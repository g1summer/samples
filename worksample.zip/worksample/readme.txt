This sample contains 3 items:

robot_penguin.mpg, is a short 3d animation I made with C++ and opengl

CanvasDraw, is an web drawing program I made with a partner, to use, open index.html

2012-09-csc301, is the source code of a project I worked with a team during one of my software engineering course, it is a java project of a self checkout system, and it is developed under the eclipse enviroment. The GUI can be invoked running src\ca\utoronto\csc301\SelfCheckOut\Gui\SelfCheckOutGUI.java