/*
 * Creator: Susan Elliott Sim
 * Course: Inf111, Winter 2008
 * 
 * Created on May 10, 2006
 * Updated on January 17, 2008
 * 
 * Copyright, 2006, 2008 University of California. 
 * 
 * The ProductDB class maintains the items in the database. The items are stored in a hash table.
 */

package ca.utoronto.csc301.SelfCheckOut.App;

import java.io.FileWriter;
import java.util.Hashtable;
import java.util.Scanner;

/**
 * The ProductDB class encapsulates the list of all products sold in the store. 
 * In a real system, this would likely be a wrapper around a database of products
 * which would be managed elsewhere.  In our sample system, we have a method which 
 * can provide a sample DB, and the capability to add items to the DB using an
 * addItem() method.
 *
 */
public class ProductDB extends Database<String, ProductInfo> {
	/**
	 * Constructs an empty database.
	 */
	public ProductDB() {
		super("Product.db");
	}
	
	/**
	 * Adds a single product to the database
	 */
	public boolean addItem(ProductInfo product) {
		return addItem(product.getCode().getCode(), product);
	}

	/**
	 * loads database contents from a file
	 * 
	 * Assumes the file is properly formatted
	 */
	@Override
	protected Hashtable<String, ProductInfo> restoreDatabase(Scanner scanner) {
		Hashtable<String, ProductInfo> hashtable = new Hashtable<String, ProductInfo>();

		while(scanner.hasNextLine()) {
			String line = scanner.nextLine();
			
			ProductInfo info;
			//12 digit code means UPC item, otherwise BIC
			if(line.split(":")[2].length() == 12) {
				info = new PackagedProduct();
			} else {
				info = new BulkProduct();
			}
			
			info.restoreObject(line);
			
			hashtable.put(info.getCode().getCode(), info);
		}
		
		return hashtable;
	}

	/**
	 * Adds a single database item from a file
	 */
	@Override
	protected void addToDatabase(FileWriter writer, String key, ProductInfo value) {
		try {
			writer.write(value.saveObject() + String.format("%n"));
		} catch (Exception e) {
			
		}
	}
}
