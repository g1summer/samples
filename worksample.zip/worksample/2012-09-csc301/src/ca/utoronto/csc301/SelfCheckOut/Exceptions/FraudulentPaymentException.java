package ca.utoronto.csc301.SelfCheckOut.Exceptions;

//an exception thrown when a fraudulent payment is detected
public class FraudulentPaymentException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	public FraudulentPaymentException() {
		super();
	}

	public FraudulentPaymentException(String message) {
		super(message);
	}

	public FraudulentPaymentException(String message, Throwable cause) {
		super(message, cause);
	}

	public FraudulentPaymentException(Throwable cause) {
		super(cause);
	}

}
