package ca.utoronto.csc301.SelfCheckOut.Devices;

import java.io.BufferedInputStream;
import java.io.InputStream;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;


public class SoundSystem {
	
	private static Clip clip;
	
	
	/*
	 * Plays a sound contained in the file pointed to by fileName
	 */
	public static void playSound(Class<?> c, String fileName) {
	
		try {
			//Only one sound should play at a time, to avoid confusion/annoyance
			if (clip != null) {
				clip.stop();
			}
			
			//Load and play the sound
			InputStream stream = c.getClassLoader().getResourceAsStream(fileName);
			AudioInputStream audio = AudioSystem.getAudioInputStream(new BufferedInputStream(stream));
			clip = AudioSystem.getClip();	    
			clip.open(audio);
			clip.start();
			
			//Catch errors because the sound system shouldn't break everything else
		} catch (Exception e){
			e.printStackTrace();
		}
			/**
			 * exception message is no longer being printed to the terminal,
			 * because it blocks normal tasks like showing
			 * thank-you-for-helping-our-environment screen.
			 */
	}
	
}
