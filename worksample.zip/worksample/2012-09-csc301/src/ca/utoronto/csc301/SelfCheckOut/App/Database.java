package ca.utoronto.csc301.SelfCheckOut.App;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Scanner;

/**
 * Abstract database class. Uses key 'V' mapped to database item 'X'.
 */
public abstract class Database<V, X> {
	
	protected Hashtable<V, X> hashtable;
	private String filename;

	/**
	 * Constructs an empty database.
	 */
	public Database(String DbFileName) {
		filename = DbFileName;
		hashtable = loadFromFile();
	}
	
	/**
	 * This method returns a Collection of the elements in the database.
	 */
	public Enumeration<X> getAllItems() {
		return hashtable.elements();
	}
	
	/**
	 * Adds a single item to the database, mapped by 'key'.
	 * By default, this will not be a persistent database entry
	 */
	public boolean addItem(V key, X item) {
		return addItem(key, item, false);
	}
	
	/**
	 * Adds a single item to the database, mapped by 'key'.
	 */
	public boolean addItem(V key, X item, boolean isPersistent)
	{
		if(lookUpItem(key) != null)
			return false;
		hashtable.put(key, item);
		if(isPersistent)
			addToFile(key, item);
		return true;
	}

	/**
	 * Updates the item mapped by 'key'
	 */
	public X updateItem(V key, X item, boolean isPersistent) {
		if (lookUpItem(key) == null) {
			return null;
		}
		hashtable.remove(key);
		hashtable.put(key, item);
		if(isPersistent) {
			updateFile(key, item);
		}
		
		return item;
	}
	
	/**
	 * This method looks up a object in the database.  
	 * @param key the key at which this object maps to
	 * @return	The object mapped to the given key
	 */
	public X lookUpItem(V key) {
		return hashtable.get(key);
	}
	
	/**
	 * Saves a single item added to the database, into it's partner file
	 */
	private void addToFile(V key, X value) {
		FileWriter writer = null;
		
		try {
			writer = new FileWriter(filename, true);
			addToDatabase(writer, key, value);
		} catch (Exception e) {
			return;
		} finally {
			try {
				if(writer != null) {
					writer.close();
				}
			} catch (Exception ex) {
			
			}
		}
		return;
	}
	
	/**
	 * Updates a single item on the database, into it's partner file
	 */
	private void updateFile(V key, X value) {
		String tmpFileName = "tmp" + filename;
		
		BufferedReader br = null;
		BufferedWriter bw = null;
		
		try {
			bw = new BufferedWriter(new FileWriter(tmpFileName, true));
			br = new BufferedReader(new FileReader(filename));
			String line;
			while ((line = br.readLine()) != null){
				if (line.contains(String.valueOf(key))) {
					continue;
				}
				bw.write(line + "\n");
			}
			
		} catch (Exception e) {
			return;
		} finally {
			try {
				if(br != null) {
					br.close();
				}
			} catch (IOException ex) {}
			try {
				if(bw != null) {
					bw.close();
				}
			} catch (IOException ex) {}
			
		}
		//delete old file
		File oldFile = new File(filename);
		oldFile.delete();
		
		// rename tmp file to old file's name
		File newFile = new File(tmpFileName);
		newFile.renameTo(oldFile);
		
		addToFile(key, value);
		return;
	}
	
	/**
	 * Load database contents from file
	 * @param filename the file location
	 */
	private Hashtable<V, X> loadFromFile() {
		File file;
		Scanner scanner = null;
		
		try {
			file = new File(filename);
			if(file.isDirectory())
				return null;
			
			//if 'filename' file doesn't exist, attempt to create it
			if(file.exists() == false)
				if(file.createNewFile() == false)
					return null;
				
			scanner = new Scanner(file);
			
			Hashtable<V, X> table = restoreDatabase(scanner);
			
			return table;
		} catch (Exception e) {
			return null;
		} finally {
			scanner.close();
		}
	}
	
	/**
	 * clears the database
	 */
	public void clearDatabase() {
		hashtable.clear();
	}
	
	/**
	 * loads database contents from a file
	 */
	protected abstract Hashtable<V, X> restoreDatabase(Scanner scanner);
	
	/**
	 * Adds a single database item from a file
	 */
	protected abstract void addToDatabase(FileWriter writer, V key, X value);
}
