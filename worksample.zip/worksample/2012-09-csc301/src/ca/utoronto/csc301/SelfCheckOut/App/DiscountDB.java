package ca.utoronto.csc301.SelfCheckOut.App;

import java.io.FileWriter;
import java.util.Hashtable;
import java.util.Scanner;

/**
 * Database which holds all PreferredCustomerDiscount objects for the system
 */
public class DiscountDB extends Database <PreferredCustomerDiscount, PreferredCustomerDiscount> {

	/**
	 * Constructs an empty database.
	 */
	public DiscountDB() {
		super("Discount.db");
	}

	/**
	 * Adds an item to the database
	 */
	public boolean addItem(PreferredCustomerDiscount discount) {		
		return addItem(discount, discount);
	}

	/**
	 * Adds an item to the database
	 */
	public boolean addItem(PreferredCustomerDiscount discount, boolean isPersistent) {		
		return addItem(discount, discount, isPersistent);
	}

	/**
	 * loads database contents from a file
	 */
	@Override
	protected Hashtable<PreferredCustomerDiscount, PreferredCustomerDiscount> restoreDatabase(Scanner scanner) {
		Hashtable<PreferredCustomerDiscount, PreferredCustomerDiscount> hashtable =
				new Hashtable<PreferredCustomerDiscount, PreferredCustomerDiscount>();
		
		while(scanner.hasNextLine()) {
			PreferredCustomerDiscount customerDiscount = new PreferredCustomerDiscount();
			customerDiscount.restoreObject(scanner.nextLine());
			
			hashtable.put(customerDiscount, customerDiscount);
		}
		
		return hashtable;
	}

	/**
	 * Adds a single database item from a file
	 */
	@Override
	protected void addToDatabase(FileWriter writer, PreferredCustomerDiscount key, PreferredCustomerDiscount value) {
		try {
			writer.write(value.saveObject() + String.format("%n"));
		} catch (Exception e) {
			
		}
	}
}
