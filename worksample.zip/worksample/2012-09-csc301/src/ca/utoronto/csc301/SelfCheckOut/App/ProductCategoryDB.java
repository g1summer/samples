package ca.utoronto.csc301.SelfCheckOut.App;

import java.io.FileWriter;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Scanner;

import javax.swing.ImageIcon;

/**
 * A database class that holds information about different categories of products, used for
 * searching for products by category.
 */
public class ProductCategoryDB extends Database<String, ProductCategory>{
	
	public ProductCategoryDB(){
		super("ProductCategories.db");
	}

	@Override
	/**
	 * The keys of the hashtable are strings storing the categories, and the values are
	 * string arrays listing the product codes of the products in the category
	 */
	protected Hashtable<String, ProductCategory> restoreDatabase(Scanner scanner) {
		Hashtable<String, ProductCategory> hashtable = new Hashtable<String, ProductCategory>();

		while(scanner.hasNextLine()) {
			String line = scanner.nextLine();
			String[] tokens = line.split(":");
			String name = tokens[0];
			String[] products;
			ImageIcon image;
			
			//If the database does not indicate an image to use, use the default
			if (tokens[1].endsWith(".jpg")) {
				image = new ImageIcon(getClass().getClassLoader().getResource(tokens[1]));
				products = Arrays.copyOfRange(tokens, 2, tokens.length);
			} else {
				image = new ImageIcon(getClass().getClassLoader().getResource("default.jpg"));
				products = Arrays.copyOfRange(tokens, 1, tokens.length);
			}
			
			// Construct ProductCategory object
			ProductCategory category = new ProductCategory(name, image, products);
			
			hashtable.put(name, category);
		}
		
		return hashtable;
	}

	@Override
	protected void addToDatabase(FileWriter writer, String key, ProductCategory value) {
		//we are not using the method, so it is left blank.
		//we assume that data entering ProductCategories.db is done manually.
	}
}