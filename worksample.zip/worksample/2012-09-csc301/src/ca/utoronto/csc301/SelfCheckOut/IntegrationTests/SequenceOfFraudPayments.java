package ca.utoronto.csc301.SelfCheckOut.IntegrationTests;

import static org.junit.Assert.*;

import java.util.Vector;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.App.DiscountDB;
import ca.utoronto.csc301.SelfCheckOut.App.FakeFraudChecker;
import ca.utoronto.csc301.SelfCheckOut.App.FraudChecker;
import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomerDB;
import ca.utoronto.csc301.SelfCheckOut.App.ProductDB;
import ca.utoronto.csc301.SelfCheckOut.App.SelfCheckOut;
import ca.utoronto.csc301.SelfCheckOut.App.UPC;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingArea;
import ca.utoronto.csc301.SelfCheckOut.Devices.PaymentCollector;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.StallCustomerException;

public class SequenceOfFraudPayments {

	static SelfCheckOut selfCheckOut;
	static BaggingArea baggingArea;
	static ProductDB productDB;
	static PaymentCollector paymentCollector;
	static PreferredCustomerDB customerDB;
	static DiscountDB discountDB;
	
	static final String UPC1 = "786936224306";
	
	static int size = 10; //change this value for testing purposes
	static FakeFraudChecker fakeFraudChecker;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		//Manually initialize parameters for a SelfCheckOut
		baggingArea = new BaggingArea();
		paymentCollector = new PaymentCollector();
		productDB = new ProductDB();
		customerDB = new PreferredCustomerDB();
		
		//Set up FakeFraudChecker
		boolean b = false;
		Vector<Boolean> vb = new Vector<Boolean>();
		for (int i = 0; i < size; i++) {
			vb.add(b);
			if (b) {
				b = false;//alternate
			} else {
				b = true;
			}
		}
		// sequence of false, true, false, true, ... 
		fakeFraudChecker = new FakeFraudChecker(vb);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		baggingArea = null;
		productDB = null;
		paymentCollector = null;
		fakeFraudChecker = null;
		selfCheckOut = null;
	}
	
	/**
	 * Tests the sequence of starting with a fraud payment, reseting, and finishing with a valid payment.
	 * @throws Exception
	 */
	@Test
	public void testEmptyCartSmallSequenceFraudPayingForNoGroceries() throws Exception {
		FraudChecker fc; //iterator
		SelfCheckOut mySCO = new SelfCheckOut(baggingArea, paymentCollector, productDB,
				customerDB, discountDB);
		fakeFraudChecker.setPosition(1); //start with true
		fc = fakeFraudChecker;
			
		mySCO.getPaymentCollector().setFraudChecker(fc);
		try {
			mySCO.payForGroceries(); //expecting to fail since fc is set to true
		} catch (StallCustomerException e) {
			assertTrue(fc.hasFraud()); 
			assertTrue(mySCO.getPaymentCollector().getFraudChecker().hasFraud()); //is a fraud payment
			assertTrue(mySCO.inStallState()); //still in stall state
			
			mySCO.resetAll(); //reset the instance of SelfCheckOut so that you can continue
		}

		fakeFraudChecker.setPosition(2); //next is false
		fc = fakeFraudChecker;
		mySCO.getPaymentCollector().setFraudChecker(fc);
		try {
			mySCO.payForGroceries(); //expecting not to fail since fc is set to false
		} catch (Exception e) {
			fail("Failed to resetAll");
		}
		assertFalse(fc.hasFraud()); 
		assertFalse(mySCO.getPaymentCollector().getFraudChecker().hasFraud()); //is not fraud payment
		assertFalse(mySCO.inStallState()); //not in stall state anymore
	}
	
	/**
	 * Large sequence of fraud and non-fraud payments. Also tests reset of the single SelfCheckOut instance.
	 * @throws Exception
	 */
	@Test
	public void testNonEmptyCartSmallSequenceFraudPayingForNoGroceries() throws Exception {
		FraudChecker fc; //iterator
		SelfCheckOut mySCO = new SelfCheckOut(baggingArea, paymentCollector, productDB,
				customerDB, discountDB);
		fakeFraudChecker.setPosition(1); //start with true
		fc = fakeFraudChecker;
		
		UPC upc = new UPC(UPC1);
		mySCO.addItem(upc); // Add an item to cart
		
		mySCO.getPaymentCollector().setFraudChecker(fc);
		try {
			mySCO.payForGroceries();
		} catch (StallCustomerException e) {
			assertTrue(fc.hasFraud()); 
			assertTrue(mySCO.getPaymentCollector().getFraudChecker().hasFraud()); //is a fraud payment
			assertTrue(mySCO.inStallState()); //still in stall state
			
			mySCO.resetAll(); //reset the instance of SelfCheckOut so that you can continue
			assertFalse(mySCO.listItemsInCart().hasMoreElements()); //new empty checkoutcart
		}

		fakeFraudChecker.setPosition(2); //next is false
		fc = fakeFraudChecker;
		mySCO.getPaymentCollector().setFraudChecker(fc);
		try {
			mySCO.payForGroceries(); //does not throw exception since we reset SelfCheckOut
		} catch (Exception e) {
			fail("Failed to resetAll");
		}
		assertFalse(fc.hasFraud()); 
		assertFalse(mySCO.getPaymentCollector().getFraudChecker().hasFraud()); //is not fraud payment
		assertFalse(mySCO.inStallState()); //not in stall state anymore
	}

	/**
	 * Tests the sequence of starting with a fraud payment, adding and item, reseting, and finishing
	 * with a valid payment.
	 * @throws Exception
	 */
	@Test
	public void testBigSequenceFraudPayingForNoGroceries() throws Exception {
		FraudChecker fc; //iterator
		SelfCheckOut mySCO = new SelfCheckOut(baggingArea, paymentCollector, productDB,
				customerDB, discountDB);
		for (int i = 0; i < size; i++) {
			fakeFraudChecker.setPosition(i); //sequence of false, true,... FakeFraudChecker
			fc = fakeFraudChecker;
			mySCO.getPaymentCollector().setFraudChecker(fc);
			try {
				mySCO.payForGroceries();
			} catch (StallCustomerException e) {
				assertTrue(fc.hasFraud()); 
				assertTrue(mySCO.getPaymentCollector().getFraudChecker().hasFraud()); //is a fraud payment
				assertTrue(mySCO.inStallState()); //still in stall state
				
				mySCO.resetAll(); //reset the instance of SelfCheckOut so that you can continue
			}
			//Otherwise there should be no fraud payment
		}
	}

	/**
	 * Large sequence of fraud and non-fraud payments with adding item taken into consideration.
	 * Also tests reset of the single SelfCheckOut instance.
	 * @throws Exception
	 */
	@Test
	public void testBigSequenceFraudPayingForOneGrocery() throws Exception {
		FraudChecker fc; //iterator
		SelfCheckOut mySCO = new SelfCheckOut(baggingArea, paymentCollector, productDB,
				customerDB, discountDB);
		for (int i = 0; i < size; i++) {
			fakeFraudChecker.setPosition(i);
			fc = fakeFraudChecker;
			mySCO.getPaymentCollector().setFraudChecker(fc);
			
			UPC upc = new UPC(UPC1);
			mySCO.addItem(upc); // Add an item to cart
			
			try {
				mySCO.payForGroceries();
			} catch (StallCustomerException e) {
				assertTrue(fc.hasFraud()); 
				assertTrue(mySCO.getPaymentCollector().getFraudChecker().hasFraud()); //is a fraud payment
				assertTrue(mySCO.inStallState()); //still in stall state
				
				mySCO.resetAll(); //reset the instance of SelfCheckOut so that you can continue
				assertFalse(mySCO.listItemsInCart().hasMoreElements()); //new checkoutcart
			}
			//Otherwise there should be no fraud payment
		}
	}
	
}
