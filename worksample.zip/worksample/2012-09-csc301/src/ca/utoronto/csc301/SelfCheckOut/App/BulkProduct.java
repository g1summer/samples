/*
 * Creator: Susan Elliott Sim
 * 
 * Created on May 10, 2006
 * Updated on January 17, 2008, September 12, 2012
 * 
 * The BulkProduct class is for products with a BIC code. It implements the ProductInfo interface.
 */

package ca.utoronto.csc301.SelfCheckOut.App;

import javax.swing.ImageIcon;

/**
 * The BulkProduct class represents a grocery product which is sold by
 * weight, such as produce, deli, meat, etc.  The details of the product
 * are stored at the time of construction, and can be retrieved using
 * accessor functions.
 *
 */
public class BulkProduct implements ProductInfo {
	/**
	 * The BIC representing the product's 5-digit bulk item code.
	 */
	private BIC myBIC;

	/**
	 * The price per unit weight of the product
	 */
	private double myUnitPrice;

	/**
	 * The String description of the product.
	 */
	private String myDescription;
	
	/**
	 * The tax category for this product
	 */
	private TaxCategory myCategory;
	
	/**
	 * The image for this product
	 */
	private ImageIcon image;
	
	/**
	 * empty constructor
	 */
	public BulkProduct() {
		
	}
	/**
	 * @param description 	The text description of the product.
	 * @param category		The tax category this product falls under.
	 * @param BICcode 		A BIC representing the product's 5-digit bulk item code.
	 * @param price 		The unit price of the product.
	 */
	public BulkProduct(String description, TaxCategory category, BIC BICcode, double price) {
		myDescription = description;
		if (category == null) {
			myCategory = new TaxCategory(0.0);
		} else {
			myCategory = category;
		}
		myBIC = BICcode;
		myUnitPrice = price;
	}

	/**
	 * Accessor function returning the product's BIC
	 */
	public BIC getBIC() {
		return myBIC;
	}
	
	/* (non-Javadoc)
	 * @see edu.uci.ics121.SelfCheckOut.App.ProductInfo#getCode()
	 */
	public Code getCode() {
		return getBIC();
	}

	/* (non-Javadoc)
	 * @see edu.uci.ics121.SelfCheckOut.App.ProductInfo#getPrice()
	 */
	public double getPrice() {
		return myUnitPrice;
	}

	/* (non-Javadoc)
	 * @see edu.uci.ics121.SelfCheckOut.App.ProductInfo#getDescription()
	 */
	public String getDescription() {
		return myDescription;
	}

	/**
	 * An accessor method which returns the tax rate for the product
	 */
	public double getTaxRate() {
		return myCategory.getTaxRate();
	}

	/**
	 * restores an object from a database file line
	 */
	@Override
	public void restoreObject(String line) {
		String[] pieces = line.split(":");
		
		myDescription = pieces[0];
		myCategory = new TaxCategory(Double.parseDouble(pieces[1]));
		try {
			myBIC = new BIC(pieces[2]);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
		myUnitPrice = Double.parseDouble(pieces[3]);
		
		//If no image indicated by the database, use a default one
		if (pieces.length == 5) {			
			image = new ImageIcon(getClass().getClassLoader().getResource(pieces[4]));
		} else {
			image = new ImageIcon(getClass().getClassLoader().getResource("default.jpg"));
		}
	}

	/**
	 * saves the object into a database file line
	 */
	@Override
	public String saveObject() {
		return myDescription + ":" + myCategory.getTaxRate() + ":" + myBIC.getCode() + ":" + myUnitPrice;
	}
	@Override
	public ImageIcon getImage() {
		return image;
	}
	
}
