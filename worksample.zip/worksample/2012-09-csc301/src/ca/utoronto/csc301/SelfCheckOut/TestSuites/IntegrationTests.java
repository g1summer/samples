package ca.utoronto.csc301.SelfCheckOut.TestSuites;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import ca.utoronto.csc301.SelfCheckOut.IntegrationTests.CartWithBulkProducts;
import ca.utoronto.csc301.SelfCheckOut.IntegrationTests.CartWithManyItems;
import ca.utoronto.csc301.SelfCheckOut.IntegrationTests.CartWithNoItems;
import ca.utoronto.csc301.SelfCheckOut.IntegrationTests.CartWithOneItem;
import ca.utoronto.csc301.SelfCheckOut.IntegrationTests.CartWithPackagedProducts;
import ca.utoronto.csc301.SelfCheckOut.IntegrationTests.InstantiatingSelfCheckOut;
import ca.utoronto.csc301.SelfCheckOut.IntegrationTests.CartWithCombinationsOfItemTypes;
import ca.utoronto.csc301.SelfCheckOut.IntegrationTests.PreferredCustomerDiscountTests;
import ca.utoronto.csc301.SelfCheckOut.IntegrationTests.SequenceOfFraudPayments;
import ca.utoronto.csc301.SelfCheckOut.IntegrationTests.SequencesofAddingAndBagging;
import ca.utoronto.csc301.SelfCheckOut.IntegrationTests.TotalCostWithTaxes;

@RunWith(Suite.class)
@SuiteClasses({ 
	CartWithManyItems.class, 
	CartWithNoItems.class,
	CartWithOneItem.class,
	CartWithPackagedProducts.class,
	CartWithBulkProducts.class,
	InstantiatingSelfCheckOut.class,
	SequencesofAddingAndBagging.class,
	CartWithCombinationsOfItemTypes.class,
	PreferredCustomerDiscountTests.class,
	TotalCostWithTaxes.class,
	SequenceOfFraudPayments.class})

public class IntegrationTests {

}
