package ca.utoronto.csc301.SelfCheckOut.IntegrationTests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Enumeration;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.App.BIC;
import ca.utoronto.csc301.SelfCheckOut.App.DiscountDB;
import ca.utoronto.csc301.SelfCheckOut.App.FakeFraudChecker;
import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomerDB;
import ca.utoronto.csc301.SelfCheckOut.App.ProductDB;
import ca.utoronto.csc301.SelfCheckOut.App.ProductInfo;
import ca.utoronto.csc301.SelfCheckOut.App.SelfCheckOut;
import ca.utoronto.csc301.SelfCheckOut.App.GroceryItem;
import ca.utoronto.csc301.SelfCheckOut.App.UPC;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingArea;
import ca.utoronto.csc301.SelfCheckOut.Devices.PaymentCollector;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.FraudulentPaymentException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.IncorrectStateException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidProductException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.StallCustomerException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidWeightException;

public class CartWithManyItems {
	
	static final double EPSILON = 1e-15;
	
	static SelfCheckOut selfCheckOut;
	static BaggingArea baggingArea;
	static ProductDB ProductDB;
	static PaymentCollector productCollector;
	static PreferredCustomerDB customerDB;
	static DiscountDB discountDB;
	static BIC[] bics;
	static double[] bicWeights;
	static UPC[] upcs;
	static ArrayList<GroceryItem> groceryItems;
	static double otherWeight = 1.1;
	static ArrayList<ProductInfo> products;

	@BeforeClass
	public static void classSetUp() throws Exception {
		//create a SelfCheckOut
		baggingArea = new BaggingArea();
		productCollector = new PaymentCollector();
		ProductDB = new ProductDB();
		customerDB = new PreferredCustomerDB();
		discountDB = new DiscountDB();

		selfCheckOut = new SelfCheckOut(baggingArea, productCollector, ProductDB, customerDB, discountDB);
		
		bics = new BIC[5];
		bicWeights = new double[5];
		upcs = new UPC[4];
		
		//Get ready to add BulkProducts
		bics[0] = new BIC("11111");
		bicWeights[0] = 2.5f;
		bics[1] = new BIC("22222");
		bicWeights[1] = 1.1f;
		bics[2] = new BIC("33333");
		bicWeights[2] = 3f;
		bics[3] = new BIC("44444");
		bicWeights[3] = 4.8f;
		bics[4] = new BIC("55555");
		bicWeights[4] = 1.5f;
		
		//Get ready to add PackagedProducts
		upcs[0] = new UPC("786936224306");
		upcs[1] = new UPC("717951000842");
		upcs[2] = new UPC("024543213710");
		upcs[3] = new UPC("085392132225");
	}

	@AfterClass
	public static void classTearDown() {
		selfCheckOut = null;
		baggingArea = null;
		ProductDB = null;
		productCollector = null;
	}
	
	@Before
	public void setUp() throws StallCustomerException{
		groceryItems = new ArrayList<GroceryItem>();
		
		//We will create a cart with many items, including duplicate items,
		//and both packaged and bulk products.

		//Add all the bulk products
		for (int i = 0; i < bics.length; i++) {
			try {
				//Keep track of the items added
				groceryItems.add(selfCheckOut.addItem(bics[i], bicWeights[i]));
				baggingArea.changeWeight(bicWeights[i]);
				
				//Add a duplicate item but with a different weight
				if (i == 0) {
					groceryItems.add(selfCheckOut.addItem(bics[i], otherWeight));
					baggingArea.changeWeight(bicWeights[i]);
				}
			} catch (IncorrectStateException e) {
				fail("IncorrectStateException");
			} catch (InvalidProductException e) {
				fail("InvalidProductException");
			} catch (InvalidWeightException e) {
				fail("Bulk products shouldn't have zero weight");
			}
		}
		
		//Add all the packaged products
		
		for (int i = 0; i < upcs.length; i++) {
			try {
				groceryItems.add(selfCheckOut.addItem(upcs[i]));
				//We don't check the weight anyway, so give an arbitrary change
				baggingArea.changeWeight(2);				

				//Add a duplicate item
				if (i == 2) {
					groceryItems.add(selfCheckOut.addItem(upcs[i]));
					baggingArea.changeWeight(2);
				}
			} catch (IncorrectStateException e) {
				fail("IncorrectStateException");
			} catch (InvalidProductException e) {
				fail("InvalidProductException");
			}
		}
		
		
	}
	
	@After
	public void tearDown() {
		selfCheckOut.resetAll();
	}
	
	@Test
	public void listItemsInCart() {
		Enumeration<GroceryItem> egi = selfCheckOut.listItemsInCart();
		GroceryItem gi;
		int i = 0;
		//Make sure every item we added is in the cart, and that
		//every item in the cart is one we added
		while(egi.hasMoreElements()) {
			i++;
			gi = egi.nextElement();
			//Makes sure everything that selfCheckOut returns is actually something
			//we added
			assertTrue(groceryItems.remove(gi));		
		}
		//Makes sure everything we added was returned
		assertTrue(groceryItems.isEmpty());
		//Makes sure all 11 items were added, so nothing strange is making this
		//test case pass when it shouldn't
		assertEquals(i, 11);
	}
	
	@Test
	public void calculatingTotalPrice() {
		double totalCost= 0.0;
		double priceBeforeTax = 0.0;
		double unitPrice = 0.0;
		
		for (int i = 0; i < bics.length; i++) {
			unitPrice = ProductDB.lookUpItem(bics[i].getCode()).getPrice();
			totalCost += (unitPrice * bicWeights[i]);
		}
		
		for (int i = 0; i < upcs.length; i++) {
			priceBeforeTax = ProductDB.lookUpItem(upcs[i].getCode()).getPrice();
			totalCost += priceBeforeTax + (ProductDB.lookUpItem(upcs[i].getCode()).getTaxRate() * 
					priceBeforeTax);
		}
		
		//Add the other two items as well
		totalCost += (ProductDB.lookUpItem(bics[0].getCode()).getPrice() * otherWeight);
		priceBeforeTax = ProductDB.lookUpItem(upcs[2].getCode()).getPrice();
		totalCost += priceBeforeTax + (ProductDB.lookUpItem(upcs[2].getCode()).getTaxRate() * 
				priceBeforeTax);
		
		assertEquals(selfCheckOut.getTotalCost(), totalCost, 1 / 1e8);
	
	}
	
	@Test
	public void paymentCollection() throws FraudulentPaymentException, StallCustomerException {
		/*Since payment isn't implemented and we've already checked that
		 * the items in the cart are the right ones, we just need to check
		 * that after payment the cart has become empty and thus ready to take
		 * the next customer */
		Enumeration<GroceryItem> egi;		
		selfCheckOut.getPaymentCollector().setFraudChecker(new FakeFraudChecker());
		selfCheckOut.payForGroceries();
		egi = selfCheckOut.listItemsInCart();
		assertFalse(egi.hasMoreElements());
	}

}
