package ca.utoronto.csc301.SelfCheckOut.IntegrationTests;

import static org.junit.Assert.*;

import java.util.Enumeration;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.App.BIC;
import ca.utoronto.csc301.SelfCheckOut.App.CheckOutCart;
import ca.utoronto.csc301.SelfCheckOut.App.DiscountDB;
import ca.utoronto.csc301.SelfCheckOut.App.FakeFraudChecker;
import ca.utoronto.csc301.SelfCheckOut.App.GroceryItem;
import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomerDB;
import ca.utoronto.csc301.SelfCheckOut.App.ProductDB;
import ca.utoronto.csc301.SelfCheckOut.App.ProductInfo;
import ca.utoronto.csc301.SelfCheckOut.App.SelfCheckOut;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingArea;
import ca.utoronto.csc301.SelfCheckOut.Devices.PaymentCollector;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.FraudulentPaymentException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidBICException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.StallCustomerException;

public class CartWithOneItem {

	static SelfCheckOut selfCheckOut;
	static BaggingArea baggingArea;
	static ProductDB productDB;
	static PaymentCollector paymentCollector;
	static PreferredCustomerDB customerDB;
	static DiscountDB discountDB;
	static BIC bic;
	static double weight;
	static GroceryItem groceryItem;

	@BeforeClass
	public static void classSetUp() throws Exception {
		//create a SelfCheckOut
		baggingArea = new BaggingArea();
		paymentCollector = new PaymentCollector();
		productDB = new ProductDB();
		customerDB = new PreferredCustomerDB();
		discountDB = new DiscountDB();

		selfCheckOut = new SelfCheckOut(baggingArea, paymentCollector, productDB, customerDB, discountDB);				

		// create a bulk item to play with
		try {
			bic = new BIC("13138");
		} catch (InvalidBICException e) {
			fail("Invalid BIC");
		}

		weight = 2.61;
	}

	@AfterClass
	public static void classTearDown(){
		selfCheckOut = null;
		baggingArea = null;
		productDB = null;
		paymentCollector = null;
	}
	
	@Before
	public void setUp() throws Exception {
		groceryItem = selfCheckOut.addItem(bic, weight); 
	}

	@After
	public void tearDown(){
		selfCheckOut.resetAll();
	}
	
	@Test
	public void listingItemsInCart() {
		Enumeration<GroceryItem> egi;

		egi = selfCheckOut.listItemsInCart();
		assertEquals(groceryItem, egi.nextElement());
		assertFalse(egi.hasMoreElements());
	}

	@Test
	public void calculatingTotalCost() {

		double total;
		ProductInfo product;
		product = productDB.lookUpItem(bic.getCode());
		
		total = selfCheckOut.getTotalCost();
		
		assertEquals((weight*product.getPrice())*(1+product.getTaxRate()), total, 0.0);
	}

	@Test
	public void payingForGroceries() throws FraudulentPaymentException, StallCustomerException {
		CheckOutCart coc;
		Enumeration<GroceryItem> egi;
		double unitPrice;
		
		// first check that coc contains some groceries
		selfCheckOut.getPaymentCollector().setFraudChecker(new FakeFraudChecker());
		coc = selfCheckOut.payForGroceries();
		assertTrue(coc.listItems().hasMoreElements());

		// now check that the one GroceryItem in coc is the one that we put
		// in by checking the code, weight, and price
		groceryItem = coc.listItems().nextElement();
		assertEquals(bic.toString(), groceryItem.getInfo().getCode().toString());
		
		double EPSILON = 1e-15; // a really small number
		assertEquals(weight, groceryItem.getWeight(), EPSILON);

		unitPrice = productDB.lookUpItem(bic.getCode()).getPrice();
		
		assertEquals(weight*unitPrice, groceryItem.getPrice(), 0.0);
		
		// we would check the actual payment here
		// but since it isn't implemented, we won't
		
		// current cart should be empty again
		
		egi = selfCheckOut.listItemsInCart();
		assertFalse(egi.hasMoreElements());
		
	}
	
}
