package ca.utoronto.csc301.SelfCheckOut.App;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

public class DateProcessor {
	/**
	 * Get the month and date (of the month) number from a Date object.
	 * @param date The date to get month number and date number from.
	 * @return An int array of size 2. The first int element is the month number.
	 * The second element is the date (of the month) number.
	 */
	public static int[] monthAndDateNumber(Date date){
		int[] md = new int[2];
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		md[0] = cal.get(Calendar.MONTH);
		md[1] = cal.get(Calendar.DATE);
		return md;
	}
	
	/**
	 * Compare if two days have the same month and date number.
	 * @param date1 A date to compare.
	 * @param date2 Another date to compare.
	 * @return truen if date1 and date2 has the same month and date number,
	 * false otherwise.
	 */
	public static boolean hasTheSameMonthAndDate(Date date1, Date date2){
		if (Arrays.equals(monthAndDateNumber(date1), monthAndDateNumber(date2))){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * get the Date for today
	 * @return Date as today
	 * @throws ParseException 
	 */
	public static Date getTodaysDate() throws ParseException{
		
			Calendar calendar = Calendar.getInstance(); 	
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			String sDate = dateFormat.format(calendar.getTime());
			Date today;
			today = dateFormat.parse(sDate);
			return today;
	}
}
