/*
 * Creator: Susan Elliott Sim
 * 
 * Created on May 10, 2006
 * Updated on January 17, 2008, September 12, 2012
 * 
 * The Utils class contains stubs and placeholder utilities for subsystems 
 * that don't exist in this program (yet), but would in a full self-service
 * POS.
 * 
 */

package ca.utoronto.csc301.SelfCheckOut.App;

import java.util.Enumeration;

public class Utils {

	/**
	 * A utility method which prints the contents of the DB to System.out
	 * @param itemsInDB  The DB Hashtable, which should be accessed using db.listAll()
	 */
	public static void printDB(Enumeration<ProductInfo> items) {
		//Enumeration<ProductInfo> items = itemsInDB.elements();
		
		PackagedProduct tempPP;
		BulkProduct tempBP;
		
		
		String out = "";
		out += "*** Below is a list of products currently in the database.***" + String.format("%n");
		out += "-------------------------------------------------------" + String.format("%n");
		
		int numElements = 0;
		while(items.hasMoreElements()) {
			numElements++;
			ProductInfo retrievedItem = items.nextElement();

			if (retrievedItem instanceof PackagedProduct) // if it is a
															// PackagedProduct
			{
				tempPP = (PackagedProduct) retrievedItem;
				out +="Product description: "
						+ tempPP.getDescription() + String.format("%n");
				out += "UPC: " + tempPP.getUPC().getCode() + String.format("%n");
				out += "Cost: " + tempPP.getPrice() + String.format("%n");
				out += "Tax Rate: " + tempPP.getTaxRate() + String.format("%n");
				out += "Weight: " + tempPP.getWeight() + String.format("%n");
			} else if (retrievedItem instanceof BulkProduct) // if it is a
																// BulkProduct
			{
				tempBP = (BulkProduct) retrievedItem;
				out += "Product description: "
						+ tempBP.getDescription() + String.format("%n");
				out += "BIC: " + tempBP.getBIC().getCode() + String.format("%n");
				out += "Unit Cost: " + tempBP.getPrice() + String.format("%n");
				out += "Tax Rate: " + tempBP.getTaxRate() + String.format("%n");
			} else {
				// This should never execute
				out += "ERROR: Product type unknown." + String.format("%n");
			}
		}

		out += "-------------------------------------------------------" + String.format("%n");
		
		System.out.println("There are " + numElements
				+ " items in the database.");
		System.out.print(out);
	}

	/**
	 * A utility method used to print out the cart contents.
	 * @param cc The CheckOutCart to print.
	 */
	public static void printCart(CheckOutCart cc) {
		Enumeration<GroceryItem> itemsInCart = cc.listItems();
		Object retrievedItem;
		GroceryItem tempGI;
		PackagedProduct tempPP;
		BulkProduct tempBP;

		System.out
				.println("*** Below is a list of products you have added: ***");
		System.out
				.println("-------------------------------------------------------");

		while (itemsInCart.hasMoreElements()) {
			tempGI = (GroceryItem) itemsInCart.nextElement();
			retrievedItem = tempGI.getInfo(); // returns the ProductInfo
												// object in GroceryItem

			if (retrievedItem instanceof PackagedProduct) // if it is a
															// PackagedProduct
			{
				tempPP = (PackagedProduct) retrievedItem;
				System.out.println("Product description: "
						+ tempPP.getDescription());
				System.out.println("UPC: " + tempPP.getUPC().getCode());
				System.out.printf("Cost: $%.2f", tempPP.getPrice());
				System.out.println();
				System.out.println("Tax Rate: " + tempPP.getTaxRate());
				System.out.println("Weight: " + tempPP.getWeight());
				System.out.printf("Total Cost: $%.2f", tempGI.getPrice() + tempGI.getTax());
				System.out.println();
			} else if (retrievedItem instanceof BulkProduct) // if it is a
																// BulkProduct
			{
				tempBP = (BulkProduct) retrievedItem;
				System.out.println("Product description: "
						+ tempBP.getDescription());
				System.out.println("BIC: " + tempBP.getBIC().getCode());
				System.out.printf("Unit Cost: %.2f", tempBP.getPrice());
				System.out.println();
				System.out.println("Tax Rate: " + tempBP.getTaxRate());
				System.out.println("Weight: " + tempGI.getWeight());
				System.out.printf("Total Cost: $%.2f", tempGI.getPrice() + tempGI.getTax());
				System.out.println();
			} else {
				// This should never execute
				System.out.println("ERROR: Product type unknown.");
			}
			System.out.println();
		}

		System.out.printf("---- TOTAL: $%.2f", cc.getTotalCost() + cc.getTotalTax());
		System.out.println();
		System.out
				.println("-------------------------------------------------------");
	}

}
