package ca.utoronto.csc301.SelfCheckOut.App;

import java.awt.Color;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;

/**
 * Class contains information about a preferred customer.
 * Also holds methods to log purchase information about the customer.
 */
public class PreferredCustomer implements DatabaseObject {
	public static enum Gender { MALE, FEMALE };
	
	/**
	 * Unique identifier for the customer
	 */
	private long id;
	
	/**
	 * Date the customer joined the preferred customer program
	 */
	private Date joinDate;
	
	/**
	 * Birth date of the customer
	 */
	private Date birthday;
	
	/**
	 * Customer's gender
	 */
	private Gender gender;
	
	/**
	 * Full name of the customer
	 */
	private String name;
	
	/**
	 * Objects array containing the settings of customer.
	 * Contains: 0. font size, 1. color at each respective index.
	 */
	private Object[] settings;
	
	/**
	 * default constructor
	 */
	PreferredCustomer() {
		settings = new Object[2];
	}
	/**
	 * Constructor
	 */
	PreferredCustomer(long id, Date joinDate, Date birthday,
			Gender gender, String name, Object[] settings) {
		this.id = id;
		this.joinDate = joinDate;
		this.birthday = birthday;
		this.gender = gender;
		this.name = name;
		this.settings = settings;
	}
	
	/**
	 * Logs a purchase made by this customer. Information is saved to a file
	 * called PreferredCustomer-{@link #id}.txt, where id is replaced by the 
	 * given customer id.
	 * @param cart check out cart of the customer
	 * @param directory directory to place the log file. Can be null.
	 */
	void logPurchases(CheckOutCart cart, String directory) {
		if(cart == null)
			return;
		if(directory == null || directory == "")
			directory = "";
		else if(!directory.endsWith("/") || !directory.endsWith("\\")) {
			directory += "/";
		}
		
		Enumeration<GroceryItem> list = cart.listItems();
		
		//setup certain vars
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		String filename = directory + "PreferredCustomer-" + id + ".txt";
		boolean newFile = false;
		BufferedWriter writer = null;
		try {
			
			//Check for file existance, and if it's in fact a directory
			File file = new File(filename);
			if(file.isDirectory())
				//Cannot continue
				return;
			
			//If it's a new file, we need to know
			if(file.exists() == false)
				newFile = true;
			
			FileWriter fileStream = new FileWriter(filename, true);
			writer = new BufferedWriter(fileStream);
			
			//If is a new file, write header
			if(newFile) {
				String header = String.format("%-14s %-17s %-12s %-12s %-12s%n",
						"Date", "UPC/BIC Code", "Weight", "Price", "Tax");
				writer.write(header);
			}
			
			//For each element in the list, add upc/bic code, price, tax and item weight
			while(list.hasMoreElements()) {
				GroceryItem groceryItem = list.nextElement();
				if(groceryItem != null) {
					String log = String.format("%-14s %-17s %-12.3f %-12.2f %-12.2f%n",
							dateFormat.format(new Date()),
							groceryItem.getInfo().getCode().getCode(),
							groceryItem.getWeight(),
							groceryItem.getPrice(),
							groceryItem.getTax());
					writer.write(log);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return;
		} finally {
			//Be sure to close the stream so file i/o is flushed and resources deallocated
			try {
				if(writer != null)
					writer.close();
			} catch (IOException e) {
				
			}
		}
	}
	
	/**
	 * returns the unique ID for this customer
	 */
	public long getId() {
		return id;
	}
	
	/**
	 * returns the date the customer joined the preferred customer program
	 */
	public Date getJoinDate() {
		return joinDate;
	}
	
	/**
	 * returns the customer's birthday
	 */
	public Date getBirthday() {
		return birthday;
	}
	
	/**
	 * returns the customer's gender
	 */
	public Gender getGender() {
		return gender;
	}
	
	/**
	 * returns the customer's full name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * returns the customer's settings
	 */
	public Object[] getSettings() {
		return settings;
	}
	
	/**
	 * sets the customer's settings
	 */
	public void setSettings(Object[] settings) {
		this.settings = settings;
	}

	/**
	 * restores an object from a database file line
	 */
	@Override
	public void restoreObject(String str) {
		String[] pieces = str.split(":");
		
		this.id = Long.parseLong(pieces[0]);
		this.joinDate = pieces[1].equals("null") ? null : new Date(Long.parseLong(pieces[1]));
		this.birthday = pieces[2].equals("null") ? null : new Date(Long.parseLong(pieces[2]));
		if(pieces[3].equals("null"))
			gender = null;
		if(pieces[3].equals("M"))
			gender = Gender.MALE;
		else
			gender = Gender.FEMALE;
		this.settings[0] = Float.parseFloat(pieces[4]);
		this.settings[1] = new Color(Integer.parseInt(pieces[5]));
		this.name = pieces[6];
	}

	/**
	 * saves the object into a database file line
	 */
	@Override
	public String saveObject() {
		Color color = (Color) settings[1];
		return 
				id + 
				";" + id + 
				":" + (joinDate == null ? "null" : joinDate.getTime()) + 
				":" + (birthday == null ? "null" : birthday.getTime()) + 
				":" + (gender == null ? "null" : (gender == Gender.MALE ? "M" : "F")) + 
				":" + (settings[0] == null? "null" : (Float.parseFloat((settings[0].toString())))) +
				":" + (settings[1] == null? "null" : (color.getRGB())) +
				":" + name;
	}
	
	
	
	/**
	 * Check if the birthday of a preferred customer is today.
	 * @param pc The preferred customer to check for birthday.
	 * @return True if today is the birth day of the preferred customer, false otherwise.
	 * @throws ParseException 
	 */
	public boolean hasBirthdayToday() throws ParseException{
		return DateProcessor.hasTheSameMonthAndDate(this.getBirthday(), DateProcessor.getTodaysDate());
	}
}
