package ca.utoronto.csc301.SelfCheckOut.Exceptions;

import java.util.Date;

import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomer;

/**
 * A simple exception which is thrown when a customer tries to 
 * sign up to be a preferred customer with invalid personal info
 *
 */
public class InvalidInfoException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public String name;
	public Date birthdate;
	public PreferredCustomer.Gender gender;

	public InvalidInfoException() {
		super();
	}

	public InvalidInfoException(String message, String name, 
			Date birthdate, PreferredCustomer.Gender gender) {
		super(message);
		this.name = name;
		this.gender = gender;
		this.birthdate = birthdate;
	}

	public InvalidInfoException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidInfoException(Throwable cause) {
		super(cause);
	}

}