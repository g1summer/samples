package ca.utoronto.csc301.SelfCheckOut.Exceptions;

public class NegativePriceException extends Exception {
	private static final long serialVersionUID = 1L;

	public NegativePriceException() {
		super();
	}

	public NegativePriceException(String message) {
		super(message);
	}

	public NegativePriceException(String message, Throwable cause) {
		super(message, cause);
	}

	public NegativePriceException(Throwable cause) {
		super(cause);
	}
}
