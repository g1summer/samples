package ca.utoronto.csc301.SelfCheckOut.Gui;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import ca.utoronto.csc301.SelfCheckOut.App.ProductCategory;

public class SearchResultPanel extends JPanel implements ActionListener {

	private static final long serialVersionUID = 165077656717078253L;

	private JLabel resultLabel;
	private ArrayList<SearchResultPanelListener> listeners;
	
	public SearchResultPanel() {
		listeners = new ArrayList<SearchResultPanelListener>();
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
	}
	
	public void displayResults(ArrayList<ProductSearchResult> results) {
		//Refreshing the results
		this.removeAll();
		
		resultLabel = new JLabel();
		
		if (results == null || results.size() == 0) {
			resultLabel.setText("No results matching search");
			this.add(resultLabel);
		} else {
			//Get ready to store results
			JPanel resultsPanel = new JPanel();
			GridBagLayout gbl = new GridBagLayout();
			GridBagConstraints c = new GridBagConstraints();
			resultsPanel.setLayout(gbl);
			
			//Helpful message
			resultLabel.setText("Displaying " + results.size() + " results:");
			//this.add(resultLabel);
			c.gridwidth = GridBagConstraints.REMAINDER;
			resultsPanel.add(resultLabel, c);
			c.gridwidth = 1;
			//Actually get each result
			for (ProductSearchResult result : results) {
				//Set up the constraints to get labels added properly,
				//then add the label
				JLabel resultName = new JLabel(result.getProductName());
				resultName.setAlignmentX(LEFT_ALIGNMENT);
				resultName.setMaximumSize(resultsPanel.getSize());
				c.fill = GridBagConstraints.WEST;
				c.weighty = 0.6;
				c.gridx = 2;
				c.gridy = GridBagConstraints.RELATIVE;
				c.anchor = GridBagConstraints.WEST;
				c.insets = new Insets(5, 0, 0, 10);
				resultsPanel.add(resultName, c);
				
				//Add the image
				c.weighty = 0.2;
				c.gridx = 1;
				JLabel image = new JLabel(result.getImage());
				resultsPanel.add(image, c);
				
				//Slightly different constraints for each add button
				JButton addButton = new JButton("Add");
				c.gridx = 0;
				addButton.setActionCommand(result.getCode());
				addButton.addActionListener(this);
				resultsPanel.add(addButton, c);
			}
			
			//Want to the results into a scrollable pane in case there are a lot
			JScrollPane scroll = new JScrollPane(resultsPanel);
			scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			
			//A bit of magic to get the panel to display nicely and not have
			//scrolling be painfully slow
			scroll.setPreferredSize(new Dimension(200, 200));
			scroll.getVerticalScrollBar().setUnitIncrement(16);
			this.add(scroll);
		} 
		
		//Redraw
		this.revalidate();
	}
	
	public void displayCategories(Enumeration<ProductCategory> categories) {
		//Refreshing the results
		this.removeAll();
		
		resultLabel = new JLabel();
		
		//Get ready to store results
		JPanel categoriesPanel = new JPanel();
		GridBagLayout gbl = new GridBagLayout();
		GridBagConstraints c = new GridBagConstraints();
		categoriesPanel.setLayout(gbl);
		
		//Helpful message
		resultLabel.setText("Product Categories");
		c.gridwidth = GridBagConstraints.REMAINDER;
		categoriesPanel.add(resultLabel, c);
		c.gridwidth = 1;
		//Actually get each result
		while(categories.hasMoreElements()) {
			//Get the next category
			ProductCategory category = categories.nextElement();
			
			//Set up the constraints to get labels added properly,
			//then add the label
			JLabel categoryName = new JLabel(category.getName());
			categoryName.setAlignmentX(LEFT_ALIGNMENT);
			categoryName.setMaximumSize(categoriesPanel.getSize());
			c.fill = GridBagConstraints.WEST;
			c.weighty = 0.6;
			c.gridx = 2;
			c.gridy = GridBagConstraints.RELATIVE;
			c.anchor = GridBagConstraints.WEST;
			c.insets = new Insets(5, 0, 0, 10);
			categoriesPanel.add(categoryName, c);
			
			//Add the image
			c.weighty = 0.2;
			c.gridx = 1;
			JLabel image = new JLabel(category.getImage());
			categoriesPanel.add(image, c);
			
			//Slightly different constraints for each add button
			JButton addButton = new JButton("List Items");
			c.gridx = 0;
			addButton.setActionCommand(category.getName());
			addButton.addActionListener(this);
			categoriesPanel.add(addButton, c);
		}
		
		//Want to the results into a scrollable pane in case there are a lot
		JScrollPane scroll = new JScrollPane(categoriesPanel);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		
		//A bit of magic to get the panel to display nicely and not have
		//scrolling be painfully slow
		scroll.setPreferredSize(new Dimension(200, 200));
		scroll.getVerticalScrollBar().setUnitIncrement(16);
		this.add(scroll);
		
		//Redraw
		this.revalidate();
	}
	
	public void addListener(SearchResultPanelListener listener) {
		listeners.add(listener);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		for (SearchResultPanelListener listener : listeners) {
			listener.resultEvent(e.getActionCommand());
		}
		
	}
		
}
