package ca.utoronto.csc301.SelfCheckOut.Exceptions;

public class StallCustomerException extends Exception{
	private static final long serialVersionUID = 1L;

	public StallCustomerException() {
		super();
	}

	public StallCustomerException(String message) {
		super(message);
	}

	public StallCustomerException(String message, Throwable cause) {
		super(message, cause);
	}

	public StallCustomerException(Throwable cause) {
		super(cause);
	}
}
