package ca.utoronto.csc301.SelfCheckOut.App;

//the interface for the payment fraud checker
public interface FraudChecker {
	
	public boolean hasFraud();
	
}
