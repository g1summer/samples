/*
 * Creator: Susan Elliott Sim
 * 
 * Created on May 10, 2006
 * Updated on January 17, 2008, September 12, 2012
 * 
 * The SelfCheckOut class contains functions that can be called by the real user interface
 * of the self checkout systems.
 */

package ca.utoronto.csc301.SelfCheckOut.App;

import java.util.*;

import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingArea;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingAreaEvent;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingAreaListener;
import ca.utoronto.csc301.SelfCheckOut.Devices.PaymentCollector;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.AddWhileBaggingException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.AddWhilePayingException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.AlreadyLoggedInException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.BagWhileAddingException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.FraudulentPaymentException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.IncorrectStateException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidInfoException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidProductException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.StallCustomerException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidWeightException;
import ca.utoronto.csc301.SelfCheckOut.Gui.ProductSearchResult;

import com.wcohen.ss.*;


/**
 * The SelfCheckOut class contains the business logic of the sales point, and keeps
 * track of the state of the current customer's checkout.  The class contains 
 * methods to handle adding items to the customer's cart, accepting payment,
 * and receiving events from the BaggingArea.
 *
 */
public class SelfCheckOut implements BaggingAreaListener {
	/**
	 * This enumeration represents the four states of the
	 * SelfCheckOut system:<br>
	 * <code>READY</code> means the system is awaiting a new customer<br>
	 * <code>ADDING</code> means the system is prepared for another item to be added<br>
	 * <code>BAGGING</code> means the system is awaiting notification that the item 
	 * has been placed in the bagging area<br>
	 * <code>DONEADDING</code> means the system is waiting for the customer to pay for their items.<br>
	 * Attempts to add items while <code>BAGGING</code> or <code>DONEADDING</code> result in errors.
	 * @author Susan Elliott Sim
	 *
	 */
	public enum checkOutState {
		//added STALLING state for stalling customer
		READY, ADDING, BAGGING, DONEADDING, STALLING
	}

	//This is a bit of a magic number. Since we are allowing "fuzzy" search,
	//we can adjust this value to determine how fuzzy we want it. This value
	//was arrived at through mostly through experimentation and seeing what felt
	//right
	private static final double SIMILARITY_THRESHOLD = 0.78;

	/**
	 * The cart containing items the customer has scanned.
	 */
	private CheckOutCart checkOutCart;

	/**
	 * The associated BaggingArea, which will notify SelfCheckOut when it detects a weight change.
	 */
	public BaggingArea baggingArea;

	/**
	 * An object representing the credit card or cash accepting device.
	 */
	private PaymentCollector paymentCollector;

	/**
	 * The database of products in the store.
	 */
	private ProductDB productDB;

	/**
	 * The current state of the system.
	 */
	private checkOutState transactionState;
	
	/**
	 * Tax recorder to keep track of how much taxes have been collected by the system 
	 */
	private TaxRecorder taxRecorder;
	
	/**
	 * Preferred customer database
	 */
	private PreferredCustomerDB preferredCustomerDB;
		
	/**
	 * Logged in preferred customer
	 */
	private PreferredCustomer preferredCustomer;
	
	/**
	 * Alert system for this instance
	 */
	private AlertSystem alertsys = new FakeAlertSystem();
	
	/**
	 * The fake alert code for the fraudulent payment event.
	 */
	private int alertCode = 123;
	
	/**
	 * Verbal description of the fraudulent payment event.
	 */
	private String alertMsg = "A fradulent payment is detected, " +
			"please detain the suspected customer at the" +
			"self check out area ASAP.";
	
	/**
	 * Database of discounts for preferred customers
	 */
	private DiscountDB discountDB;
	
	/**
	 * Today's date (impossible to test without having date field in SCO object)
	 */
	private Date today;
	
	/**
	 * Specifies the logging directory for preferred customers
	 */
	private String loggingDirectory;
		
	/**
	 * The argument-less constructor makes the necessary utility classes and passes them to the 
	 * argumented constructor.
	 * @throws Exception
	 */
	public SelfCheckOut() throws Exception {
		this(new BaggingArea(), new PaymentCollector(), new ProductDB(),
				new PreferredCustomerDB(), new DiscountDB(), "");		
	}
	
	/**
	 * This is the chief constructor.  It records the provided BaggingArea, PaymentCollector and ProductDB,
	 * and attaches itself to the BaggingArea so that it receives notifications of BaggingAreaEvents. 
	 * @param bagging
	 * @param payment
	 * @param db
	 * @param customerDb
	 * @throws Exception
	 */
	public SelfCheckOut(BaggingArea bagging, PaymentCollector payment,
			ProductDB productDb, PreferredCustomerDB customerDb,
			DiscountDB discountDb) throws Exception {
		this(bagging, payment, productDb, customerDb, discountDb, "");
	}

	/**
	 * This is the chief constructor.  It records the provided BaggingArea, PaymentCollector and ProductDB,
	 * and attaches itself to the BaggingArea so that it receives notifications of BaggingAreaEvents. 
	 * @param bagging
	 * @param payment
	 * @param db
	 * @param customerDb
	 * @param loggingDirectory
	 * @throws Exception
	 */
	public SelfCheckOut(BaggingArea bagging, PaymentCollector payment,
			ProductDB productDb, PreferredCustomerDB customerDb, 
			DiscountDB discountDb, String loggingDirectory) throws Exception {
		checkOutCart = new CheckOutCart();
		taxRecorder = new TaxRecorder();
		baggingArea = bagging;
		baggingArea.attach(this);
		paymentCollector = payment;
		productDB = productDb;
		preferredCustomerDB = customerDb;
		discountDB = discountDb;
		Calendar cal = Calendar.getInstance();
		today = cal.getTime();
		transactionState = checkOutState.READY;
		if(loggingDirectory == null)
			loggingDirectory = "";
		this.loggingDirectory = loggingDirectory;
	}

	/**
	 * This version of addItem() accepts a UPC code and adds the corresponding 
	 * PackagedProduct to the customer's cart.  It looks the code up in the DB.
	 * 
	 * @param upcCode	The UPC of the scanned item.
	 * @return			The GroceryItem which is also added to the CheckOutCart.
	 * @throws IncorrectStateException	Thrown when addItem() is called during Bagging or once payment is initiated.
	 * @throws InvalidProductException	Thrown when a product corresponding to the UPC is not found.
	 * @throws StallCustomerException 
	 */
	public GroceryItem addItem(UPC upcCode) throws IncorrectStateException,
			InvalidProductException, StallCustomerException {
		/*
		 *  if weight change is not ok, or transactionState is BAGGING or
		 *  DONEADDING, don't allow customer to add!  
		 */
		if (transactionState == checkOutState.BAGGING) {
			// user should place the previous item in the bagging area first.
			throw new AddWhileBaggingException();			
		} else if (transactionState == checkOutState.DONEADDING) 
		{
			// user has chosen to pay, and cannot add more items
			throw new AddWhilePayingException();
		} else if (transactionState == checkOutState.STALLING){
			throw new StallCustomerException();
		}
			else {
			//This shouldn't happen, but in case it does, throw a more
			//graceful exception than NullPointer
			if (upcCode == null) {
				throw new InvalidProductException();
			}
			// returns a ProductInfo object			
			ProductInfo info = productDB.lookUpItem(upcCode.getCode()); 
			if (info == null) {
				throw new InvalidProductException();
			} else {
				// create a new GroceryItem object
				GroceryItem newItem = new GroceryItem(info,
						((PackagedProduct) info).getPrice(),
						((PackagedProduct) info).getWeight());
				// add the new GroceryItem object to vector				
				checkOutCart.addItemToCart(newItem); 
				transactionState = checkOutState.BAGGING;
				return newItem;
			}
		}
	}

	// This function will be called to add a BulkProduct object to checkOutCart.
	// It accepts an BIC code
	// object since this is what the user interface will pass. This function
	// will use it to find the product
	// information, create a GroceryItem object to add to the cart.
	/**
	 * This version of addItem() accepts a BIC and weight, and adds the corresponding 
	 * BulkProduct to the customer's cart.  It looks the code up in the DB.
	 * 
	 * @param bicCode	The BIC of the scanned item.
	 * @param weight	The amount of the BulkProduct being purchased.
	 * @return			The GroceryItem which is also added to the CheckOutCart.
	 * @throws IncorrectStateException	Thrown when addItem() is called during Bagging or once payment is initiated.
	 * @throws InvalidProductException	Thrown when a product corresponding to the BIC is not found.
	 * @throws InvalidWeightException 
	 * @throws StallCustomerException 
	 */
	public GroceryItem addItem(BIC bicCode, double weight)
			throws IncorrectStateException, InvalidProductException, InvalidWeightException, StallCustomerException {

		/* if weight change is not ok, or transactionState is BAGGING or
		 * DONEADDING, don't allow customer to add!
		 */
		if (transactionState == checkOutState.BAGGING) {
			// user should place the previous item in the bagging area first.
			throw new AddWhileBaggingException();
		} else if (weight <= 0) {
			 throw new InvalidWeightException();
		} else if (transactionState == checkOutState.DONEADDING)
		{
			// user has chosen to pay, and cannot add more items
			throw new AddWhilePayingException();
		} 
		else if (transactionState == checkOutState.STALLING){
			throw new StallCustomerException();
		}
		else {
			//This shouldn't happen, but in case it does, throw a more
			//graceful exception than NullPointer
			if (bicCode == null) {
				throw new InvalidProductException();
			}
			// returns a ProductInfo object
			ProductInfo info = productDB.lookUpItem(bicCode.getCode()); 
			if (info == null) {
				throw new InvalidProductException();
			} else {
				// create a new GroceryItem object
				GroceryItem newItem = new GroceryItem(info,
						((BulkProduct) info).getPrice() * weight, weight);
				// add the new GroceryItem object to the cart
				checkOutCart.addItemToCart(newItem); 
				transactionState = checkOutState.BAGGING;
				return newItem;
			}
		}
	}

	// Calls relevant function in CheckOutCart to return the Enumeration
	// containing items in the CheckOutcart
	/**
	 * This method retrieves an enumeration of all the items currently in the cart
	 * and returns it.
	 */
	public Enumeration<GroceryItem> listItemsInCart() {
		return checkOutCart.listItems();
	}

	/**
	 * This method returns the current cost total of all items in the cart.
	 */
	public double getTotalCost() {
		return checkOutCart.getTotalCost() + checkOutCart.getTotalTax() - getTotalDiscount();
	}

	/**
	 * When the bagging area detects a change in total weight, this function
	 * is called to change the state of the system (transactionState).
	 * Normally we would do a weight check here to ascertain if the predicted and actual
	 * bagging area weights match. Since that functionality is not implemented
	 * in this example, we simply change state to ADDING
	 * @param be	The attached BaggingArea which is sending the event.
	 * @param event	The BaggingAreaEvent, which includes the total weight and most recent change in the bagging area. 
	 * @throws BagWhileAddingException 
	 */
	public void notifyBaggingAreaEvent(BaggingArea be, BaggingAreaEvent event) throws BagWhileAddingException {
		//Customer should only be bagging an item after adding it
		if (transactionState != checkOutState.BAGGING) {
			throw new BagWhileAddingException();
		}
		
		transactionState = checkOutState.ADDING;
	}

	/**
	 * Handling payment is not part of this assignment. This function just
	 * returns the cart indicating the payment was received.  It also clears the
	 * shopping cart and resets the system state.  If we implemented this part of the system,
	 * we would throw an exception to indicate a failed transaction rather than returning null.
	 * @return the cart corresponding to the just-completed transaction.
	 * @throws StallCustomerException 
	 * @throws FraudulentPaymentException 
	 */
	public CheckOutCart payForGroceries() throws StallCustomerException{
		if (transactionState == checkOutState.STALLING){
			throw new StallCustomerException();
		}
		transactionState = checkOutState.DONEADDING;
		// check if payment is successful
		// make sure tax is added to total cost at this stage
		try {

			// discounts are applied before tax, as is customary
			if(paymentCollector.collect(getTotalCost())) {
				//record collected taxes into the tax recorder
				taxRecorder.recordCollectedTaxes(checkOutCart.getTotalTax());
				
				//If the customer is a preferred customer, record purchases to their history
				if(preferredCustomer != null) {
					preferredCustomer.logPurchases(checkOutCart, loggingDirectory);
				}
				
				// make a copy of the old cart
				CheckOutCart cc = checkOutCart;
				
				// replace the full cart with a new one
				checkOutCart = new CheckOutCart();
				
				// reset our state to waiting for a customer.
				transactionState = checkOutState.READY;
				
				// reset the logged in preferred customer
				preferredCustomer = null;
				
				// return the old cart for examination
				return cc;
			}
		} catch (FraudulentPaymentException e) {
			
			transactionState = checkOutState.STALLING;
			alertsys.recieveAlert(alertCode, alertMsg);
			throw new StallCustomerException();
		}
		return null;
	}
	
	/**
	 * An accessor method which returns the PreferredCustomer associated with this
	 * SelfCheckOut. Useful for getting PreferredCustomer settings.
	 * 
	 */
	public PreferredCustomer getPreferredCustomer() {
		return preferredCustomer;
	}
	
	/**
	 * An accessor method which returns the BaggingArea associated with this SelfCheckout.
	 * Useful if the application wants to also receive bagging events, for example.
	 */
	public BaggingArea getBaggingArea() {
		return baggingArea;
	}
	
	/**
	 * An accessor method which returns the ProductDB associated with this SelfCheckOut.
	 * Useful if the application wants to add items to the database or to look up items.
	 */
	public ProductDB getProductDB() {
		return productDB;		
	}
	
	/**
	 * Returns true if the transaction state is in stalling. Return false otherwise.
	 * 
	 */
	public boolean inStallState(){
		return transactionState == checkOutState.STALLING;
	}
	
	/**
	 * An accessor method which returns the AlertSystem associated with this SelfCheckOut.
	 * Useful if the application wants to send an alert to the store personnel.
	 */
	public AlertSystem getAlertSystem(){
		return alertsys;
	}
	
	/**
	 * An accessor method which returns the PaymentCollector associated with this SelfCheckOut.
	 * It is useful for accessing the FraudChecker to determine whether there is fraud or not
	 * in the payment.
	 */
	public PaymentCollector getPaymentCollector() {
		return paymentCollector;
	}
	
	/**
	 * Method which returns the total dollar discount that the currently
	 * logged in customer is eligible for today. If no customer is logged in,
	 * return 0;
	 */
	public double getTotalDiscount() {
		// If a preferred customer is logged in, determine which, if any,
		// discounts they are eligible for and apply them accordingly
		double percentage = 0.0;
		
		if (preferredCustomer != null) {
			Enumeration<PreferredCustomerDiscount> discounts = discountDB.getAllItems();
			
			while (discounts.hasMoreElements()) {
				PreferredCustomerDiscount deal = discounts.nextElement();
				if (deal.accepted(preferredCustomer, today)) {
					percentage += deal.getDiscount();
				}
			}
		}
		
		return (percentage * checkOutCart.getTotalCost());
	}
	
	/**
	 * A utility method for resetting the SelfCheckOut to the initial state with 
	 * an empty cart. Useful when testing.
	 * @return 
	 * 
	 */
	public void resetAll() {
		
		// replace the old cart with a new one
		checkOutCart = new CheckOutCart();
		
		// reset our state to waiting for a customer.
		transactionState = checkOutState.READY;
		
		// reset the logged in preferred customer
		preferredCustomer = null;
			
	}
	
	/**
	 * Logs in the preferred customer with the given id
	 * @param id the id of the customer
	 * @return true if logged in, false otherwise
	 * @throws AlreadyLoggedInException 
	 */
	public PreferredCustomer loginPreferredCustomer(long id) throws AlreadyLoggedInException {
		if(preferredCustomerDB == null)
			return null;
		
		if (preferredCustomer != null) throw new AlreadyLoggedInException();
		
		preferredCustomer = preferredCustomerDB.lookUpItem(id);
		
		return preferredCustomer;
	}
	
	/**
	 *  
	 * 
	 */
	public PreferredCustomer updatePreferredCustomer(PreferredCustomer customer) throws Exception {
		if (preferredCustomerDB == null) return null;
		
		if (preferredCustomer.getId() != customer.getId()) throw new Exception();
		
		preferredCustomer = preferredCustomerDB.updateItem(preferredCustomer, true);
		return null;
	}
	
	/**
	 * Method for adding a new preferred customer to the database
	 * 
	 * @param name Name of the customer
	 * @param birthdate Birthdate of the customer
	 * @param gender Gender of the customer
	 * @return If the login was successful, return the PreferredCustomer object
	 * @throws InvalidInfoException
	 */
	public PreferredCustomer addPreferredCustomer(String name, Date birthdate, PreferredCustomer.Gender gender)  throws InvalidInfoException{
		// Verify that the info is correct
		PreferredCustomer pc = SignUpValidator.validateForm(today, birthdate, name, gender, preferredCustomerDB);
		
		// add the customer to the database
		if (preferredCustomerDB.addItem(pc, true)) {
			return pc;
		} else {
			return null;
		}
	}
	
	public ArrayList<ProductSearchResult> getProductsByTextSearch(String lookfor) {
		ArrayList<ProductSearchResult> results = new ArrayList<ProductSearchResult>();
		ArrayList<Double> scores = new ArrayList<Double>();
		
		Enumeration<ProductInfo> allItems = productDB.getAllItems();
		
		//For each item, figure out if we want it in our results
		//At the same time, sort results by relevance
		while (allItems.hasMoreElements()) {
			ProductInfo info = allItems.nextElement();
			String productName = info.getDescription();
			double totalscore = 0;
			double nextscore = 0;
			
			/* Old implementation */
			
			/*
			//Return results that have a substring that matches
			//what the user searched for exactly
			for (int i = 0; i < productName.length() - lfLength + 1; i++) {
				if (productName.substring(i, i+lfLength).equalsIgnoreCase(lookfor)) {
					ProductSearchResult result = 
							new ProductSearchResult(info.getDescription(),
													info.getCode().getCode(),
													info.getImage());
					results.add(result);
					break;
				}
			}
			*/
			
			/* New sleek and fancy string matching that allows for fuzzy search */
			
			//String matching algorithm
			JaroWinkler jw = new JaroWinkler();
			
			//Best matches will match before tokenizing so assign extra points
			nextscore = jw.score(productName, lookfor);
			if (nextscore >= SIMILARITY_THRESHOLD) {
				totalscore+=nextscore;
			}
			
			//Want to match if any word matches
			for (String token : productName.split(" ")) {				
				//Calculate the score
				nextscore = jw.score(token, lookfor);
				if (nextscore >= SIMILARITY_THRESHOLD) {
					totalscore+=nextscore;
				}
			}
			
			//Add items sorted by relevance
			if (totalscore > 0) {
				boolean added = false;
				//Make a result object					
				ProductSearchResult result = new ProductSearchResult(
						info.getDescription(),
						info.getCode().getCode(),
						info.getImage());
				
				//Basically insertion sort
				for (int i = 0; i < results.size(); i++) {						
					if (scores.get(i) < totalscore) {
						scores.add(totalscore);
						results.add(i, result);
						added = true;
						break;
					}
				}
				
				//This is the case where the current result is the least
				//relevant, so we put it at the end
				if (!added) {
					scores.add(totalscore);
					results.add(result);
				}				
			}				
		}
		
		return results;
	}
	
	/**
	 * Utility method for setting today's date for testing purposes
	 */
	public void setDate(Date date) {
		today = date;
	}
	
	/**
	 * Utility method for getting today's date
	 */
	public Date getDate() {
		return today;
	}
	
	public void printPreferredCustomer() {
		System.out.println(preferredCustomer.getId());
		System.out.println(preferredCustomer.getName());
	}
	
	/**
	 * @return true is the current checkOutCart contains an eco-friendly product.
	 * false otherwise.
	 */
	public boolean shoppedEcoFriendlyItem(){
		if (this.checkOutCart == null){
			return false;
		}
		return this.checkOutCart.hasEcoFriendlyProduct();
	}
}
