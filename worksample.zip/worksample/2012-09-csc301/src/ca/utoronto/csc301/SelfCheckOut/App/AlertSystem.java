package ca.utoronto.csc301.SelfCheckOut.App;

//the interface for the alert system
public interface AlertSystem {
	public void recieveAlert(int alertCode, String alertMsg);
	public int getAlertCode(int i);
	
	public int numAlertReceived();
	
	public int lastAlertCode();
	
	public String getAlertMsg(int i);
}
