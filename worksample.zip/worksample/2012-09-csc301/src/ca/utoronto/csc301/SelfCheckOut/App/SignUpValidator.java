package ca.utoronto.csc301.SelfCheckOut.App;

import java.awt.Color;
import java.util.Calendar;
import java.util.Date;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidInfoException;

/**
 * A class to verify that the information given by a customer to register
 * as a preferred customer is valid.
 *
 */
public class SignUpValidator {

	/**
	 * Takes information given by the customer and validates it. If nothing is awry,
	 * return the PreferredCustomer object with the given information, otherwise 
	 * throw an exception with an appropriate message to show the customer.
	 * 
	 * @param today Today's date
	 * @param birthdate The birthdate of the customer
	 * @param name The name of the customer
	 * @param gender The gender of the customer
	 * @return The PreferredCustomer object representing the customer
	 * @throws InvalidInfoException 
	 */
	public static PreferredCustomer validateForm(Date today, Date birthdate, String name, 
			PreferredCustomer.Gender gender, PreferredCustomerDB db)
					throws InvalidInfoException {
		
		Calendar temp = Calendar.getInstance();
		temp.setTime(today);
		temp.add(Calendar.YEAR, -120);
		Date comp = temp.getTime();
		
		// If the person is over 120 years old, something is wrong
		if (comp.after(birthdate)) {
			throw new InvalidInfoException("You are not possibly over 120 years old", 
					name, birthdate, gender);
		}
		
		temp.setTime(today);
		temp.add(Calendar.YEAR, -16);
		comp = temp.getTime();
		
		// If the person is younger than 16 years old, we should not let them sign up
		if (comp.before(birthdate)) {
			throw new InvalidInfoException("You must be over the age of 16 to register", 
					name, birthdate, gender);
		}
		
		// Customer must have a name
		if (name.length() == 0) {
			throw new InvalidInfoException("Please enter your name", 
					name, birthdate, gender);
		}
		
		// Name must be less than 30 characters
		if (name.length() > 30) {
			throw new InvalidInfoException("Your name must be less than 30 characters long", 
					name, birthdate, gender);
		}
		
		// Generate an id number for this customer
		long id;
		do {
			id = (long) (Math.random() * 1e8);
		} while (db.lookUpItem(id) != null);
		
		// Create the new preferred customer object and return it
		// Create default font size and background color for customer
		Color color = new Color(238,238,238); //default background color
		float fontSize = 12f; //default font size
		Object[] settings = { fontSize, color };
		PreferredCustomer pc = new PreferredCustomer(id, today, birthdate, gender, name, settings);
		
		return pc;
	}
}
