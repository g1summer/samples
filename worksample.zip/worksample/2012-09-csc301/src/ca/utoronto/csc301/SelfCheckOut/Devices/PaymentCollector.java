/*
 * Creator: Susan Elliott Sim
 * Course: Inf111, Winter 2008
 * 
 * Created on May 10, 2006
 * Updated on January 17, 2008
 * 
 * Copyright, 2006, 2008 University of California. 
 * 
 * The PaymentCollector class handles the payment process. This is not a concern for this assignment.
 * It is created to make the system more "complete," but it lacks real functionalities.
 */

package ca.utoronto.csc301.SelfCheckOut.Devices;

import ca.utoronto.csc301.SelfCheckOut.App.FakeFraudChecker;
import ca.utoronto.csc301.SelfCheckOut.App.FraudChecker;
//import ca.utoronto.csc301.SelfCheckOut.App.ManualFakeFraudChecker;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.FraudulentPaymentException;

/**
 * This class represents the payment-collecting portion of the system: the 
 * credit-card pad or cash-input part of the system.  We are not concerned with 
 * this part of the system, so a simple stub method is provided.
 *
 */
public class PaymentCollector {
	
	private FraudChecker fraudChecker;
	//private AlertSystem alert;
	
	public PaymentCollector() {
		//change the argument of fc if you want some fake fraudulent detection decisions.
		fraudChecker = new FakeFraudChecker(false);
		//If you want to test stalling in SelfCheckOutGUI by a pre-deternmined
		//sequence of fraud checking decisions use the manual fake fc below.
		//If you want to edit the sequence and see how it works, go to
		//ManualFakeFraudChekcer Class.
		//fraudChecker = new ManualFakeFraudChecker();
	}
	
	//I added this constructor to make PaymentCollector with fake fraud checking 
	//testable, because you can now use your own customized fake checker, as well as
	//you own customized fake alarm.
	public PaymentCollector(FraudChecker fraudChecker){
		this.fraudChecker = fraudChecker;
	}	

	/**
	 * This method is called by SelfCheckOut when the customer is finished scanning and
	 * wishes to pay.  It is a stub method which returns <code>true</code>, indicating successful payment.  
	 * @param amount	The amount of payment requested.
	 * @return <code>true</code> indicating payment accepted.
	 * @throws FraudulentPaymentException 
	 */
	public boolean collect(double amount) throws FraudulentPaymentException {
		
		if (fraudChecker.hasFraud()){
			throw new FraudulentPaymentException("A fraudulent payment is detected.");
		}
		// For this project, we are not concerned with this part of the system.
		// We will just assume
		// that whenever this function is called, this function will always
		// return true to the
		// calling program to indicate that the payment has been accepted.
        
		return true;
	}
	
	/**
	 * Getter function for FraudChecker
	 */
	public FraudChecker getFraudChecker() {
		return fraudChecker;
		
	}
	
	/**
	 * Setter function for FraudChecker. 
	 * @param fc the FraudChecker to set fraudChecker to
	 */
	public void setFraudChecker(FraudChecker fc){
		this.fraudChecker= fc;
	}
	
}