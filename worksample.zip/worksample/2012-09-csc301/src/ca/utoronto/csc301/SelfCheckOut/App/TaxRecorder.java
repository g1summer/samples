package ca.utoronto.csc301.SelfCheckOut.App;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

/**
 * The TaxRecorder is a class to facilitate the action of recording all taxes collected
 * by the system.
 */
public class TaxRecorder {
	
	/**
	 * date timestamp format. package access to allow test suite to have access
	 */
	static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
	
	/**
	 * currency formatter for doubles. package access to allow test suite to have access
	 */
	static final NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(Locale.CANADA);
	
	/**
	 * The default filename used if none is given
	 */
	private static final String DEFAULT = "CollectedTaxes.txt";
	
	/**
	 * The filename where all recorded taxes will be written to
	 */
	private String filename;
	
	/**
	 * Default constructor, calls {@link #TaxRecorder(String)} with the default
	 * file name, {@link #DEFAULT}
	 */
	public TaxRecorder() {
		this(DEFAULT);
	}
	
	/**
	 * Contstructor which which defiles which file to append all collected taxes
	 * @param filename
	 */
	public TaxRecorder(String filename) {
		this.filename = filename;
		currencyFormatter.setRoundingMode(RoundingMode.HALF_EVEN);
	}
	
	/**
	 * Records the given tax amount to the given tax recording file
	 * @param taxesCollected
	 * @return true if write is successful, false otherwise
	 */
	public boolean recordCollectedTaxes(double taxesCollected) {
		//Taxes are recorded in 'filename'. This function scans through the file until the 
		// last line is found, which will contain the taxes collected for the latest day.
		//If the day for that entry matches the day that this function is called, the line 
		// entry will be read, the new total taxes will be recalculated, and replaced in the file.
		
		//This is done by writing the updated tax values to a temp file, then replacing the old 
		// file when it is complete
		
		File currentFile, tempFile;
		Scanner scanner = null;
		FileWriter writer = null;
		
		try {
			currentFile = new File(filename);
			if(currentFile.isDirectory())
				return false;
			
			//if 'filename' file doesn't exist, attempt to create it
			if(currentFile.exists() == false)
				if(currentFile.createNewFile() == false)
					return false;
				
			scanner = new Scanner(currentFile);
			writer = new FileWriter(filename + ".tmp", true);
			
			//scan through all lines in 'filename'
			String line = null;
			while(scanner.hasNextLine()) {
				line = scanner.nextLine();
				
				//write the line to the temp file, but only if it's not the last of the file
				if(scanner.hasNextLine())
					writer.write(line + "\r\n");
			}
			
			//check that file isn't empty
			if(line != null) {
				//line[0] will contain the date, line[1] contains the taxes collected for that day
				String[] linePeices = line.split(":");
				Date date = dateFormat.parse(linePeices[0]);
				
				if(dateFormat.format(date).equals(dateFormat.format(new Date()))) {
					//if the date from the file is the today, then re-calculate taxes collected for the day
					Double dayTaxes = Double.valueOf(linePeices[1].replace("$", "").replace(",", ""));
					taxesCollected += dayTaxes;
				} else {
					//Otherwise it needs to be copied back into the file, 
					// new ammount for today will be appended later
					writer.write(line + "\r\n");
				}
			}
			
			//write new taxes collected to the temp file
			String formattedTaxes = currencyFormatter.format(taxesCollected);
			writer.write(dateFormat.format(new Date()) + ":" + formattedTaxes + "\r\n");
		} catch (Exception e) {
			return false;
		} finally {
			//close any open streams
			if(scanner != null)
				scanner.close();
			if(writer != null) {
				try {
					writer.close();
				} catch (IOException ex) {
					return false;
				}
			}
		}

		//now replace the old file with the temp file, which is now current
		if(currentFile.delete() == false)
			return false;
		tempFile = new File(filename + ".tmp");
		return tempFile.renameTo(currentFile);
	}
}
