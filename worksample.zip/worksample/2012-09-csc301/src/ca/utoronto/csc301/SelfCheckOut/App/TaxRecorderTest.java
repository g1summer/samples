package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileWriter;
import java.util.Date;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TaxRecorderTest {
	
	static final String FILENAME = "testTaxRecorder.txt";
	
	TaxRecorder recorder;
	
	@Before
	public void setUp() throws Exception {
		recorder = new TaxRecorder(FILENAME);
	}

	@After
	public void tearDown() throws Exception {
		recorder = null;
		
		File file = new File(FILENAME);
		assertEquals(file.delete(), true);
	}
	
	@Test
	public void testDirectoryInPlaceOfFile() {
		//create directory in place of file, should be impossible to record taxes in that instance
		File directory = new File(FILENAME);
		assertEquals(directory.mkdir(), true);
		
		assertFalse(recorder.recordCollectedTaxes(1.00f));
	}
	
	@Test
	public void testSingleEntry() {
		Scanner scanner = null;
		try {
			//add a single entry
			double ammount = 5.05f;
			assertEquals(recorder.recordCollectedTaxes(ammount), true);
			
			File file = new File(FILENAME);
			scanner = new Scanner(file);
			
			//make sure the entry counted towards today's totals, and with the correct ammount
			String line = scanner.nextLine();
			assertEquals(line, TaxRecorder.dateFormat.format(new Date()) + ":" + TaxRecorder.currencyFormatter.format(ammount));
		} catch (Exception e) {
			//should not have exceptions, fail
			fail(e.getClass() + e.getMessage());
		} finally {
			if(scanner != null)
				scanner.close();
		}
	}
	
	@Test
	public void testTwoEntries() {
		Scanner scanner = null;
		try {
			double first = 5.15f;
			double second = 1234.56f;
			//add two entries, both as the same day
			assertEquals(recorder.recordCollectedTaxes(first), true);
			assertEquals(recorder.recordCollectedTaxes(second), true);
			
			File file = new File(FILENAME);
			scanner = new Scanner(file);

			//entries should be added together and counted towards the same day
			String line = scanner.nextLine();
			assertEquals(line, TaxRecorder.dateFormat.format(new Date()) + ":" + TaxRecorder.currencyFormatter.format(first + second));
		} catch (Exception e) {
			//should not have exceptions, force an assertion fail
			assertEquals(true, false);
		} finally {
			//close open streams
			if(scanner != null)
				scanner.close();
		}
	}
	
	@Test
	public void testTwoEntriesSeparateDates() {
		Scanner scanner = null;
		try {
			double ammount1 = 1122.33;
			double ammount2 = 1029.38;
			
			//Need to create a manual entry first, as recordCollectedTaxes doesn't support setting the date.
			Date date = new Date(new Date().getTime() - 86400000);
			FileWriter writer = new FileWriter(FILENAME);
			writer.write(TaxRecorder.dateFormat.format(date) + ":" + TaxRecorder.currencyFormatter.format(ammount1));
			writer.close();
			
			assertEquals(recorder.recordCollectedTaxes(ammount2), true);
			
			File file = new File(FILENAME);
			scanner = new Scanner(file);

			String line = scanner.nextLine();
			assertEquals(line, TaxRecorder.dateFormat.format(date) + ":" + TaxRecorder.currencyFormatter.format(ammount1));
			line = scanner.nextLine();
			assertEquals(line, TaxRecorder.dateFormat.format(new Date()) + ":" + TaxRecorder.currencyFormatter.format(ammount2));
		} catch (Exception e) {
			//should not have exceptions, fail
			fail(e.getClass() + e.getMessage());
		} finally {
			//close open streams
			if(scanner != null)
				scanner.close();
		}
	}
	
	@Test
	public void testEntryWithZeroTax() {
		Scanner scanner = null;
		try {
			//add a single entry
			double ammount = 0.00f;
			assertEquals(recorder.recordCollectedTaxes(ammount), true);
			
			File file = new File(FILENAME);
			scanner = new Scanner(file);
			
			//make sure the entry counted towards today's totals, and with the correct ammount
			String line = scanner.nextLine();
			assertEquals(line, TaxRecorder.dateFormat.format(new Date()) + ":" + TaxRecorder.currencyFormatter.format(ammount));
		} catch (Exception e) {
			//should not have exceptions, fail
			fail(e.getClass() + e.getMessage());
		} finally {
			if(scanner != null)
				scanner.close();
		}
	}
}
