package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidBICException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidUPCException;

public class ProductDBTest {

	static final double EPSILON = 1e-15;
	ProductDB productDB;

	@Before
	public void setUp() throws Exception {
		productDB = new ProductDB();
	}

	@After
	public void tearDown() throws Exception {
		productDB.clearDatabase();
		productDB = null;
	}
	
	@Test
	public final void testInitialization() throws Exception{
		ProductDB pd = new ProductDB();
		//if the initialization data changes, the test cases must be remodified or
		//otherwise may fail.
		assertEquals(pd.lookUpItem("11111").getPrice(), 0.69, EPSILON);
		assertEquals(pd.lookUpItem("22222").getDescription(), "Orange");
		assertEquals(pd.lookUpItem("33333").getTaxRate(), 0, EPSILON);
		assertEquals(pd.lookUpItem("757551000842").getPrice(), 5, EPSILON);
		assertEquals(pd.lookUpItem("085392132225").getDescription(), "Oreo Cookies");
		assertEquals(pd.lookUpItem("786936224306").getTaxRate(), 0, EPSILON);
	}	
	
	@Test
	public final void testLookUpItem(){
		BulkProduct bulkProduct1, bulkProduct2, bulkProduct3 = null;
		PackagedProduct packagedProduct1, packagedProduct2, packagedProduct3 = null;
		BIC bic1, bic2, bic3 = null;
		UPC upc1, upc2, upc3 = null;
		try {
			bic1 = new BIC("11151");
			bic2 = new BIC("22252");
			bic3 = new BIC("33353");
			upc1 = new UPC("737751000743");
			upc2 = new UPC("717951000743");
			upc3 = new UPC("024543213611");
			
			bulkProduct1 = new BulkProduct("test1", 
					new TaxCategory(0.1f), bic1, 1);
			bulkProduct2 = new BulkProduct("test2", 
					new TaxCategory(0.2f), bic2, 2);
			bulkProduct3 = new BulkProduct("test3", 
					new TaxCategory(0.3f), bic3, 3);
			packagedProduct1 = new PackagedProduct("testa", new TaxCategory(0.4f), 
					upc1, 10, 40);
			packagedProduct2 = new PackagedProduct("testb", new TaxCategory(0.5f), 
					upc2, 20, 50);
			packagedProduct3 = new PackagedProduct("testc", new TaxCategory(0.6f), 
					upc3, 30, 60);
			
			productDB.addItem(bulkProduct1);
			productDB.addItem(bulkProduct2);
			productDB.addItem(bulkProduct3);
			productDB.addItem(packagedProduct1);
			productDB.addItem(packagedProduct2);
			productDB.addItem(packagedProduct3);
			
			assertEquals(productDB.lookUpItem(bic1.getCode()).getDescription(), "test1");
			assertEquals(productDB.lookUpItem(bic2.getCode()).getPrice(), 2, EPSILON);
			assertEquals(productDB.lookUpItem(bic3.getCode()).getTaxRate(), 0.3f, EPSILON);
			assertEquals(productDB.lookUpItem(upc1.getCode()).getDescription(), "testa");
			assertEquals(productDB.lookUpItem(upc2.getCode()).getPrice(), 20, EPSILON);
			assertEquals(productDB.lookUpItem(upc3.getCode()).getTaxRate(), 0.6f, EPSILON);
			
		} catch (InvalidBICException e) {
			fail("Invalid BIC");
		} catch (InvalidUPCException e) {
			fail("Invalid UPC");
		}

	}
	@Test
	public final void testAddItem() throws InvalidUPCException {
		BulkProduct bulkProduct = null;
		PackagedProduct packagedProduct = null;
		BIC bic = null;
		UPC upc =  null;
		try {
			//add a bulk and packaged product to DB
			bic = new BIC("12345");
			upc = new UPC("737751000743");
			bulkProduct = new BulkProduct("something1", new TaxCategory(0.135f), bic, 0.99);
			packagedProduct = new PackagedProduct("something2", new TaxCategory(0.135f), 
					upc, 2.13, 1.45);
			
			productDB.addItem(bulkProduct);
			productDB.addItem(packagedProduct);
		} catch (InvalidBICException e) {
			fail("Invalid BIC");
		}
		
		//test lookup on both items
		assertEquals(productDB.lookUpItem(bic.getCode()), bulkProduct);
		assertEquals(productDB.lookUpItem(upc.getCode()), packagedProduct);
	}

}
