package ca.utoronto.csc301.SelfCheckOut.IntegrationTests;

import static org.junit.Assert.assertEquals;

import java.util.Enumeration;

import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.App.CheckOutCart;
import ca.utoronto.csc301.SelfCheckOut.App.GroceryItem;
import ca.utoronto.csc301.SelfCheckOut.App.PackagedProduct;
import ca.utoronto.csc301.SelfCheckOut.App.TaxCategory;
import ca.utoronto.csc301.SelfCheckOut.App.UPC;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidUPCException;

public class CartWithPackagedProducts {
	
	static final double EPSILON = 1e-15;
	
	@Test
	public final void testAddingPackagedProducts() throws InvalidUPCException {
		CheckOutCart checkoutCart = new CheckOutCart();
		GroceryItem[] groceryItem = new GroceryItem[100];
		
		//sanity test on checkout cart, make sure it's completely empty
		assertEquals(checkoutCart.getTotalCost(), 0, EPSILON);
		assertEquals(checkoutCart.getTotalWeight(), 0, EPSILON);
		assertEquals(checkoutCart.getTotalTax(), 0, EPSILON);
		
		//create a few products
		for(int i = 0; i < 100; i++){
			PackagedProduct packagedProduct;
			UPC upc = new UPC("737751000842");
			packagedProduct = new PackagedProduct("desc", new TaxCategory(1.0f), upc, 1.0f, 1.0f);
			groceryItem[i] = new GroceryItem(packagedProduct, packagedProduct.getPrice(), packagedProduct.getWeight());
		}
		
		//add each item to the checkout cart
		for(int j = 0; j < 100; j++) {
			checkoutCart.addItemToCart(groceryItem[j]);
			assertEquals(checkoutCart.getTotalCost(), j + 1, EPSILON);
			assertEquals(checkoutCart.getTotalWeight(), j + 1, EPSILON);
			assertEquals(checkoutCart.getTotalTax(), j + 1, EPSILON);
		}
		
		//ensure each item was added successfully
		Enumeration<GroceryItem> cartItems = checkoutCart.listItems();
		while(cartItems.hasMoreElements()) {
			GroceryItem item = cartItems.nextElement();
			assertEquals(item.getInfo().getDescription(), "desc");
			assertEquals(item.getPrice(), 1.0f, EPSILON);
			assertEquals(item.getWeight(), 1.0f, EPSILON);
			assertEquals(item.getTax(), 1.0f, EPSILON);
		}
	}
}
