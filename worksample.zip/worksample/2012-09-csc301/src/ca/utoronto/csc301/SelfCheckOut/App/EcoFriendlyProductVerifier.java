package ca.utoronto.csc301.SelfCheckOut.App;

import java.io.FileWriter;
import java.util.Hashtable;
import java.util.Scanner;

/**
 * A verification class that is used to determine if a product is eco-friendly.
 * by checking if a product is recorded in EcoProduct.db. 
 * Format of each line in EcoProduct.db:
 * product code:why it is eco-friendly
 */
public class EcoFriendlyProductVerifier extends Database<String, String>{
	
	public EcoFriendlyProductVerifier(){
		super("EcoProduct.db");
	}
	
	/**
	 * Return true if the ProductCode is a BIC/UPC string code for a eco-friendly product.
	 * @param ProductCode the string for the product code (either BIC or UPC)
	 * @return true is this product is eco-friendly(by being in the Green Product DB),
	 * false otherwise
	 */
	public boolean isEcoFriendly(String ProductCode){
		return this.hashtable.containsKey(ProductCode);
	}

	@Override
	/**
	 * The key of the hash table is the product code. The value is the description
	 * on why this product is eco-friendly.
	 */
	protected Hashtable<String, String> restoreDatabase(Scanner scanner) {
		Hashtable<String, String> hashtable = new Hashtable<String, String>();

		while(scanner.hasNextLine()) {
			String line = scanner.nextLine();
			if(line.split(":").length == 2) {
				String code = line.split(":")[0];
				String ecoCommitment = line.split(":")[1];
				hashtable.put(code, ecoCommitment);
			} 
		}
		
		return hashtable;
	}

	@Override
	protected void addToDatabase(FileWriter writer, String key, String value) {
		//we are not using the method, so it is left blank.
		//we assume that data entering EcoProduct.db is done manually.
	}
}
