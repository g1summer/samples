package ca.utoronto.csc301.SelfCheckOut.Devices;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.App.SelfCheckOut;
import ca.utoronto.csc301.SelfCheckOut.App.UPC;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.BagWhileAddingException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidUPCException;

public class BaggingAreaTest {

	static final String code = "786936224306";
	static final double weight = 3.52;
	static final double EPSILON = 1e-15;
	
	static SelfCheckOut selfCheckout1, selfCheckout2;
	
	BaggingArea baggingArea;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		selfCheckout1 = new SelfCheckOut();
		selfCheckout2 = new SelfCheckOut();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		selfCheckout1 = null;
		selfCheckout2 = null;
	}

	@Before
	public void setUp() throws Exception {
		baggingArea = new BaggingArea();

	}

	@After
	public void tearDown() throws Exception {
		baggingArea = null;
		selfCheckout1.resetAll();
		selfCheckout2.resetAll();
	}

	@Test
	public void testNoObserversBaggingArea() {
		
		BaggingArea myBA = new BaggingArea();
		assertEquals(0.0f, myBA.getTotalWeight(), 0.0);
		try {
			myBA.changeWeight(0.0f); // try and see if this crashes the program
		} catch (Exception e) {
			fail("Bag while adding exception");
		}
	}

	@Test (expected = BagWhileAddingException.class)
	public void testOneObserverBaggingArea() throws BagWhileAddingException {

		assertEquals(0.0f, baggingArea.getTotalWeight(), 0.0); // new BaggingArea
		
		baggingArea.attach(selfCheckout1);
		selfCheckout1.baggingArea = baggingArea;
		
		baggingArea.changeWeight(0.0); // throws BagWhileAddingException

	}
	
	@Test (expected = BagWhileAddingException.class)
	public void testTwoObserverBaggingArea() throws BagWhileAddingException {

		assertEquals(0.0f, baggingArea.getTotalWeight(), 0.0); // new BaggingArea
		
		baggingArea.attach(selfCheckout1);
		baggingArea.attach(selfCheckout2);
		selfCheckout1.baggingArea = baggingArea;
		selfCheckout2.baggingArea = baggingArea;
		
		baggingArea.changeWeight(0.0); // throws BagWhileAddingException

	}
	
	@Test (expected = BagWhileAddingException.class)
	public void testOneObserverChangeWeightException() throws BagWhileAddingException {

		assertEquals(0.0f, baggingArea.getTotalWeight(), 0.0); // new BaggingArea
		
		baggingArea.attach(selfCheckout1);
		selfCheckout1.baggingArea = baggingArea;
		
		baggingArea.changeWeight(0.0); // throws BagWhileAddingException

	}
	
	@Test 
	public void testOneObserverChangeWeight() throws BagWhileAddingException {

		assertEquals(0.0f, baggingArea.getTotalWeight(), 0.0); // new BaggingArea
		
		baggingArea.attach(selfCheckout1);
		selfCheckout1.baggingArea = baggingArea;
		
		UPC upc;
		try {
			upc = new UPC(code);
			selfCheckout1.addItem(upc);
		} catch (InvalidUPCException e) {
			fail("Cannot construct UPC");
		} catch (Exception e1) {
			fail("Cannot do addItem");
		}
		
		baggingArea.changeWeight(weight);
		
		assertEquals(3.52, baggingArea.getTotalWeight(), EPSILON);
		assertEquals(3.52, selfCheckout1.getBaggingArea().getTotalWeight(), EPSILON);

	}
	
	@Test 
	public void testTwoObserversChangeWeight() throws BagWhileAddingException {

		assertEquals(0.0f, baggingArea.getTotalWeight(), 0.0); // new BaggingArea
		
		baggingArea.attach(selfCheckout1);
		baggingArea.attach(selfCheckout2);
		selfCheckout1.baggingArea = baggingArea;
		selfCheckout2.baggingArea = baggingArea;
		
		UPC upc;
		try {
			upc = new UPC(code);
			selfCheckout1.addItem(upc); selfCheckout2.addItem(upc); // add item in both selfcheckout instances
		} catch (InvalidUPCException e) {
			fail("Cannot construct UPC");
		} catch (Exception e1) {
			fail("Cannot do addItem");
		}
		
		
		baggingArea.changeWeight(weight);
		assertEquals(3.52, baggingArea.getTotalWeight(), EPSILON);
		assertEquals(3.52, selfCheckout1.getBaggingArea().getTotalWeight(), EPSILON);
		assertEquals(3.52, selfCheckout2.getBaggingArea().getTotalWeight(), EPSILON);

	}

	@Test
	public void testZeroWeight() throws BagWhileAddingException {
		
		assertEquals(0.0f, baggingArea.getTotalWeight(), 0.0); // new BaggingArea
		
		
		baggingArea.attach(selfCheckout1);
		selfCheckout1.baggingArea = baggingArea;
		
		UPC upc;
		try {
			upc = new UPC(code);
			selfCheckout1.addItem(upc);
		} catch (InvalidUPCException e) {
			fail("Cannot construct UPC");
		} catch (Exception e1) {
			fail("Cannot do addItem");
		}
		
		baggingArea.zeroWeight(); // reset weight to 0.0
		
		assertEquals(0.0, baggingArea.getTotalWeight(), EPSILON);
		assertEquals(0.0, selfCheckout1.getBaggingArea().getTotalWeight(), EPSILON);
	}

	@Test
	public void testAttachNull() {
		
		try {
			baggingArea.attach(null);
		} catch (Exception e) {
			fail("Program crashed trying to attach null");
		}
	}

	@Test
	public void testAttachOne() {
		
		try {
			baggingArea.attach(selfCheckout1);
		} catch (Exception e) {
			fail("Program crashed trying to attach one observer");
		}
	}

	@Test
	public void testAttachTwo() {
		
		try {
			baggingArea.attach(selfCheckout1);
			baggingArea.attach(selfCheckout2);
		} catch (Exception e) {
			fail("Program crashed trying to attach two observers");
		}
	}

}
