package ca.utoronto.csc301.SelfCheckOut.IntegrationTests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.Enumeration;

import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.App.BIC;
import ca.utoronto.csc301.SelfCheckOut.App.BulkProduct;
import ca.utoronto.csc301.SelfCheckOut.App.CheckOutCart;
import ca.utoronto.csc301.SelfCheckOut.App.GroceryItem;
import ca.utoronto.csc301.SelfCheckOut.App.TaxCategory;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidBICException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidUPCException;

public class CartWithBulkProducts {
	static final double EPSILON = 1e-15;
	
	@Test
	public final void testAddingBulkProducts() throws InvalidUPCException {
		CheckOutCart checkoutCart = new CheckOutCart();
		GroceryItem[] groceryItem = new GroceryItem[100];
		
		//sanity test on checkout cart, make sure it's completely empty
		assertEquals(checkoutCart.getTotalCost(), 0, EPSILON);
		assertEquals(checkoutCart.getTotalWeight(), 0, EPSILON);
		assertEquals(checkoutCart.getTotalTax(), 0, EPSILON);
		
		//create a few products
		for(int i = 0; i < 100; i++){
			BulkProduct bulkProduct;
			try {
				bulkProduct = new BulkProduct("desc", new TaxCategory(1.0f), new BIC("11111"), 1.0f);
				groceryItem[i] = new GroceryItem(bulkProduct, bulkProduct.getPrice(), 1.0f);
			} catch (InvalidBICException e) {
				fail("Invalid BIC");
			}
			
		}
		
		//add each item to the checkout cart
		for(int j = 0; j < 100; j++) {
			checkoutCart.addItemToCart(groceryItem[j]);
			assertEquals(checkoutCart.getTotalCost(), j + 1, EPSILON);
			assertEquals(checkoutCart.getTotalWeight(), j + 1, EPSILON);
			assertEquals(checkoutCart.getTotalTax(), j + 1, EPSILON);
		}
		
		//ensure each item was added successfully
		Enumeration<GroceryItem> cartItems = checkoutCart.listItems();
		while(cartItems.hasMoreElements()) {
			GroceryItem item = cartItems.nextElement();
			assertEquals(item.getInfo().getDescription(), "desc");
			assertEquals(item.getPrice(), 1.0f, EPSILON);
			assertEquals(item.getWeight(), 1.0f, EPSILON);
			assertEquals(item.getTax(), 1.0f, EPSILON);
		}
	}
}
