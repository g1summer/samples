package ca.utoronto.csc301.SelfCheckOut.Exceptions;


/**
 * An exception which is thrown when a user tries to bag an item while the
 * system expects them to add an item or pay.
 * 
 */
public class BagWhileAddingException extends IncorrectStateException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -128179995932223538L;

	public BagWhileAddingException() {
		super();
	}

	public BagWhileAddingException(String message) {
		super(message);
	}

	public BagWhileAddingException(String message, Throwable cause) {
		super(message, cause);
	}

	public BagWhileAddingException(Throwable cause) {
		super(cause);
	}
}
