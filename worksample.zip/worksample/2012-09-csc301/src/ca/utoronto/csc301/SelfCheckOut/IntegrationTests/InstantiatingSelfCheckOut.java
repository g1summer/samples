package ca.utoronto.csc301.SelfCheckOut.IntegrationTests;

import ca.utoronto.csc301.SelfCheckOut.App.*;

import ca.utoronto.csc301.SelfCheckOut.Devices.*;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class InstantiatingSelfCheckOut {

	SelfCheckOut selfCheckOut;
	BaggingArea baggingArea;
	ProductDB productDB;
	PreferredCustomerDB customerDB;
	DiscountDB discountDB;
	PaymentCollector paymentCollector;
		
	@Before
	public void setUp() throws Exception {
		
		//create a SelfCheckOut
		baggingArea = new BaggingArea();
		paymentCollector = new PaymentCollector();
		productDB = new ProductDB();
		customerDB = new PreferredCustomerDB();
		discountDB = new DiscountDB();

		selfCheckOut = new SelfCheckOut(baggingArea, paymentCollector, productDB, customerDB, discountDB);

	}

	@After
	public void tearDown() throws Exception {
		
		selfCheckOut = null;
		baggingArea = null;
		productDB = null;
		paymentCollector = null;
	}

	@Test
	public void instantiateSCOWithNoArgs() throws Exception {
		SelfCheckOut noArgSelfCheckOut;
		
		noArgSelfCheckOut = new SelfCheckOut();
		assertNotNull(noArgSelfCheckOut.getBaggingArea());
		assertNotNull(noArgSelfCheckOut.getProductDB());
		assertNotNull(noArgSelfCheckOut.getPaymentCollector());
			
	}

/*
 * Don't need this, because it's been called in the setUp
 * 
 * 	public void testSelfCheckOutBaggingAreaPaymentCollectorProductDB() {
		fail("Not yet implemented");
	}
*/


/*	
 * This is not implemented, because the notifyBaggingAreaEvent only changes
 * a private variable.
 * 
 * public void testNotifyBaggingAreaEvent() {
		fail("Not yet implemented");
	}
*/
	

	@Test
	public void gettingBaggingArea() {
		assertSame(baggingArea, selfCheckOut.getBaggingArea());
	}

	@Test
	public void gettingGetProductDB() {
		assertSame(productDB, selfCheckOut.getProductDB());
	}

	@Test
	public void gettingGetPaymentCollector() {
		assertSame(paymentCollector, selfCheckOut.getPaymentCollector());
	}

}
