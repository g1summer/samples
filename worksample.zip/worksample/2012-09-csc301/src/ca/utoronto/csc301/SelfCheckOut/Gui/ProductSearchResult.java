package ca.utoronto.csc301.SelfCheckOut.Gui;

import javax.swing.ImageIcon;

public class ProductSearchResult {
	
	private String productName;
	private String code;
	private ImageIcon image;
	
	/**
	 * This class is just a data wrapper used to send information from the database
	 * up to the GUI. 
	 */
	public ProductSearchResult(String productName, String code, ImageIcon image) {
		this.productName = productName;
		this.code = code;
		this.image = image;
	}
	
	public String getProductName() {
		return productName;
	}
	
	public String getCode() {
		return code;
	}
	
	public ImageIcon getImage() {
		return image;
	}

}
