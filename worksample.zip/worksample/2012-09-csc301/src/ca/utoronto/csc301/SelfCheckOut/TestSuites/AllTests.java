package ca.utoronto.csc301.SelfCheckOut.TestSuites;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({UnitTests.class, IntegrationTests.class})
public class AllTests {

}
