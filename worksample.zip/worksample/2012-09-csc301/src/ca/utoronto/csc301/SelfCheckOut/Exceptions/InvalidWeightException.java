package ca.utoronto.csc301.SelfCheckOut.Exceptions;

/**
 * An exception which is thrown when a bulk item with zero weight is
 * added to the checkoutcart 
 *
 */
public class InvalidWeightException extends Exception {
	private static final long serialVersionUID = 1L;

	public InvalidWeightException() {
		super();
	}

	public InvalidWeightException(String message) {
		super(message);
	}

	public InvalidWeightException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidWeightException(Throwable cause) {
		super(cause);
	}

}
