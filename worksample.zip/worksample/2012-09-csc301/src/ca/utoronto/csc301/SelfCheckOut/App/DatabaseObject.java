package ca.utoronto.csc301.SelfCheckOut.App;

public interface DatabaseObject {
	public void restoreObject(String str);
	public String saveObject();
}
