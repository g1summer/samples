/*
 * Creator: Susan Elliott Sim
 * 
 * Created on May 10, 2006
 * Updated on January 17, 2008, September 12, 2012
 * 
 * The PackagedProduct class is for products with a UPC code. It implements the ProductInfo interface.
 */

package ca.utoronto.csc301.SelfCheckOut.App;

import javax.swing.ImageIcon;

/**
 * A PackedProduct represents a single UPC-code-bearing product in the store.
 * Packaged products are sold as discrete single units, and never by weight.
 * Note the difference between 'items' and 'products':  A 'product' is a type
 * of good sold at the store, whereas an 'item' is a particular box of that
 * product.  
 *
 */
public class PackagedProduct implements ProductInfo {
	/**
	 * The UPC for this product. 
	 */
	private UPC myUPC;

	/**
	 * The price for a box of the product.
	 */
	private double myPrice;

	/**
	 * The estimated weight for a box of the product.
	 */
	private double myWeight;

	/**
	 * A text description of the product.
	 */
	private String myDescription;
	
	/**
	 * The tax category for this product
	 */
	private TaxCategory myCategory;

	/**
	 * The image for this product
	 */
	private ImageIcon image;
	
	/**
	 * empty constructor
	 */
	public PackagedProduct() {
		
	}
	/**
	 * This constructor stores all relevant details of the product, which can
	 * be retrieved using accessor methods. 
	 * @param descrip		A text description of the product.
	 * @param category		The tax category this product falls under.
	 * @param UPCcode		A unique 12-digit UPC code for the product.
	 * @param productCost	The cost of the product.
	 * @param productWeight	The estimated weight of the product.
	 */
	public PackagedProduct(String descrip, TaxCategory category, UPC UPCcode, double productCost,
			double productWeight) {
		myDescription = descrip;
		if (category == null) {
			myCategory = new TaxCategory(0.0);
		} else {
			myCategory = category;
		}
		myUPC = UPCcode;
		myPrice = productCost;
		myWeight = productWeight;
	}

	/**
	 * An accessor method which returns the unique UPC of the product.
	 */
	public UPC getUPC() {
		return myUPC;
	}
	
	/**
	 * An accessor method which returns the unique Code (UPC) of the product.
	 */
	public Code getCode() {
		return getUPC();
	}

	/**
	 * An accessor method which returns the price of the product.
	 */
	public double getPrice() {
		return myPrice;
	}

	/**
	 * An accessor method which returns the weight of the product.
	 */
	public double getWeight() {
		return myWeight;
	}

	/**
	 * An accessor method which returns the text description of the product.
	 */
	public String getDescription() {
		return myDescription;
	}

	/**
	 * An accessor method which returns the tax rate for the product
	 */
	public double getTaxRate() {
		return myCategory.getTaxRate();
	}

	/**
	 * restores an object from a database file line
	 */
	@Override
	public void restoreObject(String str) {
		String[] pieces = str.split(":");
		
		myDescription = pieces[0];
		myCategory = new TaxCategory(Double.parseDouble(pieces[1]));
		try {
			myUPC = new UPC(pieces[2]);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
		myPrice = Double.parseDouble(pieces[3]);
		myWeight = Double.parseDouble(pieces[4]);
		
		//If the database does not indicate an image to use, use the default
		if (pieces.length == 6) {
			image = new ImageIcon(getClass().getClassLoader().getResource(pieces[5]));
		} else {
			image = new ImageIcon(getClass().getClassLoader().getResource("default.jpg"));
		}
	}

	/**
	 * saves the object into a database file line
	 */
	@Override
	public String saveObject() {
		return myDescription + ":" + myCategory.getTaxRate() + ":" + myUPC.getCode() + ":" + myPrice + ":" + myWeight;
	}
	
	@Override
	public ImageIcon getImage() {
		return image;
	}
	
}
