package ca.utoronto.csc301.SelfCheckOut.App;

import java.util.Date;
import java.util.Calendar;

import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomer.Gender;

/*
 * The PCDiscount class stores information about store promotions that give
 * preferred customers percentage discounts based on their personal information
 */
public class PreferredCustomerDiscount implements DatabaseObject {
	
	// percentage discount in decimal form 
	private double discount;

	// The start and end dates of the promotion
	private Date startDate;
	private Date endDate;
	
	/* filters on personal info for customers accepted by promotion */
	
	// true if the current date must be the customer's birthday
	private boolean birthday;
	// The gender a customer must be to receive the promotion
	private Gender gender;
	// the customer's id must match this one
	private long id;
	// minimum age of accepted customer
	private int minAge;
	// maximum age of accepted customer
	private int maxAge;
	// the minimum number of years since the customer's join date
	private int minYears;
	
	/**
	 * empty constructor
	 */
	public PreferredCustomerDiscount() {
		
	}
	/*
	 * Create a PCDiscount object. If any field is null, it is not used as a
	 * filter.
	 */
	public PreferredCustomerDiscount(double discount,
					  Date startDate,
					  Date endDate,
					  boolean birthday,
					  Gender gender,
					  long id,
					  int minAge,
					  int maxAge,
					  int minYears) {
		this();
		
		this.discount = discount;
		this.startDate = startDate;
		this.endDate = endDate;
		this.birthday = birthday;
		this.gender = gender;
		this.id = id;
		this.minAge = minAge;
		this.maxAge = maxAge;
		this.minYears = minYears;

	}

	/*
	 * Takes a single preferred customer and returns whether this customer
	 * should receive this promotion
	 */
	public boolean accepted(PreferredCustomer pc, Date today) {
		
		if (startDate != null && (startDate.compareTo(today) > 0)) {
			return false;
		}
		
		if (endDate != null && (endDate.compareTo(today)) < 0) {
			return false;
		}
		
		if (birthday) {
			Calendar birthday = Calendar.getInstance();
			Calendar now = Calendar.getInstance();
			
			birthday.setTime(pc.getBirthday());
			now.setTime(today);
			
			if (now.get(Calendar.MONTH) != birthday.get(Calendar.MONTH) ||
					now.get(Calendar.DAY_OF_MONTH) != birthday.get(Calendar.DAY_OF_MONTH))
				return false;
		}
		
		if ((gender != null) && (pc.getGender() != gender)) {
			return false;
		}
		
		if ((id != 0) && (id != pc.getId())) {
			return false;
		}
		
		if (minAge != 0 || maxAge != 0) {
			
			/*Calculate the customers age*/
			Calendar dob = Calendar.getInstance();
			Calendar now = Calendar.getInstance();
			
			dob.setTime(pc.getBirthday());
			now.setTime(today);
			
			int year1 = now.get(Calendar.YEAR);
			int year2 = dob.get(Calendar.YEAR);
			
			int age = year1 - year2;
			
			int month1 = now.get(Calendar.MONTH);
			int month2 = dob.get(Calendar.MONTH);
			
			if (month2 > month1) {
				age--;
			} else if (month1 == month2) {
				int day1 = now.get(Calendar.DAY_OF_MONTH);
				int day2 = dob.get(Calendar.DAY_OF_MONTH);
				if (day2 > day1) {
				  age--;
			  }
			}
			
			if (minAge != 0 && age < minAge) {
				return false;
			}
			
			if (maxAge != 0 && age > maxAge) {
				return false;
			}
		}
		
		if (minYears != 0) {
			/*Calculate how long they've been a customer*/
			Calendar joinDate = Calendar.getInstance();
			Calendar now = Calendar.getInstance();
			
			joinDate.setTime(pc.getJoinDate());
			now.setTime(today);
			
			int year1 = now.get(Calendar.YEAR);
			int year2 = joinDate.get(Calendar.YEAR);
			
			int age = year1 - year2;
			
			int month1 = now.get(Calendar.MONTH);
			int month2 = joinDate.get(Calendar.MONTH);
			
			if (month2 > month1) {
				age--;
			} else if (month1 == month2) {
				int day1 = now.get(Calendar.DAY_OF_MONTH);
				int day2 = joinDate.get(Calendar.DAY_OF_MONTH);
				if (day2 > day1) {
				  age--;
			  }
			}
			
			if (age < minYears) {
				return false;
			}
		}
		
		return true;
	}
	
	public double getDiscount() {
		return discount;
	}
	
	public Date getStart() {
		return startDate;
	}
	
	public Date getEnd() {
		return endDate;
	}

	/**
	 * restores an object from a database file line
	 */
	@Override
	public void restoreObject(String str) {
		String[] peices = str.split(":");
		
		discount = Double.parseDouble(peices[0]);
		startDate = (peices[1].equals("null") ? null : new Date(Long.parseLong(peices[1])));
		endDate = (peices[2].equals("null") ? null : new Date(Long.parseLong(peices[2])));
		birthday = Boolean.parseBoolean(peices[3]);
		if(peices[4].equals("null"))
			gender = null;
		else if(peices[4].equals("M"))
			gender = Gender.MALE;
		else
			gender = Gender.FEMALE;
		id = Long.parseLong(peices[5]);
		minAge = Integer.parseInt(peices[6]);
		maxAge = Integer.parseInt(peices[7]);
		minYears = Integer.parseInt(peices[8]);
	}

	/**
	 * saves the object into a database file line
	 */
	@Override
	public String saveObject() {
		return 
				discount + 
				":" + (startDate == null ? "null" : startDate.getTime()) + 
				":" + (endDate == null ? "null" : endDate.getTime()) + 
				":" + birthday + 
				":" + (gender == null ? "null" : (gender == Gender.MALE ? "M" : "F")) + 
				":" + id + 
				":" + minAge + 
				":" + maxAge + 
				":" + minYears;
	}

}
