package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.*;

import java.util.Enumeration;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingArea;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingAreaEvent;
import ca.utoronto.csc301.SelfCheckOut.Devices.PaymentCollector;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.BagWhileAddingException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.IncorrectStateException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidBICException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidProductException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidUPCException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.StallCustomerException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidWeightException;


public class SelfCheckOutTest {
	
	static final double EPSILON = 1e-7;
	static final String UPC1 = "786936224306";
	static final String UPC2 = "717951000842";
	static final String BIC1 = "11111";
	static final String BIC2 = "22222";
	//the fake alert code for the fraudulent payment event.
	static int alertCode = 123;
	//the verbal description of the fraudulent payment event.
	static String alertMsg = "A fradulent payment is detected, " +
			"please detain the suspected customer at the" +
			"self check out area ASAP.";
	
	SelfCheckOut selfCheckOut;

	@Before
	public void setUp() throws Exception {
		try {
			selfCheckOut = new SelfCheckOut();
		} catch (Exception e) {
			fail("Cannot Initialize Constructor.");
		}
	}

	@After
	public void tearDown() throws Exception {
		selfCheckOut = null;
	}

	@Test
	public void testSelfCheckOutBaggingAreaPaymentCollectorProductDB() {
		
		BaggingArea bagging = new BaggingArea();
		ProductDB db = new ProductDB();
		PaymentCollector payment = new PaymentCollector();
		PreferredCustomerDB customerDB = new PreferredCustomerDB();
		DiscountDB discountDB = new DiscountDB();
		try {
			@SuppressWarnings("unused")
			SelfCheckOut selfcheckout = new SelfCheckOut(bagging, payment, db, customerDB, discountDB);	
		} catch (Exception e) {
			fail("Cannot Initialize Constructor.");
		}
		
	}
	
	@Test
	public void testOneAddItemUPC() throws Exception {
		UPC upc1 = new UPC(UPC1);
		
		GroceryItem item1 = selfCheckOut.addItem(upc1);
		
		//Make sure the item is in the cart
		assertTrue(selfCheckOut.listItemsInCart().nextElement().equals(item1));
		
		//Make sure the GroceryItem returned (and the one that we checked is in
		//the cart) is exactly the same as what we tried to add.
		
		assertTrue(item1.getInfo().getDescription().equals("Kellogg Cereal"));
		assertTrue(item1.getPrice() == 3.52);
		assertTrue(item1.getWeight() == 1.35);
		assertTrue(item1.getTax() == 0.0);
	}
	
	@Test
	public void testOneAddItemBIC() throws Exception {
		BIC bic1 = new BIC("13138");
		
		GroceryItem item1 = selfCheckOut.addItem(bic1, 2.6);
		
		//Make sure the item is in the cart
		assertTrue(selfCheckOut.listItemsInCart().nextElement().equals(item1));
		
		//Make sure the GroceryItem returned (and the one that we checked is in
		//the cart) is exactly the same as what we tried to add.
		
		assertTrue(item1.getInfo().getDescription().equals("Skor bits"));
		assertTrue(item1.getPrice() == 13.00);
		assertTrue(item1.getWeight() == 2.6);
		assertTrue(item1.getTax() == 6.5);
	}

	@Test
	public void testTwoAddItemUPC() throws Exception {
		BaggingAreaEvent myevent = new BaggingAreaEvent(1.35, 1.35);
		
		UPC upc1 = new UPC(UPC1);
		UPC upc2 = new UPC(UPC2);
		Enumeration<GroceryItem> egroceries;
		GroceryItem groceries; //egroceries iterator
		
		GroceryItem item1 = selfCheckOut.addItem(upc1); //First item
		//Notify BaggingAreaEvent for testing purposes
		selfCheckOut.notifyBaggingAreaEvent(selfCheckOut.getBaggingArea(), myevent);
		GroceryItem item2 = selfCheckOut.addItem(upc2); //Second item
		
		egroceries = selfCheckOut.listItemsInCart();
		groceries = egroceries.nextElement(); // start at first element in checkOutart
		
		assertTrue(groceries.equals(item1));
		groceries = egroceries.nextElement();
		assertTrue(groceries.equals(item2));
		
	}

	@Test (expected = InvalidWeightException.class)
	public void testOneZeroWeightAddItemBICDouble() throws Exception {
		
		BIC bic1 = new BIC(BIC1);
		
		@SuppressWarnings("unused")
		GroceryItem item1 = selfCheckOut.addItem(bic1, 0.0);
				
	}

	@Test
	public void testTwoNonZeroWeightAddItemBICDouble() throws Exception {
		BaggingAreaEvent myevent = new BaggingAreaEvent(5.0, 5.0);
		
		BIC bic1 = new BIC(BIC1);
		BIC bic2 = new BIC(BIC2);
		Enumeration<GroceryItem> egroceries;
		GroceryItem groceries; // egroceries iterator
		
		GroceryItem item1 = selfCheckOut.addItem(bic1, 5.0);
		//Notify BaggingAreaEvent for testing purposes
		selfCheckOut.notifyBaggingAreaEvent(selfCheckOut.getBaggingArea(), myevent);
		GroceryItem item2 = selfCheckOut.addItem(bic2, 1.0);
		
		egroceries = selfCheckOut.listItemsInCart();
		groceries = egroceries.nextElement(); //start at first element
		
		assertTrue(groceries.equals(item1));
		// 5.0 weight for item that costs 0.69 per unit weight.
		assertEquals(selfCheckOut.listItemsInCart().nextElement().getPrice(), 3.45, EPSILON);
		groceries = egroceries.nextElement();
		assertTrue(groceries.equals(item2));
		// 1.0 weight for item that costs 0.99
		assertEquals(groceries.getPrice(), 0.99, EPSILON);
		
	}
	
	@Test (expected = InvalidProductException.class)
	public void testAddNullUPCItem() throws IncorrectStateException, InvalidProductException, StallCustomerException {
		UPC upc = null;
		selfCheckOut.addItem(upc);
	}
	
	@Test (expected = InvalidProductException.class)
	public void testAddNullBICItem() throws IncorrectStateException, InvalidProductException, InvalidWeightException, StallCustomerException {
		BIC bic = null;
		selfCheckOut.addItem(bic, 2.6);
	}
	
	@Test (expected = InvalidProductException.class)
	public void testAddInvalidUPCItem() throws IncorrectStateException, InvalidProductException, StallCustomerException {
		UPC upc = null;
		
		try {
			upc = new UPC("012345678905");
		} catch (InvalidUPCException e) {
			fail("Invalid UPC");
		}
		
		selfCheckOut.addItem(upc);
		
	}
	
	@Test (expected = InvalidProductException.class)
	public void testAddInvalidBICItem() throws IncorrectStateException, InvalidProductException, InvalidWeightException, StallCustomerException {
		BIC bic = null;
		
		try {
			bic = new BIC("51236");
		} catch (InvalidBICException e) {
			fail("Invalid BIC");
		}
		
		selfCheckOut.addItem(bic, 2.2);
	}

	@Test
	public void testNoItemsGetTotalCost() {
		
		double cost = 0.0;
		assertFalse(selfCheckOut.listItemsInCart().hasMoreElements());
		assertEquals(cost, selfCheckOut.getTotalCost(), EPSILON);
		
	}

	@Test
	public void testOneItemGetTotalCost() throws Exception {
		
		BaggingArea bagging = new BaggingArea();
		PaymentCollector payment = new PaymentCollector();
		ProductDB db = new ProductDB();
		PreferredCustomerDB customerDB = new PreferredCustomerDB();
		DiscountDB discountDB = new DiscountDB();
		SelfCheckOut selfcheckout = new SelfCheckOut(bagging, payment, db, customerDB, discountDB);
		
		UPC upc1 = new UPC(UPC1);
		selfcheckout.addItem(upc1); //First item
		
		double cost = 3.52;
		
		assertEquals(cost, selfcheckout.getTotalCost(), EPSILON);
		
	}
	
	@Test
	public void testTwoItemGetTotalCost() throws Exception {
		BaggingAreaEvent myevent = new BaggingAreaEvent(1.35, 1.35);
		
		UPC upc1 = new UPC(UPC1); //Kellogg Cereal
		UPC upc2 = new UPC(UPC2); //Coca Cola (12 pack)
		
		selfCheckOut.addItem(upc1); //First item
		//Notify BaggingAreaEvent for testing purposes
		selfCheckOut.notifyBaggingAreaEvent(selfCheckOut.getBaggingArea(), myevent);
		selfCheckOut.addItem(upc2); //Second item
		
		double cost = 7.152f;
		
		assertEquals(cost, selfCheckOut.getTotalCost(), EPSILON);
		
	}

	@Test
	public void testReadyStateNotifyBaggingAreaEvent() throws Exception {
		
		boolean exceptionThrown = false;
		
		BaggingAreaEvent myevent = new BaggingAreaEvent(0.0, 0.0);
		SelfCheckOut selfcheckout = new SelfCheckOut(); // transactionState = READY
		try {
			selfcheckout.notifyBaggingAreaEvent(selfcheckout.getBaggingArea(), myevent);
		} catch (BagWhileAddingException e) {
			exceptionThrown = true;
		}
		
		assertTrue(exceptionThrown);
		
	}

	@Test
	public void testAddingStateNotifyBaggingAreaEvent() throws Exception {
		
		boolean exceptionThrown = false;
		
		BaggingAreaEvent myevent = new BaggingAreaEvent(0.0, 0.0);
		// transactionState = READY
		
		UPC upc = new UPC(UPC1);
		selfCheckOut.addItem(upc); //transactionState = BAGGING
		
		try {
			// Goes next after adding an item and goes from BAGGING TO ADDING state
			selfCheckOut.notifyBaggingAreaEvent(selfCheckOut.getBaggingArea(), myevent);
		} catch (Exception e) {
			fail("Failed to do notifyBaggingAreaEvent");
		}
		
		try {
			// Try notifying while in ADDING state
			selfCheckOut.notifyBaggingAreaEvent(selfCheckOut.getBaggingArea(), myevent);
		} catch (BagWhileAddingException e1) {
			exceptionThrown = true;
		}
		
		assertTrue(exceptionThrown);
		
	}
	
	@Test
	public void testBaggingStateNotifyBaggingAreaEvent() throws Exception {
		
		boolean exceptionThrown = true;
		
		BaggingAreaEvent myevent = new BaggingAreaEvent(0.0, 0.0);
		// transactionState = READY
		
		UPC upc = new UPC(UPC1);
		selfCheckOut.addItem(upc); //transactionState = BAGGING
		
		try {
			selfCheckOut.notifyBaggingAreaEvent(selfCheckOut.getBaggingArea(), myevent);
			exceptionThrown = false;
		} catch (Exception e) {
			fail("Failed to do notifyBaggingAreaEvent");
		}
		
		assertFalse(exceptionThrown);
		
	}
	
	@Test
	public void testPayForGroceries() throws Exception {
		UPC upc = new UPC(UPC1);
		GroceryItem item = selfCheckOut.addItem(upc); // Add an item to cart
		
		CheckOutCart payed;
		selfCheckOut.getPaymentCollector().setFraudChecker(new FakeFraudChecker());
		payed = selfCheckOut.payForGroceries();
		if (payed == null) {
			fail("Failed to execute payForGroceries");
		}
		
		// selfcheckout.checkOutCart has been reset after calling payForGroceries
		assertFalse(selfCheckOut.listItemsInCart().hasMoreElements());
		// payed checkout cart contains the previously payed item
		assertTrue(payed.listItems().nextElement().equals(item));
		
	}
	
	@Test
	public void testPayForGroceriesFraud() throws Exception {
		//Mannually construct SelfCheckOut mysco
		BaggingArea bagging = new BaggingArea();
		ProductDB db = new ProductDB();
		PreferredCustomerDB customerDB = new PreferredCustomerDB();
		DiscountDB discountDB = new DiscountDB();
		//initialize payment collector with a fraudulent payment
		FraudChecker fc = new FakeFraudChecker(true);
		PaymentCollector payment = new PaymentCollector(fc); //payment will be fraudulent
		SelfCheckOut mysco = new SelfCheckOut(bagging, payment, db, customerDB, discountDB);
		
		UPC upc = new UPC(UPC1);
		mysco.addItem(upc); // Add an item to cart
		
		boolean exceptionThrown = false;
		assertTrue(mysco.getPaymentCollector().getFraudChecker().hasFraud()); //fraud payment
		try {
			mysco.payForGroceries(); // attempt fraud payment
		} catch (StallCustomerException e) {
			exceptionThrown = true;
			assertTrue(mysco.inStallState());
		}
		assertTrue(exceptionThrown);
		// Now check for whether mysco has been alerted by AlertSystem.
		AlertSystem myAlertSystem = mysco.getAlertSystem();
		int myAlertCode = myAlertSystem.lastAlertCode();
		String myAlertMsg = myAlertSystem.getAlertMsg(myAlertSystem.numAlertReceived() - 1);
		assertTrue(myAlertCode == alertCode); //check if alert code has been received by mysco
		assertTrue(myAlertMsg == alertMsg); //check if alert msg has been received by mysco
		
	}

	@Test
	public void testEmptyCartResetAll() throws Exception {
		
		assertFalse(selfCheckOut.listItemsInCart().hasMoreElements()); // No items in cart
		selfCheckOut.resetAll();
		assertFalse(selfCheckOut.listItemsInCart().hasMoreElements()); // Still no items in cart
			
	}
	
	@Test
	public void testAddOneToCartResetAll() throws Exception {
		UPC upc = new UPC(UPC1);
		selfCheckOut.addItem(upc); // Add an item to cart
		

		assertTrue(selfCheckOut.listItemsInCart().hasMoreElements()); // has one item in cart 
		
		selfCheckOut.resetAll();
		assertFalse(selfCheckOut.listItemsInCart().hasMoreElements()); // has no more items in cart
		
	}

}
