package ca.utoronto.csc301.SelfCheckOut.IntegrationTests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Enumeration;

import ca.utoronto.csc301.SelfCheckOut.App.BIC;
import ca.utoronto.csc301.SelfCheckOut.App.CheckOutCart;
import ca.utoronto.csc301.SelfCheckOut.App.DiscountDB;
import ca.utoronto.csc301.SelfCheckOut.App.FakeFraudChecker;
import ca.utoronto.csc301.SelfCheckOut.App.GroceryItem;
import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomerDB;
import ca.utoronto.csc301.SelfCheckOut.App.ProductDB;
import ca.utoronto.csc301.SelfCheckOut.App.SelfCheckOut;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingArea;
import ca.utoronto.csc301.SelfCheckOut.Devices.PaymentCollector;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.AddWhileBaggingException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.AddWhilePayingException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.FraudulentPaymentException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.IncorrectStateException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidBICException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidProductException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.StallCustomerException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidWeightException;

public class CartWithNoItems {

	static SelfCheckOut selfCheckOut;
	static BaggingArea baggingArea;
	static ProductDB productDB;
	static PaymentCollector paymentCollector;
	static PreferredCustomerDB customerDB;
	static DiscountDB discountDB;

	@BeforeClass
	public static void classSetUp() throws Exception {
		//create a SelfCheckOut
		baggingArea = new BaggingArea();
		paymentCollector = new PaymentCollector();
		productDB = new ProductDB();
		customerDB = new PreferredCustomerDB();
		discountDB = new DiscountDB();

		selfCheckOut = new SelfCheckOut(baggingArea, paymentCollector, productDB, customerDB, discountDB);	
		paymentCollector.setFraudChecker(new FakeFraudChecker());
	}

	@AfterClass
	public static void classTearDown(){
		selfCheckOut = null;
		baggingArea = null;
		productDB = null;
		paymentCollector = null;
	}

	@After
	public void tearDown(){
		selfCheckOut.resetAll();
	}
	
	
	@Test
	public void listItemsInEmptyCart(){
		Enumeration<GroceryItem> egi;

		// there's nothing in the cart, so this should be null
		egi = selfCheckOut.listItemsInCart();
		assertFalse(egi.hasMoreElements());
		
	}

	@Test
	public void calculatingTotalCostOfEmptyCart() {
		assertEquals(0.0, selfCheckOut.getTotalCost(), 0.0);
	}
	
	@Test
	public void payingForNoGroceries() throws FraudulentPaymentException, StallCustomerException {	
		
		CheckOutCart coc;
		// test paying for empty grocery cart
		coc = selfCheckOut.payForGroceries();
		assertFalse(coc.listItems().hasMoreElements());
	}

	@Test
	public void addOneGroceryItem() throws StallCustomerException {
		GroceryItem gi;
		BIC firstBIC;
		double firstWeight;

		try {
			firstBIC = new BIC("11111");
			firstWeight = 2.61;
			gi = selfCheckOut.addItem(firstBIC, firstWeight); 
			
			assertNotNull(gi);
			assertEquals("Banana", gi.getInfo().getDescription());
			assertEquals(0.69, gi.getInfo().getPrice(), 0.0);
			
		} catch (AddWhileBaggingException awbe) {
			fail("Item scanned before previous item is bagged.");
		} catch (AddWhilePayingException awpe) {
			fail("Item scanned while payment is being processed");
		} catch (InvalidProductException ipe) {
			fail("Item not recognized.");
		} catch (IncorrectStateException ise) {
			fail("Invalid action for current state of Self Check Out.");
		} catch (InvalidBICException ibe) {
			fail("Invalid code for BIC.");
		} catch (InvalidWeightException zwe) {
			fail ("Invalid weight (0) for this item");
		}
	}

}
