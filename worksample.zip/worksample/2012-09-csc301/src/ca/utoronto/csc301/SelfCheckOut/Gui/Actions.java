/*
 * Creator: Rosalva Gallardo-Valencia
 * 
 * Created on Oct 2, 2008
 * Updated on Oct 6, 2008, September 12, 2012
 * 
 * The Actions class handles the actions that are called
 * from the Graphical User Interface for the Self CheckOut 
 * system. It includes actions such as: 
 * Start Transaction, Add a Packaged Item, Add a Bulk Item, 
 * Bag Item, and Pay for Items. Also, it includes an internal action
 * for printing the contents of the shopping cart.
 */
package ca.utoronto.csc301.SelfCheckOut.Gui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.FlowLayout;
import ca.utoronto.csc301.SelfCheckOut.App.BIC;
import ca.utoronto.csc301.SelfCheckOut.App.DiscountDB;
import ca.utoronto.csc301.SelfCheckOut.App.GroceryItem;
import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomer;
import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomerDB;
import ca.utoronto.csc301.SelfCheckOut.App.ProductDB;
import ca.utoronto.csc301.SelfCheckOut.App.SelfCheckOut;
import ca.utoronto.csc301.SelfCheckOut.App.UPC;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingArea;
import ca.utoronto.csc301.SelfCheckOut.Devices.PaymentCollector;
import ca.utoronto.csc301.SelfCheckOut.Devices.SoundSystem;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.FraudulentPaymentException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidInfoException;
/**
 * This class contains the actions that can be called from the Graphical User
 * Interface of the Self CheckOut System. It also includes an internal
 * action to print the contents of the shopping cart
 *
 */
public class Actions {
	//The Icon that holds thank you for save the environment animation/picture.
	ImageIcon icon = new ImageIcon(getClass().getClassLoader().getResource("thankyouforsave.gif"));
/**
 * Method that creates a new SelfCheckOut object that includes 
 * baggingArea, paymentCollector, and productDB objects
 * @return	new selfCheckOut object
 * @throws Exception
 */ 	
	protected SelfCheckOut start() throws Exception
	{
		SelfCheckOut selfCheckOut;
		BaggingArea baggingArea;
		ProductDB productDB;
		PreferredCustomerDB customerDB;
		DiscountDB discountDB;
		PaymentCollector paymentCollector;
		
		baggingArea = new BaggingArea();
		paymentCollector = new PaymentCollector();
		productDB = new ProductDB();
		customerDB = new PreferredCustomerDB();
		discountDB = new DiscountDB();
		selfCheckOut = new SelfCheckOut(baggingArea, paymentCollector, productDB, customerDB, discountDB);
		return selfCheckOut;
	}
	/**
	 * Method that creates a new UPC object with the universalProductCode
	 * given as parameter, then it adds the UPC to the selfCheckOut object.
	 * It returns the groceryItem that was added to the shopping cart
	 * @param selfCheckOut SelfCheckOut object where the Packaged Item will 
	 * be added
	 * @param universalProductCode String that contains the universal product
	 * code for the Packaged item
	 * @return	groceryItem that was added to the shopping cart
	 * @throws Exception
	 */ 	
	protected GroceryItem addUPC(SelfCheckOut selfCheckOut, String universalProductCode) throws Exception
	{
		UPC upc = new UPC(universalProductCode);
		GroceryItem groceryItem = selfCheckOut.addItem(upc);
		return groceryItem;	
	}
	/**
	 * Method that creates a new BIC object with the bulkItemCode
	 * given as parameter, then it adds the BIC to the selfCheckOut object indicating
	 * also the weight of the Bulk Item.
	 * It returns the groceryItem that was added to the shopping cart
	 * @param selfCheckOut SelfCheckOut object where the Bulk Item will 
	 * be added
	 * @param bulkItemCode String that contains the bulk item code for the
	 * Bulk Item
	 * @param weight Double number that contains the weight of the Bulk Item
	 * @return	groceryItem that was added to the shopping cart
	 * @throws Exception
	 */ 	
	protected GroceryItem addBIC(SelfCheckOut selfCheckOut, String bulkItemCode, double weight) throws Exception
	{
		BIC bic = new BIC(bulkItemCode);
		GroceryItem groceryItem = selfCheckOut.addItem(bic, weight);
		return groceryItem;	
	}
	/**
	 * Method that bags an item using the baggingArea object from the selfCheckOut object
	 * @param selfCheckOut SelfCheckOut object for the transaction
	 * @param groceryItem  GroceryItem that will be bagged
	 * @throws Exception
	 */ 
	protected void bagItem(SelfCheckOut selfCheckOut, GroceryItem groceryItem) throws Exception
	{
		BaggingArea baggingArea = selfCheckOut.getBaggingArea();
		baggingArea.changeWeight(groceryItem.getWeight());
	}
	
	protected ArrayList<ProductSearchResult> searchProductByText(SelfCheckOut selfCheckOut, String lookfor) {
		return selfCheckOut.getProductsByTextSearch(lookfor);
	}
	
	/**
	 * Method that collects the payment for all the groceries in the cart
	 * @param selfCheckOut SelfCheckOut object for the transaction
	 * @throws Exception
	 */ 	
	protected void payItems(SelfCheckOut selfCheckOut) throws FraudulentPaymentException, Exception
	{
		selfCheckOut.payForGroceries();
	}
	
	/**
	 * Try adding the current customer to the preferred customer database, and keep trying
	 * until the customer has entered valid information
	 * 
	 * @param sco SelfCheckOut object the customer is currently at
	 * @param message Message to show customer
	 */
	protected PreferredCustomer addPreferredCustomer(String message, SelfCheckOut sco, InvalidInfoException invalidInfo) {
		
		try {
			return showForm(message, sco, invalidInfo);
		} catch (InvalidInfoException iie) {
			SoundSystem.playSound(getClass(), "badbeep.wav");
			return addPreferredCustomer(iie.getMessage(), sco, iie);
		} catch (ParseException pe) {
			SoundSystem.playSound(getClass(), "badbeep.wav");
			return addPreferredCustomer("The date is formatted improperly",
					sco, null);
		}
		
	}
	
	/**
	 * Show the customer a form to enter information in so they can sign up as
	 * a preferred customer, then add their information to the database.
	 * 
	 * @param message Message to show the customer on the form
	 * @param sco the SelfCheckoutObject that the customer is at
	 * @param invalidInfo an InvalidInfoException that resulted from bad input
	 * @return
	 * @throws InvalidInfoException If the input was mal-formatted, throw this exception
	 * @throws ParseException If the date was not formatted correctly, throw this exception
	 */
	private PreferredCustomer showForm(String message, SelfCheckOut sco,
			InvalidInfoException invalidInfo) 
			throws InvalidInfoException, ParseException {
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
		Date today = sco.getDate();
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(today);
		
		Integer[] years = new Integer[120];
		Integer[] months = new Integer[12];
		Integer[] days = new Integer[31];
		
		for (int i = 0; i < 120; i++) {
			years[i] = cal.get(Calendar.YEAR) - i;
		}
		
		for (int i = 0; i < 31; i++) {
			days[i] = i + 1;
		}
		
		for (int i = 0; i < 12; i++) {
			months[i] = i + 1;
		}
		
		JComboBox year = new JComboBox(years);
		JComboBox month = new JComboBox(months);
		JComboBox day = new JComboBox(days);

		year.setSelectedIndex(0);
		month.setSelectedIndex(0);
		day.setSelectedIndex(0);
		
		JPanel dateSelect = new JPanel();
		dateSelect.setLayout(new FlowLayout());
		dateSelect.add(new JLabel("Year:"));
		dateSelect.add(year);
		dateSelect.add(new JLabel("Month:"));
		dateSelect.add(month);
		dateSelect.add(new JLabel("Day:"));
		dateSelect.add(day);
		
		// Text field for entering name
		JTextField nameField = new JTextField();
		
		// Combo box for selecting gender
		Object[] genders = {PreferredCustomer.Gender.MALE, PreferredCustomer.Gender.FEMALE};
		JComboBox genSelect = new JComboBox(genders);
		
		if (invalidInfo != null) {
			Date bd = invalidInfo.birthdate;
			cal.setTime (bd);
			
			year.setSelectedItem(cal.get(Calendar.YEAR));
			month.setSelectedItem(cal.get(Calendar.MONTH + 1));
			day.setSelectedItem(cal.get(Calendar.DAY_OF_MONTH));
			
			nameField.setText(invalidInfo.name);
			genSelect.setSelectedItem(invalidInfo.gender);
		}
		
		Object[] options = {"Submit", "Cancel"};
		Object[] messages = {message,
				" ",
				"Name:", nameField, 
				"Birthdate:", dateSelect, 
				"Gender:", genSelect,
				" "};
		
		int choice = JOptionPane.showOptionDialog(null, messages, 
				"Preferred Customer Registration Form", 
				JOptionPane.OK_CANCEL_OPTION, 
				JOptionPane.PLAIN_MESSAGE, 
				null, 
				options, 
				options[0]);
		
		if (choice == 0) {
			String dateString = day.getSelectedItem() + "/" +
					month.getSelectedItem() + "/" +
					year.getSelectedItem();
			Date birthdate = dateFormatter.parse(dateString);
			String name = nameField.getText();
			PreferredCustomer.Gender gender = (PreferredCustomer.Gender)genSelect.getSelectedItem();
			
			return sco.addPreferredCustomer(name, birthdate, gender);
		}
		
		return null;
	}
	
	/**
	 * Show the customer a confirmation screen when the signup form has been
	 * successfully completed.
	 * 
	 *@param pcid the customer id
	 */
	protected void showSuccess(long pcid) {
		
	    Object[] options = {"OK"};
		SoundSystem.playSound(getClass(), "applause.wav");
	    JOptionPane.showOptionDialog(null,
				("Thank you for registering for our preferred customer discount program!\n" +
				"Your preferred customer id is " + pcid + "."),"Confirmation",
               JOptionPane.PLAIN_MESSAGE,
               JOptionPane.INFORMATION_MESSAGE,
               null,
               options,
               options[0]);
	}
	
	/**
	 * Present the thank-you-for-saving-our-environment screen.
	 */
	protected void showThankYou(){
		icon.getImage().flush(); //flush the icon, so gif can be re-played normally, without stalling at the latest frame.
		icon = new ImageIcon(getClass().getClassLoader().getResource("thankyouforsave.gif"));
		JOptionPane.showMessageDialog(null, "", "", JOptionPane.INFORMATION_MESSAGE, icon);
	}
	
	/**
	 * Show a settings window to customize the font size and background color.
	 */
	protected Object[] showSettings(int fontIndex, PreferredCustomer customer) {
		
		Object[] settings = new Object[2]; //initialize settings list
		
		CustomColorChooser customColorChooser = new CustomColorChooser();
		
		int size = 19; //number of font sizes
		Integer[] fontSizes = new Integer[size];
		for (int i = 0; i < size; i++) {
			fontSizes[i] = 26 - i;
		}
		
		JComboBox fontSize = new JComboBox(fontSizes);
		fontSize.setSelectedIndex(fontIndex);
		
		JButton color = new JButton("Color");
		color.addActionListener(customColorChooser);
		
		JPanel fontsPane = new JPanel();
		fontsPane.setLayout(new FlowLayout());
		fontsPane.add(new JLabel("Size"));
		fontsPane.add(fontSize);
		
		JPanel colorsPane = new JPanel();
		colorsPane.setLayout(new FlowLayout());
		colorsPane.add(color);
		
		
		Object[] options = {"Save", "Cancel"};
		Object[] messages = {"Settings",
				" ", 
				"Font:", fontsPane, 
				"Background:", colorsPane,
				" "};
		
		
		int choice = JOptionPane.showOptionDialog(null, messages, 
				"Settings", 
				JOptionPane.OK_CANCEL_OPTION, 
				JOptionPane.PLAIN_MESSAGE, 
				null, 
				options, 
				options[0]);
		
		if ((choice == 0) && true) {
			// Save settings for Preferred Customer
			settings[0] = fontSize.getSelectedItem();
			
			settings[1] = customColorChooser.getColor();
			return settings;
		}
		return settings; 
		
		
	}
	
	/**
	 * Method that prints the contents of the shopping cart
	 * This method is called internally for the GUI class and does not
	 * correspond to any external GUI action
	 * @param listItemsInCart Enumeration of GroceryItems that are in the
	 * shopping cart
	 * @throws Exception
	 */ 	
    protected String printShoppingCart(Enumeration<GroceryItem> listItemsInCart) throws Exception
    {
    	String returnString = "\n";
    	int count = 0;
    	GroceryItem groceryItem;
    	String line;
    	while (listItemsInCart.hasMoreElements()) {
    		count++;
    		groceryItem = listItemsInCart.nextElement();
    		line = "" + count + ": ";
    		line += groceryItem.getInfo().getDescription();
    		line += " ";
    		line += groceryItem.getWeight();
    		line += "lb $";
    		line += String.format("%.2f", groceryItem.getPrice());
    		line += " + $";
    		line += String.format("%.2f", groceryItem.getTax());
    		line += " = $";
    		line += String.format("%.2f", groceryItem.getPrice() + groceryItem.getTax());
    		line += "\n";
    		returnString += line;
    		
    	}
    	return returnString;
    }
}
