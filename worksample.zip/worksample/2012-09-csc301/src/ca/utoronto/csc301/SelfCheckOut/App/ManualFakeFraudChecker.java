package ca.utoronto.csc301.SelfCheckOut.App;

public class ManualFakeFraudChecker implements FraudChecker{
	//another extremely simple fraud checker that is specially
	//designed to test stalling in GUI.
	//the uniqueness of this one is when ever it calls hasFraud()
	//it automatically adjust the index (by incrementing curpos) 
	//so when it calls hasFraud()
	//again it will return a value that has a different index in decisions.
	//So you can test for sequence of true/false fraud cases in GUI
	
	//to change fraud decision sequence, simply change the array below
	private boolean[] decisions = {false, true, false, true, false, true};
	int curpos = 0;
	
	public ManualFakeFraudChecker(){}
	public ManualFakeFraudChecker(boolean [] boos){
		decisions = boos;
	}
	
	//note that the visit to decisions is circular.
	
	//A special word on using this with SelfCheckOutGUI:
	//when SelfCheckOut is already in STALLING mode(means a fraud is detected,
	//and the SelfCheckOut has not been reset since that detection), if you
	//click pay under STALLING mode, hasFraud() will not be called, because
	//the machine will not perform any actions under STALLING mode
	//except to tell the customer to wait. So not only you will not get
	//any returns from hasFraud(), this also means if you click "pay"
	//under STALLING mode, curpos will not be updated (since hasFraud
	//is not called in this circumstances), so beware.
	
	//Also make sure you know how to exit STALLING mode from SelfCheckOutGUI,
	//that is enter "abcd" (stored resetCommand in SelfCheckOutGUI) 
	//in any text field and click any button after that.
	public boolean hasFraud(){
		boolean decision = decisions[curpos % decisions.length];
		curpos = (curpos + 1) % decisions.length;
		return decision;
	}
}
