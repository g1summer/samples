package ca.utoronto.csc301.SelfCheckOut.Devices;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

//import ca.utoronto.csc301.SelfCheckOut.App.AlertSystem;
//import ca.utoronto.csc301.SelfCheckOut.App.FakeAlertSystem;
import ca.utoronto.csc301.SelfCheckOut.App.FakeFraudChecker;
import ca.utoronto.csc301.SelfCheckOut.App.FraudChecker;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.FraudulentPaymentException;

public class PaymentCollectorTest {
	
	PaymentCollector pc;

	@Before
	public void setUp() throws Exception {
		try {
			pc = new PaymentCollector();
		} catch (Exception e) {
			fail("Failed to construct PaymentCollector");
		}
	}

	@After
	public void tearDown() throws Exception {
		pc = null;
	}
	
	@Test
	public void testCostructPaymentCollector() throws FraudulentPaymentException {
		PaymentCollector mypc = null;
		try {
			//AlertSystem fas = new FakeAlertSystem();
			FraudChecker fc = new FakeFraudChecker(false); //initialize false fc
			mypc = new PaymentCollector(fc);
		} catch (Exception e) {
			fail("Failed to construct PaymentCollector");
		}
		
		assertTrue(mypc != null);
	}
	
	@Test (expected = FraudulentPaymentException.class)
	public void testCostructPaymentCollectorFraudTrue() throws FraudulentPaymentException {
		//AlertSystem fas = new FakeAlertSystem();
		FraudChecker fc = new FakeFraudChecker(true); //initialize true fc
		PaymentCollector pc = new PaymentCollector(fc);
		double amount = 100;
		pc.collect(amount); //expected to throw FraudulentPaymentException
	}
	
	@Test
	public void testCollectZeroAmount() throws FraudulentPaymentException {
		double amount = 0; //assuming no amount is due.
		pc.setFraudChecker(new FakeFraudChecker());
		assertTrue(pc.collect(amount)); 
	}

	@Test
	public void testCollectPositiveAmountFraudFalse() throws FraudulentPaymentException {
		double amount = 100; //normal case; positive amount due
		//pc is initialized with fc = new FakeFraudChecker(false)
		pc.setFraudChecker(new FakeFraudChecker());
		assertTrue(pc.collect(amount));
	}
	
	@Test (expected = FraudulentPaymentException.class)
	public void testCollectPositiveAmountFraudTrue() throws FraudulentPaymentException {
		//AlertSystem fas = new FakeAlertSystem(); //create fake alert system for testing
		FraudChecker fc = new FakeFraudChecker(true); //initialize true fc
		PaymentCollector pc = new PaymentCollector(fc);
		double amount = 100; //normal case; positive amount due
		
		//expecting to throw FraudulentPaymentException
		pc.collect(amount);
	}
	
	@Test
	public void testCollectNegativeAmountFraudFalse() throws FraudulentPaymentException {
		double amount = -100; //give negative amount (negative balance)
		pc.setFraudChecker(new FakeFraudChecker());
		assertTrue(pc.collect(amount)); //since fc is initialized with false
	}
	
	@Test (expected = FraudulentPaymentException.class)
	public void testCollectNegativeAmountFraudTrue() throws FraudulentPaymentException {
		//AlertSystem fas = new FakeAlertSystem(); //create fake alert system for testing
		FraudChecker fc = new FakeFraudChecker(true); //initialize true fc
		PaymentCollector pc = new PaymentCollector(fc);
		double amount = -100; //give negative amount (negative balance)

		pc.collect(amount); //expecting to throw FraudulentPaymentException
	}

}
