package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class GroceryItemTest {
	
	static final double TAX_RATE1 = 0.1f;
	static final double TAX_RATE2 = 6.7f;
	static final double EPSILON = 1e-15;
	
	static PackagedProduct packagedProduct;
	static BulkProduct bulkProduct;
	static TaxCategory taxCategory1, taxCategory2;
	
	double price1 = 1.97, price2 = 25.16, weight1 = 7.8, weight2 = 90.4;
	GroceryItem groceryItem1, groceryItem2;
	String validCode = "012345678905";
	String des1 = "testpackageproduct", des2 = "testbulkproduct";
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		taxCategory1 = new TaxCategory(TAX_RATE1);
		taxCategory2 = new TaxCategory(TAX_RATE2);
		packagedProduct = new PackagedProduct("Oreo Cookies", taxCategory1, new UPC("727851000842"), 3.50, 0.8);
		bulkProduct = new BulkProduct("Fuji Apple", taxCategory2, new BIC("44444"), 2.79);
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		taxCategory1 = null;
		taxCategory2 = null;
		packagedProduct = null;
		bulkProduct = null;
	}

	@Before
	public void setUp() throws Exception {
		groceryItem1 = new GroceryItem(packagedProduct, price1, weight1);
		groceryItem2 = new GroceryItem(bulkProduct, price2, weight2);
	}

	@After
	public void tearDown() throws Exception {
		groceryItem1 = null;
		groceryItem2 = null;
	}

	@Test
	public final void testGetPrice() {
		//sanity test
		assertEquals(groceryItem1.getPrice(), price1, EPSILON);
		assertEquals(groceryItem2.getPrice(), price2, EPSILON);
	}

	@Test
	public final void testGetWeight() {
		//sanity test
		assertEquals(groceryItem1.getWeight(), weight1, EPSILON);
		assertEquals(groceryItem2.getWeight(), weight2, EPSILON);
	}

	@Test
	public final void testGetInfo() {
		//sanity test
		assertEquals(groceryItem1.getInfo(), packagedProduct);
		assertEquals(groceryItem2.getInfo(), bulkProduct);
	}
	
	@Test
	public final void testTaxRates() {
		//sanity test
		assertEquals(groceryItem1.getTax(), TAX_RATE1 * price1, EPSILON);
		assertEquals(groceryItem2.getTax(), TAX_RATE2 * price2, EPSILON);
	}

}
