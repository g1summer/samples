package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.*;

import org.junit.Test;

public class ManualFakeFraudCheckerTest {
	ManualFakeFraudChecker mffc, mffc2;

	@Test
	public void testManualFakeFraudCheckerBooleanArray() {
		//check if the constructor intializes the class
		//correctly.
		boolean[] boos = {true};
		mffc = new ManualFakeFraudChecker(boos);
		assertTrue(mffc.hasFraud());
		assertTrue(mffc.hasFraud());
	}
	
	@Test
	public void testHasFraud() {
		//check if hasFraud() returns correctly,
		//with true/false alternations, and to
		//see if it visits its sequence in correct order
		//and if the visit is circulatory.
		boolean[] boos2 = {true, false};
		mffc2 = new ManualFakeFraudChecker(boos2);
		assertTrue(mffc2.hasFraud());
		assertFalse(mffc2.hasFraud());
		assertTrue(mffc2.hasFraud());
		assertFalse(mffc2.hasFraud());
	}

}
