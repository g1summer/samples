package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.SimpleDateFormat;
import java.util.Enumeration;

import org.junit.Test;

public class DiscountDBTest {
	//if data in the DiscountDB.initializeTestDB() changes, then
	//test cases must be remodified as well, or otherwise may fail.
	
	static final double EPSILON = 1e-15;
	SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");

	@Test
	public void testInitializeTestDB() throws Exception {
		//To test the initialization of the test DB
		//by first initializing it and checks for the detail
		//of data it holds.
		DiscountDB ddb = new DiscountDB();
		Enumeration<PreferredCustomerDiscount> pcds = ddb.getAllItems();
		assertTrue(pcds.hasMoreElements());
	}

	@Test
	public void testGetAllItems() throws Exception {
		//use get all after initialize test db,
		//then check each element holds the correct detail
		//and there are correct number of elements.
		DiscountDB ddb2 = new DiscountDB();
		Enumeration<PreferredCustomerDiscount> pcds2 = ddb2.getAllItems();

		int numFive = 0;
		int numTwo = 0;
		int numOne = 0;
		while(pcds2.hasMoreElements()) {
			PreferredCustomerDiscount discount = pcds2.nextElement();
			
			if(numFive < 2 && discount.getDiscount() == 0.05)
				numFive++;
			else if(numTwo < 2 && discount.getDiscount() == 0.02)
				numTwo++;
			else if(numOne < 1 && discount.getDiscount() == 0.01)
				numOne++;
			else
				fail("Invalid discount in test database");
			if(numFive == 2 && numTwo == 2 && numOne == 1)
				break;
		}
		assertFalse(pcds2.hasMoreElements());
	}

}
