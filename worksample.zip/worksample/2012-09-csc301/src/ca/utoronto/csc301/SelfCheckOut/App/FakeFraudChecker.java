package ca.utoronto.csc301.SelfCheckOut.App;

import java.util.Vector;

//A fake fraud detector to test stall system
public class FakeFraudChecker implements FraudChecker{
	
	//for purpose of easier testing, position and decisions are left
	//public for testers to direct access.
	
	//position represents the index of boolean value
	//in decisions which hasFraud to return
	private int position;
	//decisions holds a list of fraudulent detection decisions
	//a false represents no fraud, a true represents a fraud
	private Vector<Boolean> decisions = new Vector<Boolean>();
	
	public FakeFraudChecker(){
		//by default, it is believed that there is no fraud.
		position = 0;
		decisions.add(false);
	}
	
	public FakeFraudChecker(boolean b){
		//you can specify an initial boolean element
		position = 0;
		decisions.add(b);
	}
	
	public FakeFraudChecker(Vector<Boolean> vb){
		//It is expected that vb must have at least 1 element.
		position = 0;
		for (Boolean x: vb){
			decisions.add(x);
		}
	}
	
	public boolean hasFraud(){
		return decisions.get(position);
	}
	
	public void setPosition(int i){
		//set the position where you want to read
		//the boolean from decisions.
		position = i;
	}
	
	public int getPosition(){
		//set the position where you want to read
		//the boolean from decisions.
		return position;
	}
	
	public void setFraud(boolean b){
		//set the boolean value at index specified by position
		decisions.set(position, b);
	}
	
	public int getSize(){
		//returns the size of decisions.
		return decisions.size();
	}
	
	public void incrementPosition(){
		//increment position by 1
		position += 1;
	}
	
}
