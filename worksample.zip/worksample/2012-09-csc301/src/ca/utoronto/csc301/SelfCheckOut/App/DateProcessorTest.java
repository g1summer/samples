package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

/**
 * Test class for the DateProcessor.
 */
public class DateProcessorTest{

	//The date formatter and the dates to be used in the test.
	private static SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");

	private static Date date1;
	private static Date date2;
	private static Date date3;
	private static Date date4;
	private static Date date5;
	
	@Test
	public void testMonthAndDateNumber() throws ParseException {
		//test if the DateProcessor.monthAndDateNumber returns the
		//correct month and date number.
		date1 = (Date) dateFormatter.parseObject("03/12/1990");
		date2 = (Date) dateFormatter.parseObject("03/12/2000");
		assertEquals(DateProcessor.monthAndDateNumber(date1)[0], DateProcessor.monthAndDateNumber(date2)[0]);
		assertEquals(DateProcessor.monthAndDateNumber(date1)[1], DateProcessor.monthAndDateNumber(date2)[1]);
	}

	@Test
	public void testHasTheSameMonthAndDate() throws ParseException {
		//test if the DateProcessor.hasTheSameMonthAndDate returns the correct
		//boolean value.
		date3 = (Date) dateFormatter.parseObject("10/17/1788");
		date4 = (Date) dateFormatter.parseObject("10/17/2333");
		assertTrue(DateProcessor.hasTheSameMonthAndDate(date3, date4));
		assertFalse(DateProcessor.hasTheSameMonthAndDate(date1, date3));
	}

	@Test
	public void testGetTodaysDate() throws ParseException {
		//test if the getTodaysDate returns the correct date of the
		//current day.
		date5 = DateProcessor.getTodaysDate();
		date5.equals(dateFormatter.parse(dateFormatter.format(Calendar.getInstance().getTime())));
	}

}
