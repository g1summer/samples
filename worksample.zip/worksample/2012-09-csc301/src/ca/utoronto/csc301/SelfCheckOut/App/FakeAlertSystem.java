package ca.utoronto.csc301.SelfCheckOut.App;

import java.util.Vector;

public class FakeAlertSystem implements AlertSystem{
	private Vector<Integer> alertCodeReceived = new Vector<Integer>();
	private Vector<String> alertMsgReceived = new Vector<String>();
	
	public void recieveAlert(int alertCode, String alertMsg){
		//an alert code is a numerical identification to what kind
		//of alert it is, alertMsg is a verbal description of the
		//alert.
		//this method stores the alert information recieved.
		alertCodeReceived.add(alertCode);
		alertMsgReceived.add(alertMsg);
	}
	
	public int getAlertCode(int i){
		//returns the alert code stored at index i 
		return alertCodeReceived.get(i);
	}
	
	public int numAlertReceived(){
		//returns the number of alerts recieved.
		return alertCodeReceived.size();
	}
	
	public int lastAlertCode(){
		//returns the latest alert code.
		if (alertCodeReceived.size() > 0) {
			return alertCodeReceived.get(alertCodeReceived.size() - 1);
		}
		return 0;
	}
	
	public String getAlertMsg(int i){
		//returns the alert message at index i.
		return alertMsgReceived.get(i);
	}
}
