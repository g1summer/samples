package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class PreferredCustomerTest {

	private static final String LOG_DIRECTORY = "junit";
	private static final String MARC_LOG_FILE = LOG_DIRECTORY + "/PreferredCustomer-10432381.txt";
	private static final String YAN_LOG_FILE = LOG_DIRECTORY + "/PreferredCustomer-25437122.txt";
	
	private static PreferredCustomerDB db;
	private CheckOutCart checkOutCart;
	private static PreferredCustomer marc;
	private static PreferredCustomer yan;
	private static PreferredCustomer jane;
	
	@BeforeClass
	public static void setUpClass() throws Exception {
		//Setup variables used in tests
		db = new PreferredCustomerDB();
		marc = db.lookUpItem(new Long(10432381));
		yan = db.lookUpItem(new Long(25437122));
		jane = db.lookUpItem(new Long(39847102));
		
		//create directory for junit log files to be put in
		File dir = new File(LOG_DIRECTORY);
		dir.mkdirs();
	}
	
	@Before
	public void setUp() {
		checkOutCart = new CheckOutCart();
	}
	
	@After
	public void tearDown() {
		//delete log files created by each test
		File marcFile = new File(MARC_LOG_FILE);
		File yanFile = new File(YAN_LOG_FILE);
		
		boolean marcDeleted = true;
		boolean yanDeleted = true;
		
		if(marcFile.exists())
			marcDeleted = marcFile.delete();
		if(yanFile.exists())
			yanDeleted = yanFile.delete();
		
		if(!marcDeleted)
			fail("Stream not closed on file " + MARC_LOG_FILE);
		if(!yanDeleted)
			fail("Stream not closed on file " + YAN_LOG_FILE);
	}
	
	@Test
	public void testLogEmptyCart() {
		//Make the preferred customer write a file, and then we open
		//the file ourselves to make sure it exists and has the correct info
		marc.logPurchases(checkOutCart, LOG_DIRECTORY);
		
		try {
			Scanner fileReader = new Scanner(new File(MARC_LOG_FILE));
			fileReader.close();
		} catch (FileNotFoundException e) {
			fail("File was not created");
		}
		
	}
	
	@Test
	//Test for null passed into logPurchases. No file should be created, nor anything added to it.
	public void testNullCart() {
		marc.logPurchases(null, LOG_DIRECTORY);
		File file = new File(MARC_LOG_FILE);
		if(file.exists())
			fail("File should not exist");
	}
	
	@Test
	//Tests the situations where we have 1, 2, 2+ all in one, because they are all basically the
	// same thing - no need for a separate test for each
	public void testMultiItemCart() {
		try {
			//Create item 1, and add to cart
			TaxCategory fruits = new TaxCategory(0.0f);
			BIC bic1 = new BIC("11111");
			BulkProduct bp1 = new BulkProduct("Banana", 
					fruits, bic1, 0.69);
			GroceryItem banana = new GroceryItem(bp1, 0.69, 1);
			checkOutCart.addItemToCart(banana);
	
			//Create item 2, and add to cart
			TaxCategory sweets = new TaxCategory(0.135f);
			UPC upc8 = new UPC("757551000842");
			PackagedProduct pp8 = new PackagedProduct("Ice Cream",
					sweets, upc8, 5.00, 2.0);
			GroceryItem iceCream = new GroceryItem(pp8, 5.00, 2.0);
			checkOutCart.addItemToCart(iceCream);
	
			//Create item 3, and add to cart
			TaxCategory quarter = new TaxCategory(0.25f);
			UPC upc5 = new UPC("727851000842");
			PackagedProduct pp5 = new PackagedProduct("Bacon",
					quarter, upc5, 5.50, 1.3);
			GroceryItem bacon = new GroceryItem(pp5, 5.50, 1.3);
			checkOutCart.addItemToCart(bacon);
		} catch (Exception e) {
			fail("Exception caught: " + e.getClass() + " :: " + e.getMessage());
		}
		
		//log all items in the cart, they should all be written to the user's
		// purchase history file
		yan.logPurchases(checkOutCart, LOG_DIRECTORY);
		
		Scanner fileReader = null;
		try {
			//Open user's purchase history file
			fileReader = new Scanner(new File(YAN_LOG_FILE));
			
			//First line is header
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
			assertTrue(fileReader.nextLine().equals("Date           " +
					"UPC/BIC Code      Weight       Price        Tax         "));
			//Second line is the banana
			assertTrue(fileReader.nextLine().equals(dateFormat.format(new Date()) + "    " +
					"11111             1.000        0.69         0.00        "));
			//Third is the ice cream
			assertTrue(fileReader.nextLine().equals(dateFormat.format(new Date()) + "    " +
					"757551000842      2.000        5.00         0.68        "));
			//And finally, fourth is the bacon
			assertTrue(fileReader.nextLine().equals(dateFormat.format(new Date()) + "    " +
					"727851000842      1.300        5.50         1.38        "));
		} catch (FileNotFoundException e) {
			fail("File was not created");
		} catch (Exception e) {
			fail("Exception caught: " + e.getClass() + " :: " + e.getMessage());
		} finally {
			//Be sure to close the stream, or we can't delete the file in cleanup
			if(fileReader != null)
				fileReader.close();
		}
	}
	
	@Test
	//Basic test of all gets for the class
	public void testAllGets() {
		SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
		
		//Go through both yan and jane, and check that all values are correct using all gets
		assertTrue(yan.getId() == 25437122);
		assertTrue(jane.getId() == 39847102);
		try {
			assertTrue(yan.getJoinDate().compareTo(dateFormatter.parse("09/15/2008")) == 0);
			assertTrue(jane.getJoinDate().compareTo(dateFormatter.parse("09/07/1988")) == 0);
			assertTrue(yan.getBirthday().compareTo(dateFormatter.parse("12/08/1990")) == 0);
			assertTrue(jane.getBirthday().compareTo(dateFormatter.parse("01/01/1950")) == 0);
		} catch (ParseException e) {
			fail("Error parsing date");
		}
		assertTrue(yan.getGender() == PreferredCustomer.Gender.MALE);
		assertTrue(jane.getGender() == PreferredCustomer.Gender.FEMALE);
		assertTrue(yan.getName().equals("Yan Garchteine"));
		assertTrue(jane.getName().equals("Jane Doe"));
	}
}
