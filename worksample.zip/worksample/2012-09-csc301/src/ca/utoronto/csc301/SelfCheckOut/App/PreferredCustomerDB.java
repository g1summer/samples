package ca.utoronto.csc301.SelfCheckOut.App;

import java.io.FileWriter;
import java.util.Hashtable;
import java.util.Scanner;

/**
 * The PreferredCustomerDB class encapsulates the list of preferred customers signed 
 * up at the store. In a real system, this would likely be a wrapper around a database 
 * of products which would be managed elsewhere.  In our sample system, we have a method 
 * which can provide a sample DB, and the capability to add items to the DB using an
 * addItem() method.
 *
 */
public class PreferredCustomerDB extends Database<Long, PreferredCustomer> {

	/**
	 * Constructs an empty database.
	 */
	public PreferredCustomerDB() {
		super("PrefCustomer.db");
	}
	
	/**
	 * Adds a preferred customer to the database
	 */
	public boolean addItem(PreferredCustomer customer) {
		return addItem(customer.getId(), customer);
	}
	
	/**
	 * Updates a preferred customer to the database
	 */
	public PreferredCustomer updateItem(PreferredCustomer customer, boolean isPersistent) {
		return updateItem(customer.getId(), customer, isPersistent);
	}
	
	/**
	 * Adds a preferred customer to the database
	 */
	public boolean addItem(PreferredCustomer customer, boolean isPersistent) {
		return addItem(customer.getId(), customer, isPersistent);
	}
	
	/**
	 * loads database contents from a file
	 */
	@Override
	protected Hashtable<Long, PreferredCustomer> restoreDatabase(Scanner scanner) {
		Hashtable<Long, PreferredCustomer> hashtable = new Hashtable<Long, PreferredCustomer>();
		
		while(scanner.hasNextLine()) {
			String line = scanner.nextLine();
			String[] lines = line.split(";");
			
			long key = Long.parseLong(lines[0]);
			
			PreferredCustomer customer = new PreferredCustomer();
			customer.restoreObject(lines[1]);
			
			hashtable.put(key, customer);
		}

		return hashtable;
	}

	/**
	 * Adds a single database item from a file
	 */
	@Override
	protected void addToDatabase(FileWriter writer, Long key, PreferredCustomer value) {
		try {
			writer.write(value.saveObject() + String.format("%n"));
		} catch (Exception e) {
			
		}
	}
}
