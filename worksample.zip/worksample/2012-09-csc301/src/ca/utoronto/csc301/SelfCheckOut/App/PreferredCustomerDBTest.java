package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.*;

import java.awt.Color;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.*;

import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomer.Gender;

public class PreferredCustomerDBTest {
	
	private PreferredCustomerDB db;
	private static Object[] settings;
	private static PreferredCustomer c1;
	private static Date c1JoinDate;
	private static Date c1BirthDate;
	private static PreferredCustomer c2;
	private static Date c2JoinDate;
	private static Date c2BirthDate;
	private static PreferredCustomer c3;
	private static Date c3JoinDate;
	private static Date c3BirthDate;
	private static PreferredCustomer c4;
	private static Date c4JoinDate;
	private static Date c4BirthDate;
	private static PreferredCustomer c5;
	private static Date c5JoinDate;
	private static Date c5BirthDate;

	@BeforeClass
	public static void classSetUp() throws ParseException {
		SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
		settings = new Object[2];
		
		//general settings
		settings[0] = 12f;
		settings[1] = Color.WHITE;
		
		c1JoinDate = dateFormatter.parse("01/01/2012");
		c1BirthDate = dateFormatter.parse("01/01/1990");
		
		c1 =  new PreferredCustomer(1, c1JoinDate, c1BirthDate,
				Gender.MALE, "Jack", settings);
		
		c2JoinDate = dateFormatter.parse("02/02/2012");
		c2BirthDate = dateFormatter.parse("02/02/1990");
		
		c2 = new PreferredCustomer(2, c2JoinDate, c2BirthDate,
				Gender.FEMALE, "Jane", settings);
		
		c3JoinDate = dateFormatter.parse("03/03/2012");
		c3BirthDate = dateFormatter.parse("03/03/1990");
		
		c3 = new PreferredCustomer(3, c3JoinDate, c3BirthDate,
				Gender.MALE, "Jonah", settings);
		
		c4JoinDate = dateFormatter.parse("04/04/2012");
		c4BirthDate = dateFormatter.parse("04/04/1990");

		c4 = new PreferredCustomer(4, c4JoinDate, c4BirthDate,
				Gender.FEMALE, "Jennah", settings);
		
		c5JoinDate = dateFormatter.parse("05/05/2012");
		c5BirthDate = dateFormatter.parse("12/25/0000");
		
		c5 = new PreferredCustomer(5, c5JoinDate, c5BirthDate,
				Gender.MALE, "Jesus", settings);
	}
	
	@Before
	public void setUp() {
		db = new PreferredCustomerDB();
	}
	
	@After
	public void tearDown() {
		db.clearDatabase();
		db = null;
	}
	
	@Test
	public void testAddDuplicateCustomer() {		
		//Should only be able to add a customer once
		assertTrue(db.addItem(c1));
		assertFalse(db.addItem(c1));
	}
	
	@Test
	public void testAddCustomerWithDuplicateID() {
		//More specific test than AddDuplicateCustomer, since we shouldn't
		//be able to add the same ID twice regardless of if the customer is duplicated
		assertTrue(db.addItem(c1));
		PreferredCustomer c6 = new PreferredCustomer(1, c1JoinDate, c2BirthDate, Gender.MALE,
				"Test Testerson", settings);
		assertFalse(db.addItem(c6));
	}
	
	//Makes sure that two customer objects have the same information
	private void compareCustomers(PreferredCustomer firstCustomer,
			PreferredCustomer secondCustomer) {
		assertTrue(firstCustomer.getId() == secondCustomer.getId());
		assertTrue(firstCustomer.getJoinDate().equals(secondCustomer.getJoinDate()));
		assertTrue(firstCustomer.getBirthday().equals(secondCustomer.getBirthday()));
		assertTrue(firstCustomer.getGender() == secondCustomer.getGender());
		assertTrue(firstCustomer.getName().equals(secondCustomer.getName()));
	}
	
	/* The adding item and looking up item tests are very dependent on each other
	 * (have to add an item to test looking it up, and have to look up an item to
	 * test that it was added properly). Therefore, although it goes against
	 * conventional unit testing style, we will test both at once in this method
	 * */	
	@Test
	public void testAddAndLookUpItem() {
		PreferredCustomer retrievedCustomer;
		//Empty DB right now, so test adding one item to an empty database
		assertTrue(db.addItem(c1));
		
		//Try to retrieve the item to make sure it was added correctly
		retrievedCustomer = db.lookUpItem(c1.getId());
		compareCustomers(c1, retrievedCustomer);
		
		//Now add another item
		assertTrue(db.addItem(c2));
		
		//Try to retrieve both items
		retrievedCustomer = db.lookUpItem(c1.getId());
		compareCustomers(c1, retrievedCustomer);
		retrievedCustomer = db.lookUpItem(c2.getId());
		compareCustomers(c2, retrievedCustomer);
		
		//Add a few more items just in case
		assertTrue(db.addItem(c3));
		assertTrue(db.addItem(c4));
		assertTrue(db.addItem(c5));
		
		//Try to retrieve all items, in a "random" order, make sure we can get them all
		retrievedCustomer = db.lookUpItem(c4.getId());
		compareCustomers(c4, retrievedCustomer);
		retrievedCustomer = db.lookUpItem(c2.getId());
		compareCustomers(c2, retrievedCustomer);
		retrievedCustomer = db.lookUpItem(c1.getId());
		compareCustomers(c1, retrievedCustomer);
		retrievedCustomer = db.lookUpItem(c5.getId());
		compareCustomers(c5, retrievedCustomer);
		retrievedCustomer = db.lookUpItem(c3.getId());
		compareCustomers(c3, retrievedCustomer);
	}
	
	@Test
	public void testInitializeTestDB() {
		try {
			PreferredCustomer retrievedCustomer;
			
			//Set up the items we want to find
			SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");

			Date septEight = dateFormatter.parse("09/08/1988");
			Date septSeven = dateFormatter.parse("09/07/1988");
			Date decEight = dateFormatter.parse("12/08/1990");
			Date yanJoin = dateFormatter.parse("09/15/2008");
			Date janeBirth = dateFormatter.parse("01/01/1950");
			
			//ID, JoinDate, BirthDate, Gender, Name
			PreferredCustomer marc = new PreferredCustomer(10432381, septEight, septSeven, Gender.MALE, "Marc Ashman", settings);
			PreferredCustomer yan = new PreferredCustomer(25437122, yanJoin, decEight, Gender.MALE, "Yan Garchteine", settings);
			PreferredCustomer jane = new PreferredCustomer(39847102, septSeven, janeBirth, Gender.FEMALE, "Jane Doe", settings);
			
			//Make sure we can find all the items we expect to find,
			//and that their fields are stored correctly
			retrievedCustomer = db.lookUpItem(new Long(10432381));
			compareCustomers(marc, retrievedCustomer);
			retrievedCustomer = db.lookUpItem(new Long(25437122));
			compareCustomers(yan, retrievedCustomer);
			retrievedCustomer = db.lookUpItem(new Long(39847102));
			compareCustomers(jane, retrievedCustomer);
			
			//Make sure we can still add more items after initializing
		} catch (Exception e) {
			fail(e.toString());
		}
	}
}
