package ca.utoronto.csc301.SelfCheckOut.Exceptions;

public class ItemsNotFoundInDataBaseException extends Exception {
	private static final long serialVersionUID = 1L;

	public ItemsNotFoundInDataBaseException() {
		super();
	}

	public ItemsNotFoundInDataBaseException(String message) {
		super(message);
	}

	public ItemsNotFoundInDataBaseException(String message, Throwable cause) {
		super(message, cause);
	}

	public ItemsNotFoundInDataBaseException(Throwable cause) {
		super(cause);
	}
}
