package ca.utoronto.csc301.SelfCheckOut.TestSuites;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import ca.utoronto.csc301.SelfCheckOut.App.BICTest;
import ca.utoronto.csc301.SelfCheckOut.App.BulkProductTest;
import ca.utoronto.csc301.SelfCheckOut.App.CheckOutCartTest;
import ca.utoronto.csc301.SelfCheckOut.App.DatabaseTest;
import ca.utoronto.csc301.SelfCheckOut.App.DateProcessorTest;
import ca.utoronto.csc301.SelfCheckOut.App.DiscountDBTest;
import ca.utoronto.csc301.SelfCheckOut.App.FakeAlertSystemTest;
import ca.utoronto.csc301.SelfCheckOut.App.FakeFraudCheckerTest;
import ca.utoronto.csc301.SelfCheckOut.App.GroceryItemTest;
import ca.utoronto.csc301.SelfCheckOut.App.ManualFakeFraudCheckerTest;
import ca.utoronto.csc301.SelfCheckOut.App.PackagedProductTest;
import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomerDBTest;
import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomerDiscountTest;
import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomerTest;
import ca.utoronto.csc301.SelfCheckOut.App.ProductDBTest;
import ca.utoronto.csc301.SelfCheckOut.App.SelfCheckOutTest;
import ca.utoronto.csc301.SelfCheckOut.App.TaxCategoryTest;
import ca.utoronto.csc301.SelfCheckOut.App.TaxRecorderTest;
import ca.utoronto.csc301.SelfCheckOut.App.UPCTest;
import ca.utoronto.csc301.SelfCheckOut.App.UtilsTest;
import ca.utoronto.csc301.SelfCheckOut.App.SignUpValidatorTest;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingAreaEventTest;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingAreaTest;
import ca.utoronto.csc301.SelfCheckOut.Devices.PaymentCollectorTest;


@RunWith(Suite.class)
@SuiteClasses({ 
	BICTest.class, 
	BulkProductTest.class,
	CheckOutCartTest.class,
	DatabaseTest.class,
	DiscountDBTest.class,
	FakeAlertSystemTest.class,
	FakeFraudCheckerTest.class,
	GroceryItemTest.class, 
	ManualFakeFraudCheckerTest.class,
	PackagedProductTest.class,
	ProductDBTest.class,
	PreferredCustomerTest.class,
	PreferredCustomerDBTest.class,
	PreferredCustomerDiscountTest.class,
	SelfCheckOutTest.class, 
	TaxCategoryTest.class, 
	TaxRecorderTest.class,
	UPCTest.class,
	UtilsTest.class, 
	BaggingAreaEventTest.class,
	BaggingAreaTest.class,
	PaymentCollectorTest.class,
	SignUpValidatorTest.class,
	DateProcessorTest.class})

public class UnitTests {

}
