package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Before;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidInfoException;

public class SignUpValidatorTest {
	
	static PreferredCustomer.Gender gen;
	static Date today;
	static Date bdate;
	static String name;
	static PreferredCustomerDB db;
	
	@BeforeClass
	public static void setUpClass() {
		// Set today's date to January 1, 2000
		Calendar now = Calendar.getInstance();
		now.clear();
		now.set(2000, 0, 1);
		today = now.getTime();
	}
	
	@Before
	public void setUp() {
		// Initialize the customer database
		db = new PreferredCustomerDB();
	}
	
	/**
	 * Test whether the validator constructs the proper PreferredCustomer
	 * object from the given information in the case where it is valid.
	 * 
	 */
	@Test
	public void testValidInfo() {
		setUpJohnDoe();
		
		try {
			PreferredCustomer pc = SignUpValidator.validateForm(today, bdate, name, gen, db);
			
			assertEquals("birthdate mismatch", bdate, pc.getBirthday());
			assertEquals("joindate mismatch", today,  pc.getJoinDate());
			assertEquals("name mismatch", name, pc.getName());
			assertEquals("gender mismatch", gen, pc.getGender());
		} catch (Exception e) {
			fail(e.getMessage());
		}
		
		
	}
	
	/**
	 * Test a thousand different randomly generated id numbers to make 
	 * sure they fit within the specified range and are all unique
	 * 
	 */
	@Test
	public void testValidID() {
		setUpJohnDoe();
		
		try {
			for (int i = 0; i < 1e3; i++) {
				PreferredCustomer pc = SignUpValidator.validateForm(today, bdate, name, gen, db);
				long id = pc.getId();
				
				assertTrue("invalid id number: " + id, ((id >= 0) && (id < 100000000)));
				assertTrue("non-unique id number: " + id, db.addItem(pc));
			}
		} catch (Exception e) {
			fail(e.getMessage());
		}
		
		
	}
	
	/**
	 * Test to make sure validator throws exception when the customer is impossibly old
	 * 
	 * @throws InvalidInfoException
	 */
	@Test (expected = InvalidInfoException.class)
	public void testAgeTooOld() throws InvalidInfoException {
		setUpJaneDoe();
		
		SignUpValidator.validateForm(today, bdate, name, gen, db);
	}
	
	/**
	 * Test to make sure validator throws exception when the customer is too young
	 * 
	 * @throws InvalidInfoException
	 */
	@Test (expected = InvalidInfoException.class)
	public void testAgeTooYoung() throws InvalidInfoException {
		setUpJaneDoe();
		
		Calendar temp = Calendar.getInstance();
		temp.set(1990, 0, 1);
		bdate = temp.getTime();
		
		SignUpValidator.validateForm(today, bdate, name, gen, db);
	}
	
	/**
	 * Test to make sure validator throws exception when a name has not been entered
	 * 
	 * @throws InvalidInfoException
	 */
	@Test (expected = InvalidInfoException.class)
	public void testNoName() throws InvalidInfoException {
		setUpJaneDoe();
		
		name = "";
		
		SignUpValidator.validateForm(today, bdate, name, gen, db);
	}
	
	/**
	 * Test to make sure validator throws exception when the given name is too long
	 * 
	 * @throws InvalidInfoException
	 */
	@Test (expected = InvalidInfoException.class)
	public void testNameTooLong() throws InvalidInfoException {
		setUpJaneDoe();
		
		name = "*******************************";
		
		SignUpValidator.validateForm(today, bdate, name, gen, db);
	}
	
	private void setUpJohnDoe() {
		Calendar temp = Calendar.getInstance();
		temp.set(1980, 0, 1);
		bdate = temp.getTime();
		name = "John Doe";
		gen = PreferredCustomer.Gender.MALE;
	}
	
	private void setUpJaneDoe() {
		Calendar temp = Calendar.getInstance();
		temp.set(1875, 0, 1);
		bdate = temp.getTime();
		name = "Jane Doe";
		gen = PreferredCustomer.Gender.FEMALE;
	}

}
