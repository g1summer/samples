package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.*;

import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomer.Gender;

public class PreferredCustomerDiscountTest {
	
	private static PreferredCustomerDB db = new PreferredCustomerDB();
	private PreferredCustomerDiscount discount;
	private static SimpleDateFormat dateFormatter;
	private static Date startDate;
	private static Date endDate;
	private static Date tooEarly;
	private static Date tooLate;
	private static Date justRight;
	private static long[] validIDs = {10432381, 25437122, 39847102};
		
	@BeforeClass
	public static void setUpClass() throws Exception {
		dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
		startDate = dateFormatter.parse("09/01/2012");
		endDate = dateFormatter.parse("09/30/2012");
		tooEarly = dateFormatter.parse("08/31/2012");
		tooLate = dateFormatter.parse("10/01/2012");
		justRight = dateFormatter.parse("09/15/2012");		
	}
	
	@After
	public void tearDown() {
		discount = null;
	}
	
	//Should be able to initialize valid discount without problems
	@Test
	public void testInitialize() throws ParseException {
		
		discount = new PreferredCustomerDiscount(0.05,
									startDate,
									endDate,
									false,
									null,
									18030918,
									65,
									70,
									0);
	}
	
	//Should handle null values
	@Test
	public void testInitializeWithNulls() {
				
		discount = new PreferredCustomerDiscount(0.00,
									null,
									null,
									false,
									null,
									0,
									0,
									0,
									0);
	}
	
	@Test
	public void testAllNullAccept() {
		//If the discount has all null values, any customer/date combination
		//should be ok to receive the discount
		
		discount = new PreferredCustomerDiscount(0, null, null, false, null,
				0, 0, 0, 0);
		
		for (int i = 0; i < validIDs.length; i++) {
			assertTrue(discount.accepted(db.lookUpItem(validIDs[i]), tooEarly));
			
			assertTrue(discount.accepted(db.lookUpItem(validIDs[i]), tooLate));
			
			assertTrue(discount.accepted(db.lookUpItem(validIDs[i]), justRight));
		}
	}
	
	@Test
	public void testExpiredSaleReject() throws ParseException {
		//Sale is over, so the discount should be rejected
	
		discount = new PreferredCustomerDiscount(0.05, startDate, endDate, false, null,
				0, 0, 0, 0);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), tooLate));
	}
	
	@Test
	public void testExpiredSaleNullStartReject() throws ParseException {
		//Sale is over, discount should be rejected and a null start date value
		//should not affect this
		
		discount = new PreferredCustomerDiscount(0.05, null, endDate, false, null,
				0, 0, 0, 0);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), tooLate));
	}
	
	@Test
	public void testUpComingSaleReject() throws ParseException {
		//Sale hasn't started yet so it shouldn't be applied
		
		discount = new PreferredCustomerDiscount(0.05, startDate, endDate, false, null,
				0, 0, 0, 0);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), tooEarly));
	}
	
	@Test
	public void testUpComingSaleNullEndReject() throws ParseException {
		//Sale hasn't started yet and the end date format shouldn't matter
				
		discount = new PreferredCustomerDiscount(0.05, startDate, null, false, null,
				0, 0, 0, 0);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), tooEarly));
	}
	
	@Test
	public void testOngoingSaleAccept() throws ParseException {
		//Sale is happening on the date we give it so it should be applied
		
		discount = new PreferredCustomerDiscount(0.05, startDate, endDate, false, null,
				0, 0, 0, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
	}
	
	@Test
	public void testOngoingSaleNullStartAccept() {
		//Null start value indicates that any date up until the end date is valid,
		//so we the discount should be accepted
		
		discount = new PreferredCustomerDiscount(0.05, null, endDate, false, null,
				0, 0, 0, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), tooEarly));
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
	}
	
	@Test
	public void testOngoingSaleNullEndAccept() {
		//Same as last test case, except for the end value
		
		discount = new PreferredCustomerDiscount(0.05, startDate, null, false, null,
				0, 0, 0, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), tooLate));
	}
	
	@Test
	public void testOneDaySale() {
		//Edge case, make sure a one day sale works like any other sale
		
		discount = new PreferredCustomerDiscount(0.05, startDate, startDate, false, null,
				0, 0, 0, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), startDate));
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), endDate));
	}
	
	
	@Test
	public void testBirthdaySaleAccept() throws ParseException {
		//If we're offering a sale to customers on their birthday and it's their
		//birthday, we should accept
		Date birthday = dateFormatter.parse("12/08/2012");
		
		discount = new PreferredCustomerDiscount(0.05, null, null, true, null,
				0, 0, 0, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), birthday));
		
	}
	
	@Test
	public void testBirthdaySaleReject() throws ParseException {
		//If we're offering a sale to customers on their birthday and it's not
		//their birthday, we should reject. 
		Date wrongday = dateFormatter.parse("12/09/2012");
		
		discount = new PreferredCustomerDiscount(0.05, null, null, true, null,
				0, 0, 0, 0);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), wrongday));
		
	}
	
	@Test
	public void testGenderSaleAccept() {
		//Make sure males get accepted for sales targeted to males, and females
		//get accepted for sales targeted to females
		
		//Female sale
		discount = new PreferredCustomerDiscount(0.05, null, null, false, Gender.FEMALE,
				0, 0, 0, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[2]), justRight));
		
		//Male sale
		discount = new PreferredCustomerDiscount(0.05, null, null, false, Gender.MALE,
				0, 0, 0, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
		assertTrue(discount.accepted(db.lookUpItem(validIDs[0]), justRight));
	}
	
	@Test
	public void testGenderSaleReject() {
		//Make sure we reject appropriately if a sale is targetted toward a certain
		//gender
		
		//Female sale
		discount = new PreferredCustomerDiscount(0.05, null, null, false, Gender.MALE,
				0, 0, 0, 0);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[2]), justRight));
		
		//Male sale
		discount = new PreferredCustomerDiscount(0.05, null, null, false, Gender.FEMALE,
				0, 0, 0, 0);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
		assertFalse(discount.accepted(db.lookUpItem(validIDs[0]), justRight));
		
	}
	
	@Test
	public void testIDSaleAccept() {
		//Make sure if we have a sale for a particular person that they get accepted
		//for that discount
		
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				validIDs[1], 0, 0, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
	}
	
	@Test
	public void testIDSaleReject() {
		//Make sure if a sale is for a particular person, someone else
		//doesn't get it
		
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				validIDs[2], 0, 0, 0);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
	}
	
	@Test
	public void testMinAndMaxAgeAccept() {
		//Make sure if the customer fits the targeted age range for the sale,
		//they are accepted
		
		//On the lower bound
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 62, 85, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[2]), justRight));
		
		//In the middle
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 40, 85, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[2]), justRight));
		
		//On the upper bound
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 25, 62, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[2]), justRight));
	}
	
	@Test
	public void testMinAndMaxAgeRejectOver() {
		//Make sure a customer older than the maximum age does not get accepted
		
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 50, 61, 0);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[2]), justRight));
	}
	
	@Test
	public void testMinAndMaxAgeRejectUnder() {
		//Make sure a customer younger than the maximum age does not get accepted
		
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 22, 65, 0);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
	}
	
	@Test
	public void testMinAndNullMaxAccept() {
		//Make sure if only a min age is specified and a customer meets the requirement
		//they get the discount
		
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 22, 0, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[2]), justRight));
	}
	
	@Test
	public void testMinAndNullMaxReject() {
		//Make sure if only a min age is specified and a customer does not meet
		//the requirement they do not get the discount
		
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 22, 0, 0);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
	}
	
	@Test
	public void testMaxAndNullMinAccept() {
		//If min is null and customer is under the max age we should accept
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 0, 61, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
	}
	
	@Test
	public void testMaxAndNullMinReject() {
		//If min is null and customer is over the max age we should reject
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 0, 61, 0);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[2]), justRight));
	}
	
	@Test
	public void testMinAndMaxAgeOnBirthday() throws ParseException {
		
		Date twentyBDay = dateFormatter.parse("12/08/2010");
		Date twentyOneBDay = dateFormatter.parse("12/08/2011");
		
		//Today is the day they meet the minimum age requirement (birthday),
		//so we should accept
				
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 20, 20, 0);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), twentyBDay));
		
		//Today is the first day they stop meeting the maximum age requirement
		//(birthday), so we should reject
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), twentyOneBDay));
	}
	
	@Test
	public void testMinAndMaxAgeDayAdjacentToBirthday() throws ParseException {

		Date beforeTwentyBDay = dateFormatter.parse("12/07/2010");
		Date beforeTwentyOneBDay = dateFormatter.parse("12/07/2011");
		
		//Day before they meet the requirement, so we should reject
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 20, 20, 0);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), beforeTwentyBDay));
		
		//Last day the customer meets the requirement, so we should accept
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), beforeTwentyOneBDay));
	}
		
	@Test
	public void testMinYearsAccept() throws ParseException {
		//If a customer has been a preferred customer for enough years, we should
		//accept
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 0, 0, 3);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
		
	}
	
	@Test
	public void testMinYearsReject() {
		//If a customer has not been a preferred customer for enough years,
		//we should reject
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 0, 0, 6);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
		
	}
	
	@Test
	public void testDayOfMinYears() {
		//Customer should be able to receive a minimum year discount on the
		//correct anniversary of their join date
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 0, 0, 4);
		
		assertTrue(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
	}
	
	@Test
	public void testDayBeforeMinYears() throws ParseException {
		//Customer should not be able to receive a minimum year discount
		//before the correct anniversary of their join date
		
		Date dayBefore = dateFormatter.parse("09/14/2012");
		
		discount = new PreferredCustomerDiscount(0.05, null, null, false, null,
				0, 0, 0, 4);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), dayBefore));
	}
	
	@Test
	public void testAllCategoriesAccept() {
		//Make sure if a sale is extremely specific (which won't happen in practice,
		//but this is a good sanity check), we accept someone who meets all the
		//criteria
		
		discount = new PreferredCustomerDiscount(0.05, startDate, endDate, true,
				Gender.MALE, validIDs[1], 20, 22, 3);
		
		assertFalse(discount.accepted(db.lookUpItem(validIDs[1]), justRight));
	}
	
	@Test
	public void testAllCategoriesRejectOne() throws ParseException {
		//Make sure if a sale is extremely specific and any one thing about a customer
		//doesn't fit, we reject
		Date birthday = dateFormatter.parse("01/01/2012");
		Date earlyStartDate = dateFormatter.parse("01/01/2012");
		discount = new PreferredCustomerDiscount(0.05, earlyStartDate, endDate, true,
				Gender.FEMALE, validIDs[2], 60, 64, 23);
		//Sanity check: customer should fit all those criteria, double check
		//that that's true and then start making exactly one field wrong at a time
		assertTrue(discount.accepted(db.lookUpItem(validIDs[2]), birthday));		
		
		//Before Sale Starts
		Date before = dateFormatter.parse("01/01/2011");
		assertFalse(discount.accepted(db.lookUpItem(validIDs[2]), before));
		
		//After Sale Ends
		Date after = dateFormatter.parse("01/01/2013");
		assertFalse(discount.accepted(db.lookUpItem(validIDs[2]), after));
		
		//Not Birthday
		Date notBirthday = dateFormatter.parse("01/02/2012");
		assertFalse(discount.accepted(db.lookUpItem(validIDs[2]), notBirthday));
		
		//Wrong Gender
		discount = new PreferredCustomerDiscount(0.05, earlyStartDate, endDate, true,
				Gender.MALE, validIDs[2], 61, 62, 23);
		assertFalse(discount.accepted(db.lookUpItem(validIDs[2]), birthday));
		
		//Wrong ID
		discount = new PreferredCustomerDiscount(0.05, earlyStartDate, endDate, true,
				Gender.FEMALE, validIDs[0], 61, 62, 23);
		assertFalse(discount.accepted(db.lookUpItem(validIDs[2]), birthday));
		
		//Too Young
		discount = new PreferredCustomerDiscount(0.05, earlyStartDate, endDate, true,
				Gender.FEMALE, validIDs[2], 60, 61, 23);
		assertFalse(discount.accepted(db.lookUpItem(validIDs[2]), birthday));
		
		//Too Old
		discount = new PreferredCustomerDiscount(0.05, earlyStartDate, endDate, true,
				Gender.FEMALE, validIDs[2], 63, 64, 23);
		assertFalse(discount.accepted(db.lookUpItem(validIDs[2]), birthday));
		
		//Hasn't been a customer long enough
		discount = new PreferredCustomerDiscount(0.05, earlyStartDate, endDate, true,
				Gender.FEMALE, validIDs[2], 61, 62, 24);
		assertFalse(discount.accepted(db.lookUpItem(validIDs[2]), birthday));
	}
	
}
