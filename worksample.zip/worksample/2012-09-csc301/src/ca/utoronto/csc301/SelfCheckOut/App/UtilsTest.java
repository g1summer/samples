package ca.utoronto.csc301.SelfCheckOut.App;

import ca.utoronto.csc301.SelfCheckOut.App.Utils;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.FraudulentPaymentException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.IncorrectStateException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidProductException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.StallCustomerException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidWeightException;
import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class UtilsTest {
	
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	static BIC bic;
	static UPC upc;
	static String bicDescription;
	static double bicCost;
	static String upcDescription;
	static double upcCost;
	static double upcWeight;
	static ProductDB DB;
	static TaxCategory tax;
	static SelfCheckOut selfCheckOut;
	static boolean success;
	
	@BeforeClass
	public static void setUpClass() throws Exception {
		bic = new BIC("11311");
		bicDescription = "Banana";
		bicCost = 0.69;
		upc = new UPC("024543213611");
		upcDescription = "Ice Cream";
		upcCost = 4.00;
		upcWeight = 2.2;
		tax = new TaxCategory(0.135);
		
		selfCheckOut = new SelfCheckOut();
	}
	
	@Before
	public void setUp() throws Exception {
		DB = new ProductDB();
		DB.clearDatabase();
		System.setOut(new PrintStream(outContent));
		success = false;
		
	}
	
	@After
	public void tearDown() {
		DB.clearDatabase();
		DB = null;
	    System.setOut(null);
	}
	
	@Test
	public void printEmptyDatabase() {
		
		String expectedStringWindows = 
			"There are 0 items in the database." + String.format("%n") +
			"*** Below is a list of products currently in the database.***" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n");
		
		Utils.printDB(DB.getAllItems());
		
		assertTrue(expectedStringWindows.equals(outContent.toString()));
	}
	
	@Test
	public void printDatabaseWithOneUPCItem() {
				
		DB.addItem(new PackagedProduct(upcDescription, tax, upc, upcCost, upcWeight));
		
		String expectedStringWindows = 
			"There are 1 items in the database." + String.format("%n") +
			"*** Below is a list of products currently in the database.***" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n") +
			"Product description: Ice Cream" + String.format("%n") +
			"UPC: 024543213611" + String.format("%n") +
			"Cost: 4.0" + String.format("%n") +
			"Tax Rate: 0.135" + String.format("%n") +
			"Weight: 2.2" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n");
		
		Utils.printDB(DB.getAllItems());
		
		assertTrue(expectedStringWindows.equals(outContent.toString()));
	}
	
	@Test
	public void printDatabaseWithOneBICItem() {
				
		DB.addItem(new BulkProduct(bicDescription, tax, bic, bicCost));
		
		String expectedStringWindows = 
			"There are 1 items in the database." + String.format("%n") +
			"*** Below is a list of products currently in the database.***" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n") +
			"Product description: Banana" + String.format("%n") +
			"BIC: 11311" + String.format("%n") +
			"Unit Cost: 0.69" + String.format("%n") +
			"Tax Rate: 0.135" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n");
		
		Utils.printDB(DB.getAllItems());
		assertTrue(expectedStringWindows.equals(outContent.toString()));
		
	}
	
	@Test
	public void printDatabaseWithMultipleItems() {
				
		DB.addItem(new PackagedProduct(upcDescription, tax, upc, upcCost, upcWeight));
		DB.addItem(new BulkProduct(bicDescription, tax, bic, bicCost));
		
		String expectedString = 
			"There are 2 items in the database." + String.format("%n") +
			"*** Below is a list of products currently in the database.***" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n") +
			"Product description: Banana" + String.format("%n") +
			"BIC: 11311" + String.format("%n") +
			"Unit Cost: 0.69" + String.format("%n") +
			"Tax Rate: 0.135" + String.format("%n") +
			"Product description: Ice Cream" + String.format("%n") +
			"UPC: 024543213611" + String.format("%n") +
			"Cost: 4.0" + String.format("%n") +
			"Tax Rate: 0.135" + String.format("%n") +
			"Weight: 2.2" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n");
		String expectedStringOther = 
			"There are 2 items in the database." + String.format("%n") +
			"*** Below is a list of products currently in the database.***" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n") +
			"Product description: Ice Cream" + String.format("%n") +
			"UPC: 024543213611" + String.format("%n") +
			"Cost: 4.0" + String.format("%n") +
			"Tax Rate: 0.135" + String.format("%n") +
			"Weight: 2.2" + String.format("%n") +
			"Product description: Banana" + String.format("%n") +
			"BIC: 11311" + String.format("%n") +
			"Unit Cost: 0.69" + String.format("%n") +
			"Tax Rate: 0.135" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n");
		
		Utils.printDB(DB.getAllItems());
		success = expectedString.equals(outContent.toString()) ||
					expectedStringOther.equals(outContent.toString());
		
		assertTrue(success);
		
	}
	
	@Test
	public void printCartWithNoItems() throws FraudulentPaymentException, StallCustomerException {
		String expectedStringWindows = 
				"*** Below is a list of products you have added: ***" + String.format("%n") +
				"-------------------------------------------------------" + String.format("%n") +
				"---- TOTAL: $0.00" + String.format("%n") +
				"-------------------------------------------------------" + String.format("%n");
		
		String expectedStringOther = 
				"*** Below is a list of products you have added: ***" + String.format("%n") +
				"-------------------------------------------------------" + String.format("%n") +
				"---- TOTAL: $0.00" + String.format("%n") +
				"-------------------------------------------------------" + String.format("%n");
		selfCheckOut.getPaymentCollector().setFraudChecker(new FakeFraudChecker());
		Utils.printCart(selfCheckOut.payForGroceries());
		
		success = expectedStringWindows.equals(outContent.toString()) ||
				expectedStringOther.equals(outContent.toString());
	
		assertTrue(success);
	
	}
	
	@Test
	public void printCartWithOneBICItem() throws IncorrectStateException, InvalidProductException, InvalidWeightException, FraudulentPaymentException, StallCustomerException {
		
		selfCheckOut.getProductDB().addItem(new BulkProduct(bicDescription, tax, bic, bicCost));
		selfCheckOut.addItem(bic, 2.5);
		
		String expectedStringWindows =
			"*** Below is a list of products you have added: ***" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n") +
			"Product description: Banana" + String.format("%n") +
			"BIC: 11311" + String.format("%n") +
			"Unit Cost: 0.69" + String.format("%n") +
			"Tax Rate: 0.135" + String.format("%n") +
			"Weight: 2.5" + String.format("%n") +
			"Total Cost: $1.96" + String.format("%n") +
			String.format("%n") +
			"---- TOTAL: $1.96" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n");
		
		//make sure the Fraud Checker is set to always return false, so it will not 
		//mess up our tests.
		selfCheckOut.getPaymentCollector();
		Utils.printCart(selfCheckOut.payForGroceries());
	
		assertTrue(expectedStringWindows.equals(outContent.toString()));
	
	}
	
	@Test
	public void printCartWithUPCItem() throws IncorrectStateException, InvalidProductException, FraudulentPaymentException, StallCustomerException {
		selfCheckOut.getProductDB().addItem(new PackagedProduct(upcDescription, tax, upc, upcCost, upcWeight));
				
		selfCheckOut.addItem(upc);		
		
		String expectedStringWindows = 
			"*** Below is a list of products you have added: ***" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n") +
			"Product description: Ice Cream" + String.format("%n") +
			"UPC: 024543213611" + String.format("%n") +
			"Cost: $4.00" + String.format("%n") +
			"Tax Rate: 0.135" + String.format("%n") +
			"Weight: 2.2" + String.format("%n") +
			"Total Cost: $4.54" + String.format("%n") +
			String.format("%n") +
			"---- TOTAL: $4.54" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n");
		
		Utils.printCart(selfCheckOut.payForGroceries());
	
		assertTrue(expectedStringWindows.equals(outContent.toString()));
	}
	
	@Test
	public void printCartWithMultipleItems() throws IncorrectStateException, InvalidProductException, InvalidWeightException, FraudulentPaymentException, StallCustomerException {
		
		selfCheckOut.getProductDB().addItem(new PackagedProduct(upcDescription, tax, upc, upcCost, upcWeight));
		selfCheckOut.getProductDB().addItem(new BulkProduct(bicDescription, tax, bic, bicCost));
		
		selfCheckOut.addItem(upc);
		selfCheckOut.baggingArea.changeWeight(1);
		selfCheckOut.addItem(bic, 2.5);
		
		String expectedStringWindows = 
			"*** Below is a list of products you have added: ***" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n") +
			"Product description: Banana" + String.format("%n") +
			"BIC: 11311" + String.format("%n") +
			"Unit Cost: 0.69" + String.format("%n") +
			"Tax Rate: 0.135" + String.format("%n") +
			"Weight: 2.5" + String.format("%n") +
			"Total Cost: $1.96" + String.format("%n") +
			String.format("%n") +
			"Product description: Ice Cream" + String.format("%n") +
			"UPC: 024543213611" + String.format("%n") +
			"Cost: $4.00" + String.format("%n") +
			"Tax Rate: 0.135" + String.format("%n") +
			"Weight: 2.2" + String.format("%n") +
			"Total Cost: $4.54" + String.format("%n") +
			String.format("%n") +
			"---- TOTAL: $6.50" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n");
		
		String expectedStringOther = 
			"*** Below is a list of products you have added: ***" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n") +
			"Product description: Ice Cream" + String.format("%n") +
			"UPC: 024543213611" + String.format("%n") +
			"Cost: $4.00" + String.format("%n") +
			"Tax Rate: 0.135" + String.format("%n") +
			"Weight: 2.2" + String.format("%n") +
			"Total Cost: $4.54" + String.format("%n") +
			String.format("%n") +
			"Product description: Banana" + String.format("%n") +
			"BIC: 11311" + String.format("%n") +
			"Unit Cost: 0.69" + String.format("%n") +
			"Tax Rate: 0.135" + String.format("%n") +
			"Weight: 2.5" + String.format("%n") +
			"Total Cost: $1.96" + String.format("%n") +
			String.format("%n") +
			"---- TOTAL: $6.50" + String.format("%n") +
			"-------------------------------------------------------" + String.format("%n");
		
		Utils.printCart(selfCheckOut.payForGroceries());
		
		success = expectedStringWindows.equals(outContent.toString()) ||
				expectedStringOther.equals(outContent.toString());
	
		assertTrue(success);
	}
}
