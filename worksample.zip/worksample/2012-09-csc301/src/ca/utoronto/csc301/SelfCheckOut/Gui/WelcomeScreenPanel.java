package ca.utoronto.csc301.SelfCheckOut.Gui;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JDialog;
import javax.swing.JPanel;

/**
 * @author g1chenli
 * This is a welcome screen panel intended to be used to take in an image,
 * added to a JDialog box, and displayed in the welcome screen of 
 * SelfCheckOutGUI. 
 *
 */
public class WelcomeScreenPanel extends JPanel implements ActionListener {

	/**
	 * Class serail ID
	 */
	private static final long serialVersionUID = 1L;
	private JDialog dialog;
	private boolean started; //if the start button has been pressed.

	private Image image;
	
	public WelcomeScreenPanel(JDialog d, String imagePath){
		dialog = d;
		started = false;

		try {
			image = ImageIO.read(getClass().getClassLoader().getResourceAsStream(imagePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Overriden paintComponent function to be able to draw the image in
	 * the background of the window.
	 * 
	 */
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(image, 0, 0, null);
	}
	
	public void actionPerformed(ActionEvent event) {
		if ("start".equals(event.getActionCommand())){
			dialog.setVisible(false);
			started = true; //program has started
		}
	}
	
	/**
	 * Get height of the image
	 */
	public int getImageHeight() {
		return image.getHeight(null);
	}
	
	/**
	 * Get width of the image
	 */
	public int getImageWidth() {
		return image.getWidth(null);
	}
	
	/**
	 * Get boolean representing whether the SelfCheckOutGUI app has started or not
	 */
	public boolean hasStarted() {
		return started;
	}

}
