package ca.utoronto.csc301.SelfCheckOut.Gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JColorChooser;
import javax.swing.colorchooser.AbstractColorChooserPanel;

public class CustomColorChooser implements ActionListener {
	
	private Color color;
	private static JColorChooser colorChooser;
	private AbstractColorChooserPanel[] ACCpanels;
	
	public CustomColorChooser() {
		colorChooser = new JColorChooser();
		ACCpanels = new AbstractColorChooserPanel[] { colorChooser.getChooserPanels()[0] };
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		colorChooser.setChooserPanels(ACCpanels);
		color = JColorChooser.showDialog(colorChooser, "Background Color", null);
		
	}
	
	public Color getColor() {
		return color;
	}

}
