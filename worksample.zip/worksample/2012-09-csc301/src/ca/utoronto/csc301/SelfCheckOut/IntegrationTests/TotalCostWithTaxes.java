package ca.utoronto.csc301.SelfCheckOut.IntegrationTests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.App.BIC;
import ca.utoronto.csc301.SelfCheckOut.App.DiscountDB;
import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomerDB;
import ca.utoronto.csc301.SelfCheckOut.App.ProductDB;
import ca.utoronto.csc301.SelfCheckOut.App.SelfCheckOut;
import ca.utoronto.csc301.SelfCheckOut.App.UPC;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingArea;
import ca.utoronto.csc301.SelfCheckOut.Devices.PaymentCollector;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.IncorrectStateException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidProductException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.StallCustomerException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidWeightException;

public class TotalCostWithTaxes {

	//Since we round to the nearest cent, this is still small enough
	//to not cause trouble.
	final static double EPSILON = 1e-7;
	
	static SelfCheckOut selfCheckOut;
	static ProductDB productDB;
	static PaymentCollector paymentCollector;
	static PreferredCustomerDB customerDB;
	static DiscountDB discountDB;
	static BaggingArea baggingArea;
	static UPC zeroTaxUPC, someTaxUPCOne, someTaxUPCTwo;
	static BIC zeroTaxBIC, someTaxBICOne, someTaxBICTwo;
	

	@BeforeClass
	public static void setUpClass() throws Exception {
		productDB = new ProductDB();
		baggingArea = new BaggingArea();
		paymentCollector = new PaymentCollector();
		customerDB = new PreferredCustomerDB();
		discountDB = new DiscountDB();
		
		zeroTaxUPC = new UPC("737751000842"); //Steak
		someTaxUPCOne = new UPC("085392132225"); //Oreo Cookies
		someTaxUPCTwo = new UPC("727851000842"); //Bacon
		zeroTaxBIC = new BIC("11111"); //Banana
		someTaxBICOne = new BIC("13138"); //Skor bits
		someTaxBICTwo = new BIC("66666"); //Gummi Bears
		
		selfCheckOut = new SelfCheckOut(baggingArea, paymentCollector, productDB, customerDB, discountDB);
	}
	
	@After
	public void tearDown() {
		selfCheckOut.resetAll();
	}
	
	@AfterClass
	public static void tearDownClass() {
		selfCheckOut = null;
		productDB = null;
		baggingArea = null;
		paymentCollector = null;
	}

	@Test
	public void bulkItemZeroTax() throws StallCustomerException {
		double totalCost;
		
		try {
			selfCheckOut.addItem(zeroTaxBIC, 2.2);
		} catch (IncorrectStateException e) {
			fail("Incorrect State for adding item");
		} catch (InvalidProductException e) {
			fail("Invalid Product");
		} catch (InvalidWeightException e) {
			fail("Can't add item with zero weight");
		}
		
		totalCost = selfCheckOut.getTotalCost();
		
		assertEquals(totalCost, 2.2*0.69, EPSILON);
		
	}
	
	@Test
	public void bulkItemSomeTax() throws StallCustomerException {
		double totalCost;
		
		try {
			selfCheckOut.addItem(someTaxBICOne, 3.4);
		} catch (IncorrectStateException e) {
			fail("Incorrect State for adding item");
		} catch (InvalidProductException e) {
			fail("Invalid Product");
		} catch (InvalidWeightException e) {
			fail("Can't add item with zero weight");
		}
		
		totalCost = selfCheckOut.getTotalCost();
		
		assertEquals(totalCost, 3.4*5.00*1.5, EPSILON);
		
	}
	
	@Test
	public void bulkItemsMixedTax() throws StallCustomerException {
		double totalCost;
		
		try {
			selfCheckOut.addItem(someTaxBICOne, 1.32);
			baggingArea.changeWeight(1.32);
			selfCheckOut.addItem(zeroTaxBIC, 2.2);
			baggingArea.changeWeight(2.2);
			selfCheckOut.addItem(someTaxBICTwo, 4.1);
			baggingArea.changeWeight(4.1);
			selfCheckOut.addItem(someTaxBICOne, 1.8);
			baggingArea.changeWeight(1.8);
		} catch (IncorrectStateException e) {
			fail("Incorrect State for adding item");
		} catch (InvalidProductException e) {
			fail("Invalid Product");
		} catch (InvalidWeightException e) {
			fail("Can't add item with zero weight");
		}
		
		totalCost = selfCheckOut.getTotalCost();
		
		assertEquals(totalCost, (1.32*5.00)*(1.5) +
								(2.2*0.69) +
								(4.1*0.85)*(1.135) +
								(1.8*5.00)*(1.5), EPSILON);
		
	}
	
	@Test
	public void packagedItemNoTax() throws StallCustomerException {
		double totalCost;
		
		try {
			selfCheckOut.addItem(zeroTaxUPC);
		} catch (IncorrectStateException e) {
			fail("Incorrect State for adding item");
		} catch (InvalidProductException e) {
			fail("Invalid Product");
		}
		
		totalCost = selfCheckOut.getTotalCost();
		
		assertEquals(totalCost, 16.00, EPSILON);
		
	}
	
	@Test
	public void packagedItemSomeTax() throws StallCustomerException {
		double totalCost;
		
		try {
			selfCheckOut.addItem(someTaxUPCOne);
		} catch (IncorrectStateException e) {
			fail("Incorrect State for adding item");
		} catch (InvalidProductException e) {
			fail("Invalid Product");
		}
		
		totalCost = selfCheckOut.getTotalCost();
		
		assertEquals(totalCost, 3.5*1.135, EPSILON);
	}
	
	@Test
	public void packagedItemsMixedTaxes() throws StallCustomerException {
		double totalCost;
		
		try {
			selfCheckOut.addItem(someTaxUPCOne);
			baggingArea.changeWeight(1);
			selfCheckOut.addItem(zeroTaxUPC);
			baggingArea.changeWeight(1);
			selfCheckOut.addItem(someTaxUPCTwo);
			baggingArea.changeWeight(1);
			selfCheckOut.addItem(someTaxUPCOne);
			baggingArea.changeWeight(1);
		} catch (IncorrectStateException e) {
			fail("Incorrect State for adding item");
		} catch (InvalidProductException e) {
			fail("Invalid Product");
		}
		
		totalCost = selfCheckOut.getTotalCost();
		
		assertEquals(totalCost, 3.5*1.135*2 +
								16 +
								5.5*1.25, EPSILON);
	}
	
	/**
	 * CartWithManyItems tests this
	 */
//	@Test
//	public void mixedItemsMixedTaxes() {
//
//	}
}
