package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.*;

import java.util.Vector;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class FakeAlertSystemTest {

	FakeAlertSystem fas;
	static Vector<Integer> alertCode;
	static Vector<String> alertMsg;
	static int size = 10; //size of the vector array for testing purposes
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		alertCode = new Vector<Integer>();
		alertMsg = new Vector<String>();
		for (int i = 0; i < size; i++) {
			alertCode.add(i);
			alertMsg.add("alert msg " + i);
		}
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		alertCode.removeAllElements();
		alertMsg.removeAllElements();
		alertCode = null;
		alertMsg = null;

		
	}

	@Before
	public void setUp() throws Exception {
		fas = new FakeAlertSystem();
	}

	@After
	public void tearDown() throws Exception {
		fas = null;
	}

	@Test
	public void testRecieveAlert() {
		assertTrue(fas.numAlertReceived() == 0); //start with empty fas
		
		for (int i = 0; i < size; i++) {
			fas.recieveAlert(alertCode.get(i), alertMsg.get(i));
			//make sure both the alert code/message received is the same
			//as the alert code/message sent
			assertTrue(fas.getAlertCode(i) == alertCode.get(i));
			assertTrue(fas.getAlertMsg(i) == alertMsg.get(i));
		}
		
		assertTrue(fas.numAlertReceived() == size); //end with size
	}

	@Test
	public void testLastAlertCodeEmpty() {
		assertTrue(fas.numAlertReceived() == 0); //start with empty fas
		try {
			fas.lastAlertCode();
		} catch (Exception e) {
			//should throw exception when the alerts recieved vectors are empty
		}
	}

	@Test
	public void testLastAlertCodeOne() {
		assertTrue(fas.numAlertReceived() == 0); //start with empty fas

		fas.recieveAlert(alertCode.get(0), alertMsg.get(0)); //send a message
		assertTrue(fas.numAlertReceived() == 1);
		assertTrue(fas.lastAlertCode() == 0); //index 0

	}
	
	@Test
	public void testLastAlertCodeTwo() {
		assertTrue(fas.numAlertReceived() == 0); //start with empty fas

		fas.recieveAlert(alertCode.get(0), alertMsg.get(0)); //send a message
		assertTrue(fas.numAlertReceived() == 1);
		assertTrue(fas.lastAlertCode() == 0); //index 0

		fas.recieveAlert(alertCode.get(1), alertMsg.get(1)); //send another message
		assertTrue(fas.numAlertReceived() == 2);
		assertTrue(fas.lastAlertCode() == 1); //index 0
	}
	
}
