package ca.utoronto.csc301.SelfCheckOut.App;
import java.util.Enumeration;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CheckOutCartTest {
	
	static final double EPSILON = 1e-7;
	
	static ProductDB productDB;
	static GroceryItem bacon, steak, pineapple, skor;
	static CheckOutCart cart;
	
	@BeforeClass
	public static void setUpClass() throws Exception {
		ProductInfo b, s, p, k;
		// If product db is not initialized, do so
		if (productDB == null) {
			productDB = new ProductDB();
		}
		
		// Look up products from the product db
		b = productDB.lookUpItem("727851000842");
		s = productDB.lookUpItem("737751000842");
		p = productDB.lookUpItem("00000");
		k = productDB.lookUpItem("13138");
		
		// Make grocery items out of the products
		bacon = new GroceryItem(b, 
				((PackagedProduct)b).getPrice(), 
				((PackagedProduct)b).getWeight());
		steak = new GroceryItem(s, 
				((PackagedProduct)s).getPrice(), 
				((PackagedProduct)s).getWeight());
		pineapple = new GroceryItem(p, 
				((BulkProduct)p).getPrice(), 1.0);
		skor = new GroceryItem(k, 
				((BulkProduct)k).getPrice(), 1.0);
	}
	
	@Before
	public void setUp() {
		// Refresh the cart
		cart = new CheckOutCart();

	}

	@After
	public void tearDown() throws Exception {
		// Tear down the cart
		cart = null;
	}

	@Test
	public final void testGetTotalCost() {
		assertEquals(cart.getTotalCost(), 0.00, EPSILON);
		cart.addItemToCart(bacon);
		assertEquals(cart.getTotalCost(), 5.50, EPSILON);
		cart.addItemToCart(steak);
		assertEquals(cart.getTotalCost(), 21.50, EPSILON);
		cart.addItemToCart(pineapple);
		assertEquals(cart.getTotalCost(), 23.00, EPSILON);
		cart.addItemToCart(skor);
		assertEquals(cart.getTotalCost(), 28.00, EPSILON);
	}

	@Test
	public final void testGetTotalWeight() {
		assertEquals(cart.getTotalWeight(), 0, EPSILON);
		cart.addItemToCart(bacon);
		assertEquals(cart.getTotalWeight(), 1.3, EPSILON);
		cart.addItemToCart(steak);
		assertEquals(cart.getTotalWeight(), 3.5, EPSILON);
		cart.addItemToCart(pineapple);
		assertEquals(cart.getTotalWeight(), 4.5, EPSILON);
		cart.addItemToCart(skor);
		assertEquals(cart.getTotalWeight(), 5.5, EPSILON);
	}
	
	@Test
	public final void testAddItemToCartAndListItems() {
		assertEquals(getsize(cart.listItems()), 0);
		cart.addItemToCart(bacon);
		assertEquals(getsize(cart.listItems()), 1);
		cart.addItemToCart(steak);
		assertEquals(getsize(cart.listItems()), 2);
		cart.addItemToCart(pineapple);
		assertEquals(getsize(cart.listItems()), 3);
		cart.addItemToCart(skor);
		assertEquals(getsize(cart.listItems()), 4);
	}
	
	public int getsize(Enumeration<GroceryItem> eg){
		int i = 0;
		while(eg.hasMoreElements()){
			i += 1;
			eg.nextElement();
		}
		return i;
	}

}
