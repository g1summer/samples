package ca.utoronto.csc301.SelfCheckOut.Exceptions;

public class AlreadyLoggedInException extends IncorrectStateException {
	
	private static final long serialVersionUID = 1L;

	public AlreadyLoggedInException() {
		super();
	}

	public AlreadyLoggedInException(String message) {
		super(message);
	}

	public AlreadyLoggedInException(String message, Throwable cause) {
		super(message, cause);
	}

	public AlreadyLoggedInException(Throwable cause) {
		super(cause);
	}

}
