package ca.utoronto.csc301.SelfCheckOut.Devices;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BaggingAreaEventTest {

	static final double EPSILON = 1e-15;
	
	BaggingAreaEvent event;
	
	@Before
	public void setUp() throws Exception {
		event = new BaggingAreaEvent(0, 0);
	}

	@After
	public void tearDown() throws Exception {
		event = null;
	}
	
	@Test
	public void testConstructWithSameValuesBaggingAreaEvent() {
		
		double weight = 5.5;
		double change = 5.5;
		BaggingAreaEvent myevent = new BaggingAreaEvent(weight, change);
		assertEquals(weight, myevent.getWeight(), EPSILON);
		assertEquals(change, myevent.getChange(), EPSILON);
		
	}

	@Test
	public void testConstructWithDiffValuesBaggingAreaEvent() {
		
		double weight = 5.5;
		double change = 4.5;
		BaggingAreaEvent myevent = new BaggingAreaEvent(weight, change);
		assertEquals(weight, myevent.getWeight(), EPSILON);
		assertEquals(change, myevent.getChange(), EPSILON);
		
	}
	
	@Test
	public void testConstructWithNegativeValuesBaggingAreaEvent() {
		
		double weight = -5.5;
		double change = -4.5;
		BaggingAreaEvent myevent = new BaggingAreaEvent(weight, change);
		assertEquals(weight, myevent.getWeight(), EPSILON);
		assertEquals(change, myevent.getChange(), EPSILON);
		
	}

}
