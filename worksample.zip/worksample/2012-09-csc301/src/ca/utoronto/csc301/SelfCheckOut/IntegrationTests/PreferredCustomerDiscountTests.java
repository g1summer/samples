package ca.utoronto.csc301.SelfCheckOut.IntegrationTests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.App.BIC;
import ca.utoronto.csc301.SelfCheckOut.App.DiscountDB;
import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomerDB;
import ca.utoronto.csc301.SelfCheckOut.App.ProductDB;
import ca.utoronto.csc301.SelfCheckOut.App.SelfCheckOut;
import ca.utoronto.csc301.SelfCheckOut.App.UPC;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingArea;
import ca.utoronto.csc301.SelfCheckOut.Devices.PaymentCollector;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.AlreadyLoggedInException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.IncorrectStateException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidProductException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.StallCustomerException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidWeightException;

public class PreferredCustomerDiscountTests {

	private static final String LOG_DIRECTORY = "junit";
	static final double EPSILON = 1e-7;
	
	static SelfCheckOut selfCheckOut;
	static BaggingArea baggingArea;
	static ProductDB productDB;
	static PaymentCollector paymentCollector;
	static PreferredCustomerDB customerDB;
	static DiscountDB discountDB;
	static BIC[] bics;
	static UPC[] upcs;
	
	@BeforeClass
	public static void classSetUp() throws Exception {
		//create a SelfCheckOut
		baggingArea = new BaggingArea();
		paymentCollector = new PaymentCollector();
		productDB = new ProductDB();
		customerDB = new PreferredCustomerDB();
		discountDB = new DiscountDB();

		selfCheckOut = new SelfCheckOut(baggingArea, paymentCollector, productDB, 
				customerDB, discountDB, LOG_DIRECTORY);
		
		bics = new BIC[5];
		upcs = new UPC[4];
		
		//Get ready to add BulkProducts
		bics[0] = new BIC("11111");
		bics[1] = new BIC("22222");
		bics[2] = new BIC("33333");
		bics[3] = new BIC("44444");
		bics[4] = new BIC("55555");
		
		//Get ready to add PackagedProducts
		upcs[0] = new UPC("786936224306");
		upcs[1] = new UPC("717951000842");
		upcs[2] = new UPC("024543213710");
		upcs[3] = new UPC("085392132225");
	}

	@AfterClass
	public static void classTearDown() {
		selfCheckOut = null;
		baggingArea = null;
		productDB = null;
		paymentCollector = null;
	}
	
	@Before
	public void setUp() throws StallCustomerException{
		addItemsToCart();
	}
	
	@After
	public void tearDown() {
		selfCheckOut.resetAll();
	}
	
	/**
	 * Today it is yan's birthday, so he should receive the birthday discount
	 */
	@Test
	public void testOneCriteria() {
		try {
			SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
			Date today = dateFormatter.parse("12/08/2012");
			selfCheckOut.setDate(today);
			
			// log yan in
			if (selfCheckOut.loginPreferredCustomer(25437122) == null)
				fail("login failed");
			
			// get total percentage discount
			double discountPercentage = selfCheckOut.getTotalDiscount();
			// declare expected discount percentage
			double expectedPercentage = 0.4194;
			
			assertEquals(expectedPercentage, discountPercentage, EPSILON);
			
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * Today it is not yan's birthday, so he should not receive the birthday discount
	 */
	@Test
	public void testOneCriteriaIneligible() {
		try {
			SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
			Date today = dateFormatter.parse("12/09/2012");
			selfCheckOut.setDate(today);
			
			// log yan in
			if (selfCheckOut.loginPreferredCustomer(25437122) == null)
				fail("login failed");
			
			// get total percentage discount
			double discountPercentage = selfCheckOut.getTotalDiscount();
			// declare expected discount percentage
			double expectedPercentage = 0.0;
			
			assertEquals(expectedPercentage, discountPercentage, EPSILON);
			
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * Today it is mother's day, and jane is female and older than 18, so she is eligible
	 */
	@Test
	public void testMultipleCriteria() {
		try {
			SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
			Date today = dateFormatter.parse("05/12/2013");
			selfCheckOut.setDate(today);
			
			// log jane in
			if (selfCheckOut.loginPreferredCustomer(39847102) == null)
				fail("login failed");
			
			// get total percentage discount
			double discountPercentage = selfCheckOut.getTotalDiscount();
			// declare expected discount percentage
			double expectedPercentage = 0.2097;
			
			assertEquals(expectedPercentage, discountPercentage, 1 / 1e8);
			
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * Today it is mother's day; yan is older than 18, but not female, so he is not eligible
	 */
	@Test
	public void testMultipleCriteriaIneligible() {
		try {
			SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
			Date today = dateFormatter.parse("05/12/2013");
			selfCheckOut.setDate(today);
			
			// log jane in
			if (selfCheckOut.loginPreferredCustomer(25437122) == null)
				fail("login failed");
			
			// get total percentage discount
			double discountPercentage = selfCheckOut.getTotalDiscount();
			// declare expected discount percentage
			double expectedPercentage = 0;
			
			assertEquals(expectedPercentage, discountPercentage, EPSILON);
			
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	/**
	 * Test to see whether discounts are compounded correctly if
	 * the customer is eligible for multiple discounts.
	 * Marc is eligible for the student discount, the loyalty discount
	 * and the birthday discount on september 7
	 */
	@Test
	public void testCompoundedDiscounts() {
		try {
			SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
			Date today = dateFormatter.parse("09/07/2012");
			selfCheckOut.setDate(today);
			
			// log jane in
			if (selfCheckOut.loginPreferredCustomer(10432381) == null)
				fail("login failed");
			
			// get total percentage discount
			double discountPercentage = selfCheckOut.getTotalDiscount();
			// declare expected discount percentage
			double expectedPercentage = 1.6776;
			
			assertEquals(expectedPercentage, discountPercentage, EPSILON);
			
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * Today it is yan's birthday, so he should receive the birthday discount,
	 * but after he logs out and jane logs in, jane should receive the loyalty
	 * discount.
	 */
	@Test
	public void testPreferredToPreferred() {
		try {
			SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
			Date today = dateFormatter.parse("12/08/2012");
			selfCheckOut.setDate(today);
			
			// log yan in
			if (selfCheckOut.loginPreferredCustomer(25437122) == null)
				fail("login failed");
			
			// Reset the self check out
			selfCheckOut.resetAll();
			
			//Re-add items to cart
			addItemsToCart();
			
			//log jane in
			if (selfCheckOut.loginPreferredCustomer(39847102) == null)
				fail("login failed");
			
			// get total percentage discount
			double discountPercentage = selfCheckOut.getTotalDiscount();
			// declare expected discount percentage
			double expectedPercentage = 0.2097;
			
			assertEquals(expectedPercentage, discountPercentage, EPSILON);
			
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * Today it is yan's birthday, so he should receive the birthday discount,
	 * but after he logs out and a normal customer starts, they should not receive
	 * any discounts
	 */
	@Test
	public void testPreferredToNormal() {
		try {
			SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
			Date today = dateFormatter.parse("12/08/2012");
			selfCheckOut.setDate(today);
			
			// log yan in
			if (selfCheckOut.loginPreferredCustomer(25437122) == null)
				fail("login failed");
			
			// Reset the self check out
			selfCheckOut.resetAll();
			
			//Re-add items to cart, now in new customer context
			addItemsToCart();
			
			// get total percentage discount
			double discountPercentage = selfCheckOut.getTotalDiscount();
			// declare expected discount percentage
			double expectedPercentage = 0.0;
			
			assertEquals(expectedPercentage, discountPercentage, EPSILON);
			
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * Test to see whether the discounts are being correctly applied to the
	 * total final cost of the items in the cart
	 * 
	 */
	@Test
	public void testTotalCostWithDiscount() {
		try {
			SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
			Date today = dateFormatter.parse("09/07/2012");
			selfCheckOut.setDate(today);
			
			// log jane in
			if (selfCheckOut.loginPreferredCustomer(10432381) == null)
				fail("login failed");
			
			// get total percentage discount
			double discountPercentage = selfCheckOut.getTotalCost();
			// declare expected discount percentage
			double expectedPercentage = 20.7369;
			
			assertEquals(expectedPercentage, discountPercentage, EPSILON);
			
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * Today it is yan's birthday, so he should receive the birthday discount,
	 * even when he logs into the machine after a normal customer has used it
	 * previously
	 */
	@Test
	public void testNormalToPreferred() {
		try {
			SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
			Date today = dateFormatter.parse("12/08/2012");
			selfCheckOut.setDate(today);
			
			// Reset the self check out
			selfCheckOut.resetAll();
			
			// log yan in
			if (selfCheckOut.loginPreferredCustomer(25437122) == null)
				fail("login failed");
			
			//Re-add items to cart
			addItemsToCart();
			
			// get total percentage discount
			double discountPercentage = selfCheckOut.getTotalDiscount();
			// declare expected discount percentage
			double expectedPercentage = 0.4194;
			
			assertEquals(expectedPercentage, discountPercentage, EPSILON);
			
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}
	
	/**
	 * Makes sure no log file is created/modified if nobody logged 
	 * in as preferred customer
	 */
	@Test
	public void testNoLogsCreatedIfNotPreferred() {
		
		//Make sure there are no files in our junit logs directory
		File dir = new File(LOG_DIRECTORY);
		assertTrue(dir.listFiles().length == 0);
		
		try {
			//Don't log in as preferred customer
			addItemsToCart();
			selfCheckOut.payForGroceries();
		} catch (StallCustomerException e) {
			fail("Stalled for no reason");
		}
		
		//Make sure no file was added by paying for groceries
		assertTrue(dir.listFiles().length == 0);
	}
	
	/**
	 * Makes sure a log file is created/modified a preferred customer logs in
	 */
	@Test
	public void testLogsCreatedIfPreferred() {
		
		//Make sure there are no files in our junit logs directory
		File dir = new File(LOG_DIRECTORY);
		assertTrue(dir.listFiles().length == 0);
		
		try {
			//Log in as preferred customer
			selfCheckOut.loginPreferredCustomer(10432381);
			addItemsToCart();
			selfCheckOut.payForGroceries();
		} catch (StallCustomerException e) {
			fail("Stalled for no reason");
		} catch (AlreadyLoggedInException e) {
			fail("Double login");
		}
		
		//Make sure no file was added by paying for groceries
		assertTrue(dir.listFiles().length == 1);
		//Actual file contents is tested by PreferredCustomer unit test
		
		//Clean up the file
		assertTrue(dir.listFiles()[0].delete());
	}
	
	private void addItemsToCart() throws StallCustomerException{
		//We will create a cart with many items, both packaged and bulk products.

		//Add all the bulk products
		for (int i = 0; i < bics.length; i++) {
			try {
				// weight of 1 for ease of price calculation
				selfCheckOut.addItem(bics[i], 1.0f);
				baggingArea.changeWeight(1.0f);

			} catch (IncorrectStateException e) {
				fail("IncorrectStateException");
			} catch (InvalidProductException e) {
				fail("InvalidProductException");
			} catch (InvalidWeightException e) {
				fail("Bulk products shouldn't have zero weight");
			}
		}
		
		//Add all packaged products
		for (int i = 0; i < upcs.length; i++) {
			try {
				// weight of 1 for ease of price calculation
				selfCheckOut.addItem(upcs[i]);
				baggingArea.changeWeight(2);

			} catch (IncorrectStateException e) {
				fail("IncorrectStateException");
			} catch (InvalidProductException e) {
				fail("InvalidProductException");
			}
		}
	}

}
