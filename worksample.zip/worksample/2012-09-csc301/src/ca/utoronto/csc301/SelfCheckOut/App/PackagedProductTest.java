package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidUPCException;

public class PackagedProductTest {
	
	static final double taxRate = 0.5f;
	static final double EPSILON = 1e-15;
	
	PackagedProduct packagedProduct;
	UPC upc;
	String description = "testproduct";
	double price, weight;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		upc = new UPC("012345678905");
		TaxCategory category = new TaxCategory(taxRate);
		price = 4.99;
		weight = 23.7;
		packagedProduct = new PackagedProduct(description, category, upc, price, weight);
	}

	@After
	public void tearDown() throws Exception {
		upc = null;
		packagedProduct = null;
	}

	@Test
	public void testGetUPC() {
		assertEquals(packagedProduct.getUPC(), upc); 
	}

	@Test
	public void testGetCode() {
		assertEquals(packagedProduct.getCode(), upc); 
	}

	@Test
	public void testGetPrice() {
		assertEquals(packagedProduct.getPrice(), price, EPSILON);
	}

	@Test
	public void testGetWeight() {
		assertEquals(packagedProduct.getWeight(), weight, EPSILON); 
	}

	@Test
	public void testGetDescription() {
		assertEquals(packagedProduct.getDescription(), description);
	}
	
	@Test
	public void testGetTaxRate() {
		assertEquals(packagedProduct.getTaxRate(), taxRate, EPSILON);
	}
	
	@Test
	public void testNullTaxRate() throws InvalidUPCException {
		UPC upc = new UPC("012345678905");
		PackagedProduct nullTax = new PackagedProduct("Null", null, upc, 0.5, 0.5);
		
		//Items without a category shouldn't be taxed.
		assertEquals(nullTax.getTaxRate(), 0, 0);
		
	}

}
