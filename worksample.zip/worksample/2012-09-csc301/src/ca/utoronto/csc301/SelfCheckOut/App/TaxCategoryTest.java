package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TaxCategoryTest {
	static final double TAXRATE = 1.675f;
	static final double EPSILON = 0;
	
	TaxCategory category;
	
	@Before
	public void setUp() {
		category = new TaxCategory(TAXRATE);
	}
	
	@After
	public void tearDown() {
		category = null;
	}
	
	@Test
	public void testGetTaxRate() {
		//sanity test
		assertEquals(category.getTaxRate(), TAXRATE, EPSILON);
	}
}
