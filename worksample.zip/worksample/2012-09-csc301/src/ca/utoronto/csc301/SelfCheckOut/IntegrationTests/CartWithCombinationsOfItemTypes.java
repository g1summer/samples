package ca.utoronto.csc301.SelfCheckOut.IntegrationTests;

import static org.junit.Assert.assertTrue;

import java.util.Enumeration;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.App.BIC;
import ca.utoronto.csc301.SelfCheckOut.App.GroceryItem;
import ca.utoronto.csc301.SelfCheckOut.App.SelfCheckOut;
import ca.utoronto.csc301.SelfCheckOut.App.UPC;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingAreaEvent;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.IncorrectStateException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidProductException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.StallCustomerException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidWeightException;

public class CartWithCombinationsOfItemTypes {

	static SelfCheckOut selfCheckOut;
	static UPC upc1, upc2;
	static BIC bic1, bic2;
	double weight = 5.0;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		selfCheckOut = new SelfCheckOut();
		
		//Cost: 3.52	Weight: 1.35
		upc1 = new UPC("717951000842");
		//Cost: 4.00	Weight: 2.2
		upc2 = new UPC("024543213710");
		//Cost: 1.50 per unit
		bic1 = new BIC("00000");
		//Cost: 5.00 per unit
		bic2 = new BIC("13138");
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		selfCheckOut = null;
		upc1 = null; 
		upc2 = null;
		bic1 = null;
		bic2 = null;
	}

	@After
	public void tearDown() throws Exception {
		selfCheckOut.resetAll();
	}

	@Test
	public void testSuccessiveBICAdding() throws IncorrectStateException, InvalidProductException, InvalidWeightException, StallCustomerException {
		BaggingAreaEvent myevent = new BaggingAreaEvent(weight, weight);
		Enumeration<GroceryItem> groceryItems;
		GroceryItem groceryItem1, groceryItem2, grocery;
		
		groceryItem1 = selfCheckOut.addItem(bic1, weight);
		selfCheckOut.notifyBaggingAreaEvent(selfCheckOut.getBaggingArea(), myevent); // to change the state from BAGGING TO ADDING
		groceryItem2 = selfCheckOut.addItem(bic2, weight);
		
		groceryItems = selfCheckOut.listItemsInCart();
		grocery = groceryItems.nextElement(); // start at first element in checkOutart
		
		assertTrue(grocery.equals(groceryItem1));
		grocery = groceryItems.nextElement();
		assertTrue(grocery.equals(groceryItem2));
		
	}
	
	@Test
	public void testSuccessiveUPCAdding() throws IncorrectStateException, InvalidProductException, InvalidWeightException, StallCustomerException {
		BaggingAreaEvent myevent = new BaggingAreaEvent(1.35, 1.35); // Adding upc1 first
		Enumeration<GroceryItem> groceryItems;
		GroceryItem groceryItem1, groceryItem2, grocery;
		
		groceryItem1 = selfCheckOut.addItem(upc1);
		selfCheckOut.notifyBaggingAreaEvent(selfCheckOut.getBaggingArea(), myevent); // to change the state from BAGGING TO ADDING
		groceryItem2 = selfCheckOut.addItem(upc2);
		
		groceryItems = selfCheckOut.listItemsInCart();
		grocery = groceryItems.nextElement(); // start at first element in checkOutart
		
		assertTrue(grocery.equals(groceryItem1));
		grocery = groceryItems.nextElement();
		assertTrue(grocery.equals(groceryItem2));
	}
	
	@Test
	public void testAddingBulkItemFirst() throws IncorrectStateException, InvalidProductException, InvalidWeightException, StallCustomerException {

		Enumeration<GroceryItem> groceryItems;
		GroceryItem groceryItem1, groceryItem2, grocery;
		
		groceryItem1 = selfCheckOut.addItem(upc1);
		BaggingAreaEvent myevent = new BaggingAreaEvent(groceryItem1.getWeight(), groceryItem1.getWeight());
		selfCheckOut.notifyBaggingAreaEvent(selfCheckOut.getBaggingArea(), myevent); // to change the state from BAGGING TO ADDING
		groceryItem2 = selfCheckOut.addItem(bic1, weight);
		
		groceryItems = selfCheckOut.listItemsInCart();
		grocery = groceryItems.nextElement(); // start at first element in checkOutart
		
		assertTrue(grocery.equals(groceryItem1));
		grocery = groceryItems.nextElement();
		assertTrue(grocery.equals(groceryItem2));
	}

	@Test
	public void testAddingPackagedItemFirst() throws IncorrectStateException, InvalidProductException, InvalidWeightException, StallCustomerException {

		Enumeration<GroceryItem> greoceryItems;
		GroceryItem groceryItem1, groceryItem2, grocery;
		
		groceryItem1 = selfCheckOut.addItem(bic1, weight);
		BaggingAreaEvent myevent = new BaggingAreaEvent(groceryItem1.getWeight(), groceryItem1.getWeight());
		selfCheckOut.notifyBaggingAreaEvent(selfCheckOut.getBaggingArea(), myevent); // to change the state from BAGGING TO ADDING
		groceryItem2 = selfCheckOut.addItem(upc1);
		
		greoceryItems = selfCheckOut.listItemsInCart();
		grocery = greoceryItems.nextElement(); // start at first element in checkOutart
		
		assertTrue(grocery.equals(groceryItem1));
		grocery = greoceryItems.nextElement();
		assertTrue(grocery.equals(groceryItem2));
	}

	@Test
	public void testAddingSmallItemCombination() throws IncorrectStateException, InvalidProductException, InvalidWeightException, StallCustomerException {

		Enumeration<GroceryItem> groceryItems;
		GroceryItem groceryItem1, groceryItem2, groceryItem3, groceryItem4, grocery;
		
		groceryItem1 = selfCheckOut.addItem(bic1, weight);
		BaggingAreaEvent myevent1 = new BaggingAreaEvent(groceryItem1.getWeight(), groceryItem1.getWeight());
		selfCheckOut.notifyBaggingAreaEvent(selfCheckOut.getBaggingArea(), myevent1); // to change the state from BAGGING TO ADDING
		groceryItem2 = selfCheckOut.addItem(upc1);
		BaggingAreaEvent myevent2 = new BaggingAreaEvent(groceryItem1.getWeight() + groceryItem2.getWeight(), groceryItem2.getWeight());
		selfCheckOut.notifyBaggingAreaEvent(selfCheckOut.getBaggingArea(), myevent2);
		groceryItem3 = selfCheckOut.addItem(bic2, weight);
		BaggingAreaEvent myevent3 = new BaggingAreaEvent(groceryItem1.getWeight() + groceryItem2.getWeight() + groceryItem3.getWeight(), groceryItem3.getWeight());
		selfCheckOut.notifyBaggingAreaEvent(selfCheckOut.getBaggingArea(), myevent3);
		groceryItem4 = selfCheckOut.addItem(upc2);
		
		
		
		groceryItems = selfCheckOut.listItemsInCart();
		grocery = groceryItems.nextElement(); // start at first element in checkOutart
		
		assertTrue(grocery.equals(groceryItem1));
		grocery = groceryItems.nextElement();
		assertTrue(grocery.equals(groceryItem2));
		grocery = groceryItems.nextElement();
		assertTrue(grocery.equals(groceryItem3));
		grocery = groceryItems.nextElement();
		assertTrue(grocery.equals(groceryItem4));
	}

}
