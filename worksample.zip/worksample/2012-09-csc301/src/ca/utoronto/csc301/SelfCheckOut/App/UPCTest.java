package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidUPCException;

public class UPCTest {

	static final String VALIDCODE = "012345678905";

	@Test (expected = InvalidUPCException.class)
	public void constructWithNullUPC() throws InvalidUPCException {
		@SuppressWarnings("unused")
		UPC nullUPC = new UPC(null);
	}
	
	@Test (expected = InvalidUPCException.class)
	public void constructWithCodeLength11() throws InvalidUPCException {
		@SuppressWarnings("unused")
		UPC smallUPC = new UPC("12345678901");
	}
	
	@Test (expected = InvalidUPCException.class)
	public void constructWithCodeLength13() throws InvalidUPCException {
		@SuppressWarnings("unused")
		UPC bigUPC = new UPC("1234567890123");
	}
	
	@Test (expected = InvalidUPCException.class)
	public void constructWithInvalidUPC() throws InvalidUPCException {
		@SuppressWarnings("unused")
		UPC invalidUPC = new UPC("012345678906");
	}
	
	@Test
	public void testGetCode() throws InvalidUPCException {
		UPC validUPC = new UPC(VALIDCODE);
		
		assertEquals(validUPC.getCode(), VALIDCODE);
	}
	
	@Test
	public void compareSameUPCs() throws InvalidUPCException {
		//Also tests making valid codes at the same time.
		UPC validUPCOne = new UPC(VALIDCODE);
		UPC validUPCTwo = new UPC(VALIDCODE);
		
		assertTrue(validUPCOne.equals(validUPCOne));
		assertTrue(validUPCOne.equals(validUPCTwo));
		assertTrue(validUPCOne.getCode().equals(validUPCTwo.getCode()));
	}
	
	@Test
	public void compareDifferentUPCs() throws InvalidUPCException {
		UPC validUPCOne = new UPC(VALIDCODE);
		UPC validUPCTwo = new UPC("012345678806");
		
		assertFalse(validUPCOne.equals(validUPCTwo));
		assertFalse(validUPCOne.getCode().equals(validUPCTwo.getCode()));
	}
	
}
