package ca.utoronto.csc301.SelfCheckOut.Exceptions;

public class DiscountRateOverOneException extends Exception{
	private static final long serialVersionUID = 1L;

	public DiscountRateOverOneException() {
		super();
	}

	public DiscountRateOverOneException(String message) {
		super(message);
	}

	public DiscountRateOverOneException(String message, Throwable cause) {
		super(message, cause);
	}

	public DiscountRateOverOneException(Throwable cause) {
		super(cause);
	}
}
