package ca.utoronto.csc301.SelfCheckOut.Gui;

import java.awt.event.ActionListener;

public interface SearchResultPanelListener extends ActionListener {

	public void resultEvent(String event);
}
