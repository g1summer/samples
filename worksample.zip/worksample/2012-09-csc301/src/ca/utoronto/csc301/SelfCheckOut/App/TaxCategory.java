package ca.utoronto.csc301.SelfCheckOut.App;

/**
 * The TaxCategory class defines a category of items which is taxed at a given rate
 */
public class TaxCategory {
	
	/**
	 * the tax rate for this category
	 */
	private double taxRate = 0.0f;
	
	/**
	 * TaxCategory constructor, defines the tax rate for this category
	 * @param taxRate
	 */
	public TaxCategory(double taxRate) {
		this.taxRate = taxRate;
	}
	
	/**
	 * returns the tax rate for this category
	 */
	public double getTaxRate() {
		return taxRate;
	}
}
