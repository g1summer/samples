/*
 * Creator: Susan Elliott Sim
 * 
 * Created on May 10, 2006
 * Updated on January 17, 2008, September 12, 2012
 * 
 * The ProductInfo interface is implemented by BulkProduct and PackagedProduct.
 */

package ca.utoronto.csc301.SelfCheckOut.App;

import javax.swing.ImageIcon;

/**
 * The ProductInfo interface is implemented by any class which represents a saleable product
 * in our store.  In out example, these will be the BulkProduct and PackagedProduct.  These 
 * products differ in the manner in which their prices are calculated, but have in common a
 * descriptor, price, and identifying code.  The interface provides common accessor methods
 * for these fields.
 *
 */
public interface ProductInfo extends DatabaseObject {
	/**
	 * Accessor method for product description
	 */
	public String getDescription();

	/**
	 * Accessor method for unit price
	 */
	public double getPrice();
	
	/**
	 * Accessor method for identifying code, either BIC or UPC.  (Both are of type Code)
	 */
	public Code getCode();
	
	/**
	 * Accessor method for tax rate
	 */
	public double getTaxRate();
	
	/**
	 * Accessor method for an image of this product.
	 */
	public ImageIcon getImage();
}
