package ca.utoronto.csc301.SelfCheckOut.App;

import javax.swing.ImageIcon;

public class ProductCategory {
	
	// Category image
	private ImageIcon image;
	
	// Category name
	private String name;
	
	// List of product codes
	String[] products;
	
	public ProductCategory(String name, ImageIcon image, String[] products) {
		this.name = name;
		this.image = image;
		this.products = products;
	}
	
	public ImageIcon getImage() {
		return image;
	}
	
	public String getName() {
		return name;
	}
	
	public String[] listProducts() {
		return products;
	}
}
