package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.*;

import java.util.Vector;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class FakeFraudCheckerTest {

	FakeFraudChecker ffc;

	@Before
	public void setUp() throws Exception {
		try {
			ffc = new FakeFraudChecker();
		} catch (Exception e) {
			fail("Failed to construct FakeFraudChecker");
		}
	}

	@After
	public void tearDown() throws Exception {
		ffc = null;
	}

	@Test
	public void testConstructFakeFraudCheckerFalse() {
		try {
			boolean b = false;
			FakeFraudChecker myffc = new FakeFraudChecker(b);

			//Default initialization with the first element of vector 'decisions'
			//is set to false.
			assertTrue(myffc.getPosition() == 0); //initialized with position = 0
			assertTrue(myffc.getSize() == 1); //initialized with one element in decisions
			assertFalse(myffc.hasFraud()); //b at position 0
		} catch (Exception e) {
			fail("Failed to construct FakeFraudChecker");
		}
	}

	@Test
	public void testConstructFakeFraudCheckerTrue() {
		try {
			boolean b = true;
			FakeFraudChecker myffc = new FakeFraudChecker(b);

			//Default initialization with the first element of vector 'decisions'
			//is set to true.
			assertTrue(myffc.getPosition() == 0); //initialized with position = 0
			assertTrue(myffc.getSize() == 1); //initialized with one element in decisions
			assertTrue(myffc.hasFraud()); //b at position 0
		} catch (Exception e) {
			fail("Failed to construct FakeFraudChecker");
		}
	}

	@Test
	public void testConstructFakeFraudCheckerNullVector() {
		FakeFraudChecker myffc = null;
		try {
			myffc = new FakeFraudChecker(null);
		} catch (Exception e) {
			//expected to throw an exception of construction with null value
		}
		assertTrue(myffc == null);
	}

	@Test
	public void testConstructFakeFraudCheckerEmptyVector() {
		try {
			Vector<Boolean> vb = new Vector<Boolean>();
			FakeFraudChecker myffc = new FakeFraudChecker(vb);

			//Default initialization with the first element of vector 'decisions'
			//is set to true.
			assertTrue(myffc.getPosition() == 0); //initialized with position = 0
			assertTrue(myffc.getSize() == 0); //initialized with one element in decisions
		} catch (Exception e) {
			fail("Failed to construct FakeFraudChecker");
		}
	}

	@Test
	public void testConstructFakeFraudCheckerOneElementVector() {
		try {
			Vector<Boolean> vb = new Vector<Boolean>();
			vb.add(true);
			FakeFraudChecker myffc = new FakeFraudChecker(vb);

			//Default initialization with the first element of vector 'decisions'
			//is set to true.
			assertTrue(myffc.getPosition() == 0); //initialized with position = 0
			assertTrue(myffc.getSize() == 1); //initialized empty decisions vector
			assertTrue(myffc.hasFraud()); //b at position 0
		} catch (Exception e) {
			fail("Failed to construct FakeFraudChecker");
		}
	}

	@Test
	public void testConstructFakeFraudCheckerTwoElementVector() {
		try {
			Vector<Boolean> vb = new Vector<Boolean>();
			vb.add(true);
			vb.add(false);
			FakeFraudChecker myffc = new FakeFraudChecker(vb);

			//Default initialization with the first element of vector 'decisions'
			//is set to true.
			assertTrue(myffc.getPosition() == 0); //initialized with position = 0
			assertTrue(myffc.getSize() == 2); //initialized empty decisions vector
		} catch (Exception e) {
			fail("Failed to construct FakeFraudChecker");
		}
	}

	@Test
	public void testHasFraud() {
		assertFalse(ffc.hasFraud()); //ffc is initialized with decisions with one element as false
		assertTrue(ffc.getSize() == 1);
	}

	@Test
	public void testSetFraud() {
		assertTrue(ffc.getPosition() == 0); //position initialized at 0
		assertFalse(ffc.hasFraud()); //initialized with false at position 0

		boolean b = true;
		ffc.setFraud(b); // set b to position 0
		assertTrue(ffc.getSize() == 1); //replaced false at position 0
		//setFraud sets the element at position 0 to b
		assertTrue(ffc.hasFraud()); //inserted b at position = 0

	}

	@Test
	public void testSetFraudDifferentPositions() {
		Vector<Boolean> vb = new Vector<Boolean>();
		vb.add(false);
		vb.add(false);
		vb.add(false);
		FakeFraudChecker myffc = new FakeFraudChecker(vb);

		boolean b = true;
		int size = myffc.getSize();
		for(int i = 0; i < size; i++) {
			assertTrue(myffc.getPosition() == i); // at position i
			assertFalse(myffc.hasFraud()); //check value is at first false

			myffc.setFraud(b); //set boolean to true at i
			assertTrue(myffc.hasFraud()); //check value is changed to true

			myffc.incrementPosition();
			assertTrue(myffc.getPosition() == i + 1); //incremented position by 1

		}
		myffc.setPosition(0); //reset position
		assertTrue(myffc.getPosition() == 0);
	}

}
