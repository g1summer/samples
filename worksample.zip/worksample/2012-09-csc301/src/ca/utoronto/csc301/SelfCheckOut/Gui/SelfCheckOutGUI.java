/*
 * Creator: Rosalva Gallardo-Valencia
 * 
 * Created on Oct 2, 2008
 * Updated on Oct 6, 2008, September 12, 2012
 * 
 * The SelfCheckOutGui class handles the Graphical User Interface for the Self CheckOut 
 * system. It allows the user to do the following actions in the system: 
 * Start Transaction, Add a Packaged Item, Add a Bulk Item, 
 * Bag Item, and Pay for Items.
 * Application messages, including exceptions, will be shown in the Messages section of the
 * screen.
 */
package ca.utoronto.csc301.SelfCheckOut.Gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIDefaults;
import javax.swing.UIManager;

import ca.utoronto.csc301.SelfCheckOut.App.GroceryItem;
import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomer;
import ca.utoronto.csc301.SelfCheckOut.App.ProductCategory;
import ca.utoronto.csc301.SelfCheckOut.App.ProductDB;
import ca.utoronto.csc301.SelfCheckOut.App.ProductInfo;
import ca.utoronto.csc301.SelfCheckOut.App.SelfCheckOut;
import ca.utoronto.csc301.SelfCheckOut.App.ProductCategoryDB;
import ca.utoronto.csc301.SelfCheckOut.Devices.SoundSystem;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.AddWhileBaggingException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.AddWhilePayingException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.AlreadyLoggedInException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.BagWhileAddingException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.IncorrectStateException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidBICException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidProductException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidUPCException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.StallCustomerException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidWeightException;

/**
 * This class contains the main method that will show the Graphical User
 * Interface of the Self CheckOut System.
 * 
 */
public class SelfCheckOutGUI extends JPanel implements ActionListener, SearchResultPanelListener{
    /**
	 * Class serial version
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Static SelfCheckOutGUI frame used for dynamic resizing.
	 */
	private static JFrame frame;
	/**
	 * Static font size for SelfCheckOutGUI
	 */
	private static float fontSize;
	/**
	 * String for the UPC label
	 */
	protected static final String upcLabelString = "UPC Number";
	/**
	 * String for the BIC label
	 */
	protected static final String bicLabelString = "BIC Number";
	/**
	 * String for preferred customer login label
	 */
	protected static final String prefLoginString = "Preferred Customer Login";
	/**
	 * String for the Weight label
	 */
	protected static final String bicWeightLabelString = "Weight";
	/**
	 * Button for Start action
	 */
	protected JButton startButton;
	/**
	 * Button for Add Packaged Item action
	 */
	protected JButton addUPCButton;
	/**
	 * Button for Add Bulk Item action
	 */
	protected JButton addBICButton;
	/**
	 * Button for Bag Item action
	 */
	protected JButton bagItemButton;
	/**
	 * Button for Pay for Items action
	 */
	protected JButton payButton;
	/**
	 * Login button for preferred customers
	 */
	protected JButton loginButton;
	/**
	 * sign up button for preferred customers
	 */
	protected JButton signUpButton;
	/**
	 * Settings button for GUI customization.
	 */
	protected JButton settingsButton;
	/**
	 * Text Field for UPC
	 */
	/**
	 * Index button for showing the search index
	 */
	protected JButton indexButton;
	
	protected JTextField upcTextField;
	/**
	 * Text Field for BIC
	 */
	protected JTextField bicTextField;
	/**
	 * Text Field for Preferred Customer Login
	 */
	protected JTextField prefLoginTextField;
	/**
	 * Text Field for Weight
	 */
	protected JTextField bicWeightTextField;
	/**
	 * Text Area for application messages
	 */	
    protected JTextArea messagesTextArea;
    /**
     * label used to hold visual feed back.
     */
    private static JLabel visualFeedBackLabel;
    
    /**
     * Text field for entering search terms
     */
    protected JTextField searchField;
    
    /**
     * Panel for searching
     */
    protected JPanel searchPanel;
    
    /**
     * Panel for displaying search results
     */
    protected SearchResultPanel productSearchResultPanel;
    
    /**
     * Database for storing roduct categry information
     */
    protected ProductCategoryDB categoryDB;
    
	/**
	 * SelfCheckOut object for the transaction
	 */

	protected SelfCheckOut selfCheckOut;
	/**
	 * GroceryItem object used for the transaction
	 */
	protected GroceryItem groceryItem = null;
	/**
	 * This constructor creates the text fields, labels, and buttons. It organizes all 
	 * these objects in a Grid Bag that has 5 lines, one per each action.
	 * It also creates a text area to show the application messages including exceptions.
	 * Finally, it includes all the created controls in a panel
	 */    
	
	//the message you wish to display for the customer being stalled
	private String stallMsg = "\n please wait, the machine is processing, thank you" +
			"for your patience and we are sorry for the inconvinence...\n";
	
	//enter this code in any text area and click any button
	//to reset the self check out.
	//use this the exit the stalling state
	//it is expected to be used by store personals to turn off
	//the customer stalling after the situation is dissolved.
	private String resetCommand = "abcd";

	/**
	 * The birthday message to be played to a preferred customer who birthday is the 
	 * current day.
	 */
	private String birthdayMsg = "\n You are having a birthday today, right?" +
			"Congratulations!! Happy birthday to you!! \n";
	
	/**
	 * If the customer has bought an eco friendly product.
	 */
	private boolean boughtEcoFriendlyProduct = false;
	
    public SelfCheckOutGUI() {
        setLayout(new BorderLayout());
        
        //set default font size and background color
        fontSize = 12f;

        //Text field for Preferred Customer Login
        prefLoginTextField = new JTextField(10);
        prefLoginTextField.setActionCommand(prefLoginString);
        prefLoginTextField.addActionListener(this);
        
        //Text field for UPC
        upcTextField = new JTextField(10);
        upcTextField.setActionCommand(upcLabelString);
        upcTextField.addActionListener(this);
        
        //Text field for BIC
        bicTextField = new JTextField(10);
        bicTextField.setActionCommand(bicLabelString);
        bicTextField.addActionListener(this);
        
        //Text field for BIC Weight
        bicWeightTextField = new JTextField(10);
        bicWeightTextField.setActionCommand(bicWeightLabelString);
        bicWeightTextField.addActionListener(this);

        //Label for UPC
        JLabel loginTextFieldLabel = new JLabel(prefLoginString + ": ");
        loginTextFieldLabel.setLabelFor(prefLoginTextField);
        
        //Label for UPC
        JLabel upcTextFieldLabel = new JLabel(upcLabelString + ": ");
        upcTextFieldLabel.setLabelFor(upcTextField);
        
        //Label for BIC
        JLabel bicTextFieldLabel = new JLabel(bicLabelString + ": ");
        bicTextFieldLabel.setLabelFor(bicTextField);
        
        //Label for BIC Weight
        JLabel bicWeightTextFieldLabel = new JLabel(bicWeightLabelString + ": ");
        bicWeightTextFieldLabel.setLabelFor(bicWeightTextField);
        
        
//        //Start Button
//        startButton = new JButton("Start");
//        startButton.setVerticalTextPosition(AbstractButton.BOTTOM);
//        startButton.setHorizontalTextPosition(AbstractButton.CENTER);
//        startButton.setActionCommand("start");
//        startButton.addActionListener(this);
       
        //Add Packaged Item Button
        addUPCButton = new JButton("Add UPC");
        addUPCButton.setVerticalTextPosition(AbstractButton.BOTTOM);
        addUPCButton.setHorizontalTextPosition(AbstractButton.CENTER);
        addUPCButton.setActionCommand("addUPC");
        addUPCButton.addActionListener(this);
        
        //Add Builk Item Button
        addBICButton = new JButton("Add BIC");
        addBICButton.setVerticalTextPosition(AbstractButton.BOTTOM);
        addBICButton.setHorizontalTextPosition(AbstractButton.CENTER);
        addBICButton.setActionCommand("addBIC");
        addBICButton.addActionListener(this);
        
        //Bag Item Button
        bagItemButton = new JButton("Bag Item");
        bagItemButton.setVerticalTextPosition(AbstractButton.BOTTOM);
        bagItemButton.setHorizontalTextPosition(AbstractButton.CENTER);
        bagItemButton.setActionCommand("bagItem");
        bagItemButton.addActionListener(this);
        
        //Pay Button
        payButton = new JButton("Pay");
        payButton.setVerticalTextPosition(AbstractButton.BOTTOM);
        payButton.setHorizontalTextPosition(AbstractButton.CENTER);
        payButton.setActionCommand("payItems");
        payButton.addActionListener(this);
        
        //Preferred Customer Login Button
        loginButton = new JButton("Login");
        loginButton.setVerticalTextPosition(AbstractButton.BOTTOM);
        loginButton.setHorizontalTextPosition(AbstractButton.CENTER);
        loginButton.setActionCommand("preferredLogin");
        loginButton.addActionListener(this);
        
        //Preferred Customer Login Button
        signUpButton = new JButton("Sign Up");
        signUpButton.setVerticalTextPosition(AbstractButton.BOTTOM);
        signUpButton.setHorizontalTextPosition(AbstractButton.CENTER);
        signUpButton.setActionCommand("signUp");
        signUpButton.addActionListener(this);
        
        //Settings button
        settingsButton = new JButton("Settings");
        settingsButton.setVerticalTextPosition(AbstractButton.BOTTOM);
        settingsButton.setHorizontalTextPosition(AbstractButton.CENTER);
        settingsButton.setActionCommand("settings");
        settingsButton.addActionListener(this);
        
        
        //Lay out the text controls and the labels
        JPanel textControlsPane = new JPanel();
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();

        textControlsPane.setLayout(gridbag);
		c.anchor = GridBagConstraints.EAST;
		c.insets = new Insets(5, 5, 5, 5); //padding space between cells

		// //Line 1: Start Action
		// c.gridwidth = GridBagConstraints.REMAINDER; //next-to-last
		// c.fill = GridBagConstraints.NONE; //reset to default
		// c.weightx = 0.0; //reset to default
		// textControlsPane.add(startButton, c);

		// Line 2: Preferred Customer Login
		c.gridwidth = 1; //normal width per cell
		c.fill = GridBagConstraints.NONE; // reset to default
		c.weightx = 0.0; // reset to default
		textControlsPane.add(loginTextFieldLabel, c);

		c.gridwidth = 1;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 1.0;
		textControlsPane.add(prefLoginTextField, c);

		c.anchor = GridBagConstraints.WEST; //align to the text field
		c.gridwidth = 1;
		c.fill = GridBagConstraints.NONE;
		c.weightx = 1.0;
		textControlsPane.add(loginButton, c);

		c.anchor = GridBagConstraints.CENTER;
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.fill = GridBagConstraints.NONE;
		c.weightx = 1.0;
		textControlsPane.add(signUpButton, c);		
		
		//Line 3: Add Packaged Item 	
		c.anchor = GridBagConstraints.EAST;
		c.gridwidth = 1; //normal width per cell
		c.fill = GridBagConstraints.NONE;      //reset to default
		c.weightx = 0.0;                       //reset to default
		textControlsPane.add(upcTextFieldLabel, c);

		c.gridwidth = 1;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 1.0;
		textControlsPane.add(upcTextField, c);   
		
		c.anchor = GridBagConstraints.WEST; //last one closest to previous
		c.gridwidth = GridBagConstraints.REMAINDER;     //end row
		c.fill = GridBagConstraints.NONE;
		c.weightx = 1.0;
		textControlsPane.add(addUPCButton, c);   
		
		//Line 4: Add Bulk Item	
		c.anchor = GridBagConstraints.EAST; //reset anchoring
		c.gridwidth = 1; //normal width per cell
		c.fill = GridBagConstraints.NONE;      //reset to default
		c.weightx = 0.0;                       //reset to default
		textControlsPane.add(bicTextFieldLabel, c);

		c.gridwidth = 1;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 1.0;
		textControlsPane.add(bicTextField, c);

		c.anchor = GridBagConstraints.WEST; //align to the text field
		c.gridwidth = 1;
		c.fill = GridBagConstraints.NONE; // reset to default
		c.weightx = 0.0; // reset to default
		textControlsPane.add(bicWeightTextFieldLabel, c);

		c.gridwidth = 1;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 1.0;
		textControlsPane.add(bicWeightTextField, c);

		c.gridwidth = GridBagConstraints.REMAINDER; // end row
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 1.0;
		textControlsPane.add(addBICButton, c);

		// Line 5: Bag Item
		c.anchor = GridBagConstraints.WEST; // align to west
		c.gridwidth = GridBagConstraints.REMAINDER; // next-to-last
		c.gridx = 1; // first column
		c.gridy = 5; // 5th row
		c.fill = GridBagConstraints.NONE; // reset to default
		c.weightx = 0.0; // reset to default
		textControlsPane.add(bagItemButton, c);

		// Line 6: Pay for Items
		c.gridwidth = GridBagConstraints.CENTER; // centered
		c.fill = GridBagConstraints.NONE; // reset to default
		c.gridx = 1;  // first column
		c.gridy = 6; // 6th row
		c.weightx = 0.0; // reset to default
		textControlsPane.add(payButton, c);
		
		//Change GUI display settings
		c.gridwidth = GridBagConstraints.REMAINDER; //last of row
		c.fill = GridBagConstraints.NONE;
		c.gridx = GridBagConstraints.RELATIVE; //set relative to row
		c.gridy = GridBagConstraints.RELATIVE;
		c.weightx =  0.0; //reset to default
		textControlsPane.add(settingsButton, c);
		
//		textControlsPane.setBackground(Color.cyan);
		textControlsPane.setMinimumSize(
				new Dimension(textControlsPane.getWidth(), textControlsPane.getHeight()));
        //Create border for Actions    
        textControlsPane.setBorder(
                BorderFactory.createCompoundBorder(
                                BorderFactory.createTitledBorder("Actions"),
                                BorderFactory.createEmptyBorder(20,20,20,textControlsPane.getWidth())));
        //right of border is set to the size of the text control pane's width.
        
        //Create a text area for the application messages
        messagesTextArea = new JTextArea();
        messagesTextArea.setFont(new Font("Serif", Font.ITALIC, (int)fontSize));
        messagesTextArea.setLineWrap(true);
        messagesTextArea.setWrapStyleWord(true);
        messagesTextArea.setEditable(false);
        
        //Add scroll to the text area
        JScrollPane areaScrollPane = new JScrollPane(messagesTextArea);
        areaScrollPane.setVerticalScrollBarPolicy(
                        JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        areaScrollPane.setPreferredSize(new Dimension(250, 250));
        
        //Create border for Messages
        areaScrollPane.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createCompoundBorder(
                                BorderFactory.createTitledBorder("Messages"),
                                BorderFactory.createEmptyBorder(5,5,5,5)),
                areaScrollPane.getBorder()));

        //Include all the controls in the application panel
        JPanel appPanel = new JPanel(new BorderLayout());
        appPanel.add(textControlsPane, 
                     BorderLayout.PAGE_START);
        appPanel.add(areaScrollPane,
                     BorderLayout.CENTER);
        
        add(appPanel, BorderLayout.LINE_START);
        
        //display visual feedback
        
        ImageIcon icon = new ImageIcon(getClass().getClassLoader().getResource("default2.jpg"));
        visualFeedBackLabel = new JLabel("");
        visualFeedBackLabel.setIcon(icon);
        //visualFeedBackLabel.setPreferredSize(new Dimension(300, 200));
        add(visualFeedBackLabel, BorderLayout.SOUTH);
        
        //Add a search panel, set up some basic things about it
        searchPanel = new JPanel();
        BoxLayout searchBox = new BoxLayout(searchPanel, BoxLayout.Y_AXIS);
        searchPanel.setLayout(searchBox);
        searchPanel.setAlignmentX(LEFT_ALIGNMENT);
        
        //Make it big enough to handle any pictures and such we give it,
        //we don't want this to change "randomly" as the user uses it since
        //that would be confusing
        searchPanel.setPreferredSize(new Dimension(400, this.getHeight()));
        add(searchPanel, BorderLayout.EAST);
        
        //Create a border for it
        searchPanel.setBorder(
                BorderFactory.createCompoundBorder(
                            BorderFactory.createTitledBorder("Search"),
                            BorderFactory.createEmptyBorder(5,5,5,5)));
        
        //Set up some components of the panel
        JLabel searchLabel = new JLabel(
        		"NEW! Search for your item code by item name!");
        searchPanel.add(searchLabel);
        searchLabel.setAlignmentX(LEFT_ALIGNMENT);
        
        //Add the text field for entering terms
        searchField = new JTextField(150);
        searchField.setMaximumSize(searchField.getPreferredSize());
        searchField.setAlignmentX(LEFT_ALIGNMENT);
        searchPanel.add(searchField);
        
        //Create button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(
        		new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        buttonPanel.setAlignmentX(LEFT_ALIGNMENT);
        
        //Add search button
        JButton searchButton = new JButton("Search!");
        searchButton.setActionCommand("search");
        searchButton.addActionListener(this);
        buttonPanel.add(searchButton);
        
        //Add search index button
        indexButton = new JButton("Show Categories");
        indexButton.setActionCommand("index");
        indexButton.addActionListener(this);
        buttonPanel.add(indexButton);
        
        searchPanel.add(buttonPanel);
        
        //Add search results panel
        productSearchResultPanel = new SearchResultPanel();
        productSearchResultPanel.addListener(this);
        productSearchResultPanel.setAlignmentX(LEFT_ALIGNMENT);
        searchPanel.add(productSearchResultPanel);
        
        //Initialize category database
        categoryDB = new ProductCategoryDB();
 
    }
	/**
	 * Method that receives the ActionEvent when a button is pressed in the 
	 * GUI. It calls to the appropriate action in the system and
	 * shows the result of the action in the message text area.
	 * If an exception is raised, this is showed in the message text area
	 * starting with the word EXCEPTION.
	 * @param e ActionEvent captured when user presses a button in the GUI
	 */       
    public void actionPerformed(ActionEvent e) {
    	//Instantiate actions class
        Actions actions = new Actions();
        try{
        	if(resetHandle(actions) || stallHandle()) {
        		return;
        	}
        	//if the reset code is entered, then do reset (to exit stalling)
        	//if SelfCheckOut is in STALLING mode, then do not do any
        	//actions other than telling the customer to wait there.
        	
        	//Start Action
	        if ("start".equals(e.getActionCommand())){
	        	
					selfCheckOut = actions.start();
					messagesTextArea.setText("SelfCheckOut has been started");
					SoundSystem.playSound(getClass(), "start.wav");
					
			//Add Packaged Item	
	        } else if ("addUPC".equals(e.getActionCommand())){
	       	        		
					groceryItem = actions.addUPC(selfCheckOut, upcTextField.getText());					
					messagesTextArea.setText("Shopping cart " + actions.printShoppingCart(selfCheckOut.listItemsInCart()));
					messagesTextArea.append("\n\nUPC Product " + upcTextField.getText() + " added." );
					upcTextField.setText("");
					
					//display visual feed back
					playVisualFeedBack("action_add_2.gif");

					SoundSystem.playSound(getClass(), "scanbeep.wav");	
			//Add Bulk Item		
	        } else if ("addBIC".equals(e.getActionCommand())){
        		        		
					groceryItem = actions.addBIC(selfCheckOut, bicTextField.getText(), Double.parseDouble(bicWeightTextField.getText()));
					messagesTextArea.setText("Shopping cart " + actions.printShoppingCart(selfCheckOut.listItemsInCart()));
					messagesTextArea.append("\n\nBIC Product " + bicTextField.getText() + " added. ");
					bicTextField.setText("");
					bicWeightTextField.setText("");
					
					//display visual feed back
					playVisualFeedBack("action_add_2.gif");
					
					SoundSystem.playSound(getClass(), "scanbeep.wav");	

			
			//Bag Item
	        } else if ("bagItem".equals(e.getActionCommand())){
	        	    
	        		if (groceryItem == null) {
	        			if (selfCheckOut == null) {
	        				throw new NullPointerException();
	        			} else {
	        				throw new BagWhileAddingException();
	        			}
	        		} else {
						actions.bagItem(selfCheckOut, groceryItem);
						messagesTextArea.setText("Shopping cart " + actions.printShoppingCart(selfCheckOut.listItemsInCart()));
						messagesTextArea.append("\n\nProduct bagged. ");
						
						//display visual feed back
						playVisualFeedBack("action_bag_2.gif");
						
						SoundSystem.playSound(getClass(), "scanbeep.wav");
	        		}
					
			//Pay for Items		
	        } else if ("payItems".equals(e.getActionCommand())){
	        				
	        		messagesTextArea.setText("Shopping cart " + actions.printShoppingCart(selfCheckOut.listItemsInCart()));
	        		String partialText = "\n\nTotal $" + String.format("%.2f", selfCheckOut.getTotalCost());
	        		
	        		//Set the boughtEcoFriendlyProduct to be true is there is an eco friendly
	        		//product in the self checkout cart.
	        		//this is done before calling actions.payItems()
	        		//It is because once actions.payItems() is called, the old checkout cart
	        		//is thrown out, and a new empty one is assigned.
	        		//once the new one is assigned, you can no longer tell if a customer has bought
	        		//an eco friendly product on the last cart, unless you have stored this information
	        		//already.
	        		if (selfCheckOut.shoppedEcoFriendlyItem()){
	        			this.boughtEcoFriendlyProduct = true;
	        			SoundSystem.playSound(getClass(), "thankyou_produced_by_Fredericton.wav");
	        		}else{
						SoundSystem.playSound(getClass(), "cash_register.wav");
	        		}
					actions.payItems(selfCheckOut);
					messagesTextArea.append("Discounts: - $" + String.format("%.2f", selfCheckOut.getTotalDiscount()));
					messagesTextArea.append(partialText + " Paid.");
					
					//display visual feed back
					playVisualFeedBack("action_pay.gif");
					
					//enable login button
					loginButton.setEnabled(true);
					
					if (this.boughtEcoFriendlyProduct){
						/**
						 * After customer has successfully completed for the payment of an
						 * eco-friendly product, a thank you window will be presented.
						 * And boughtEcoFriendlyProduct will be set back to false for the
						 * next use.
						 */
						actions.showThankYou();
						this.boughtEcoFriendlyProduct = false;
						}
					
		        	final Object[] settings = new Object[2]; //to contain customized settings
		        	settings[0] = 12; //default font size
		        	settings[1] = new Color(238, 238, 238); //default window color
		        	
		        	Timer timer = new Timer();
		        	timer.schedule(new TimerTask()
		        	{
						@Override
						public void run() {
				        	if (settings[0] != null) {
					        	fontSize = Float.parseFloat(settings[0].toString());
				        		changeFontSize(SelfCheckOutGUI.this, fontSize);
				        	}
				        	if (settings[1] != null) {
								changeBackgroundColor(SelfCheckOutGUI.this, (Color)settings[1]);
				        	}
						}
		        	}, 1000);
		        	
					
			//log in as a preferred customer
	        } else if ("preferredLogin".equals(e.getActionCommand())){

	        		Long customerNumber = null;
	        		try {
	        			customerNumber = Long.parseLong(prefLoginTextField.getText());
	        		} catch (NumberFormatException ex) {
	        			messagesTextArea.setText("EXCEPTION: Invalid Preferred Customer Number.");
						SoundSystem.playSound(getClass(), "badbeep.wav");
	        		}
	        		
	        		if(customerNumber != null) {
	        			PreferredCustomer customer = selfCheckOut.loginPreferredCustomer(customerNumber);
	        			if(customer == null) {
	        				messagesTextArea.setText("EXCEPTION: No such preferred customer");
							SoundSystem.playSound(getClass(), "badbeep.wav");
	        			} else {
	        				Object[] settings = customer.getSettings(); //customer settings
	        				
	        	        	if (settings[0] != null) {
	        		        	fontSize = Float.parseFloat(settings[0].toString());
	        	        		changeFontSize(this, fontSize);
	        	        		frame.pack(); //dynamically resize
	        	        	}
	        	        	if (settings[1] != null) {
	        					changeBackgroundColor(this, (Color)settings[1]);
	        	        	}
	        				
	        				messagesTextArea.setText("Welcome back " + customer.getName() + ".");
	        				prefLoginTextField.setText("");
	        				
	        				//disable login button
		    				loginButton.setEnabled(false);
		    				
		    				//congratulate for birthday if it is the preferred customer's birthday		    				
		    				if (customer.hasBirthdayToday()){
		    					this.messagesTextArea.append(this.birthdayMsg);
		        				SoundSystem.playSound(getClass(), "birthday_produced_by_Fredericton.wav");	
		        				playVisualFeedBack("cake.gif");
		    				}else{
		        				SoundSystem.playSound(getClass(), "applause.wav");	
		        				//display visual feed back
		        				playVisualFeedBack("action_login.gif");	    					
		    				}
	        			}
	        		}
	        
	        //sign up for preferred customers.
	        } else if ("signUp".equals(e.getActionCommand())){
	        	// open dialog to receive info from the customer and add them to the database
	        	String message = "Please enter your personal information";
	        	PreferredCustomer pc = actions.addPreferredCustomer(message, selfCheckOut, null);
	        	
	        	if(pc == null) {
    				messagesTextArea.setText("Sign up cancelled");
					SoundSystem.playSound(getClass(), "badbeep.wav");
    			} else {
    				actions.showSuccess(pc.getId()); //show success screen
    				pc = selfCheckOut.loginPreferredCustomer(pc.getId());
    				if (pc == null) {
    					messagesTextArea.setText("Login Failed");
    					SoundSystem.playSound(getClass(), "badbeep.wav");
    				} else {
	    				messagesTextArea.setText("Welcome " + pc.getName() + ".\n");	    						
	    				prefLoginTextField.setText("");
	    				
	    				//congratulate for birthday if it is the preferred customer's birthday
	    				if (pc.hasBirthdayToday()){
	    					this.messagesTextArea.append(this.birthdayMsg);
	        				SoundSystem.playSound(getClass(), "birthday_produced_by_Fredericton.wav");
	        				playVisualFeedBack("cake.gif");
	    				}
	    				else{
		    				
		    				//display visual feed back
	        				playVisualFeedBack("action_login.gif");
	    					
	    				}
	    				
	    				//disable login button
	    				loginButton.setEnabled(false);
    				}
    			}
	        }  else if("settings".equals(e.getActionCommand())) {
	        	//show settings window
	        	int size = 19; 			//number of font sizes
	        	int maxFontSize = 26; 	//max font size
	        	int fontIndex = 0;
	        	//Find font size index
	        	for (int i = 0; i < size; i++) {
	        		if (maxFontSize - i == fontSize) {
	        			fontIndex = i;
	        			break;
	        		}
	        	}
	        	Object[] settings = new Object[2]; //to contain customized settings
	        	PreferredCustomer customer = selfCheckOut.getPreferredCustomer();
	        	
	        	settings = actions.showSettings(fontIndex, customer);
	        	if (settings[0] != null) {
		        	fontSize = Float.parseFloat(settings[0].toString());
	        		changeFontSize(this, fontSize);
	        	}
	        	if (settings[1] != null) {
					changeBackgroundColor(this, (Color)settings[1]);
	        	}
	        	
        		//save customization for preferred customer
        		if (customer != null) {
        			customer.setSettings(settings);
        			selfCheckOut.updatePreferredCustomer(customer);
        		}
	        	
	        } else if ("search".equals(e.getActionCommand())) {
	        	//change indexButton text
	        	indexButton.setText("Show Categories");
	        	//display search results
	        	productSearchResultPanel.displayResults(actions.searchProductByText(
	        			selfCheckOut, searchField.getText()));	        	
	        } else if ("index".equals(e.getActionCommand())) {
	        	//change indexButton text
	        	indexButton.setText("Show Categories");
	        	//display categories
	        	productSearchResultPanel.displayCategories(categoryDB.getAllItems());
	        }
	    //Show exception in the text area for messages
        } catch (AddWhileBaggingException awbe) {
        	messagesTextArea.setText("EXCEPTION: Item scanned before previous item is bagged.");
			SoundSystem.playSound(getClass(), "badbeep.wav");
		} catch (AddWhilePayingException awpe) {
			messagesTextArea.setText("EXCEPTION: Item scanned while payment is being processed");
			SoundSystem.playSound(getClass(), "badbeep.wav");
		} catch (BagWhileAddingException bwae) {
			messagesTextArea.setText("EXCEPTION: Item bagged without being scanned");
			SoundSystem.playSound(getClass(), "badbeep.wav");
		} catch (InvalidProductException ipe) {
			messagesTextArea.setText("EXCEPTION: Item not recognized.");
			SoundSystem.playSound(getClass(), "badbeep.wav");
		} catch (AlreadyLoggedInException alie) {
			messagesTextArea.setText("EXCEPTION: There is already a preferred customer logged in");
			SoundSystem.playSound(getClass(), "badbeep.wav");
		} catch (IncorrectStateException ise) {
			messagesTextArea.setText("EXCEPTION: Invalid action for current state of Self Check Out.");
			SoundSystem.playSound(getClass(), "badbeep.wav");
		} catch (NumberFormatException nfe) {
			messagesTextArea.setText("EXCEPTION: Invalid format for the Weight.");
			SoundSystem.playSound(getClass(), "badbeep.wav");
		} catch (InvalidWeightException zwe) {
			messagesTextArea.setText("EXCEPTION: Item should not have 0 or negative weight.");
			SoundSystem.playSound(getClass(), "badbeep.wav");
        } catch (InvalidUPCException iupce) {
			messagesTextArea.setText("EXCEPTION: Invalid UPC: " + iupce.getMessage());
			SoundSystem.playSound(getClass(), "badbeep.wav");
		} catch (InvalidBICException ibice) {
			messagesTextArea.setText("EXCEPTION: Invalid BIC: " + ibice.getMessage());
			SoundSystem.playSound(getClass(), "badbeep.wav");
		} catch (NullPointerException npe) {
			npe.printStackTrace();
		
			//Checks if the selfCheckOut object is null
			if (selfCheckOut == null)
			{
				messagesTextArea.setText("EXCEPTION: Self Check Out has not been started.");
				SoundSystem.playSound(getClass(), "badbeep.wav");				
			}
			else
			{
				messagesTextArea.setText("EXCEPTION: Null Pointer Exception.");	
				SoundSystem.playSound(getClass(), "badbeep.wav");			
			}
		} catch (StallCustomerException sce){
			messagesTextArea.append(stallMsg);
		}
		catch (Exception exception) {
			messagesTextArea.setText("EXCEPTION: An exception has occurred: "+ exception.getMessage() +". Check console for more details.");
			SoundSystem.playSound(getClass(), "badbeep.wav");
			exception.printStackTrace();
		}
        
    }
    
    /**
     * This function handles events from the SearchResultPanel.
     * 
     * Takes information received from the panel and acts as if the user had just
     * entered it into the older default GUI themselves, so error-handling etc is
     * just passed along to the normal functions responsible for those.
     */
    public void resultEvent(String event) {
    	//Check whether the event string is all numeric
    	boolean isNumeric = true;
    	try {  
    		Float.parseFloat(event);  
    	} catch(NumberFormatException nfe) {  
    		isNumeric =  false;  
    	}
    	
    	//Handling the selection of a category
    	if (!isNumeric) {
    		indexButton.setText("Back");
    		ProductCategory category = categoryDB.lookUpItem(event);
    		ProductDB productDB = selfCheckOut.getProductDB();
    		ArrayList<ProductSearchResult> results = new ArrayList<ProductSearchResult>();
    		
    		for (String code : category.listProducts()) {
    			ProductInfo productInfo = productDB.lookUpItem(code);
    			ProductSearchResult searchResult = new ProductSearchResult(
    					productInfo.getDescription(),
    					productInfo.getCode().getCode(),
    					productInfo.getImage());
    			results.add(searchResult);
    		}
    		
    		productSearchResultPanel.displayResults(results);
    	}
    	//Handling the selection of a BIC item
    	else if (event.length() == 5) {
    		//Prompt the user for the weight
    		String weight = JOptionPane.showInputDialog("Please enter the weight:");
    		
    		//If weight is null, they pressed cancel so we do nothing
    		//Otherwise, try adding the item they entered.
    		if (weight != null) {
        		bicTextField.setText(event);
        		bicWeightTextField.setText(weight);
        		addBICButton.doClick();
    		}
    	}
    	//Handling the selection of a UPC item
    	else {
    		//Set the text and try adding the item
    		upcTextField.setText(event);
    		addUPCButton.doClick();
    	}
    }

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event dispatch thread.
     * 
     * @param scoGUI takes in a SelfCheckOutGUI GUI instance
     */
    private static JFrame createAndShowGUI(SelfCheckOutGUI scoGUI) {
        //Create and set up the window
        frame = new JFrame("Self Check Out");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        

        //Add content to the window
        frame.add(scoGUI);
        createAndShowWelcomeScreen(frame, scoGUI);

        //Display the window
        frame.pack();
        frame.setLocationRelativeTo(null); // show at center
        frame.setVisible(true);

        return frame;
    }
    
    /**
     * Show the Graphical User Interface for the Self Check Out application's welcome screen.
     * 
     * @param SelfCheckOutGUIFrame the frame containing a SelfCheckOutGUI to use in our JDialog
     * @param scoGUI a SelfCheckOutGUI to listen to our start button
     */
    private static void createAndShowWelcomeScreen(JFrame SelfCheckOutGUIFrame, SelfCheckOutGUI scoGUI) {

        //Add content to the window	     
        JDialog dialog = new JDialog(SelfCheckOutGUIFrame, "Welcome",
				Dialog.ModalityType.APPLICATION_MODAL);
        dialog.setSize(new Dimension(500, 500)); //set size of dialog
        //make a JDialog welcome screen with action listener functionality
		WelcomeScreenPanel welcomePanel = new WelcomeScreenPanel(dialog, "welcome1.jpg"); 
        
        //Start Button
        JButton startButton = new JButton("Start");
		startButton.setActionCommand("start");
		startButton.addActionListener(scoGUI);
		startButton.addActionListener(welcomePanel);
		
	    //Layout Manager
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();

        welcomePanel.setLayout(gridbag);
		c.anchor = GridBagConstraints.EAST;
		
		//Line 1: Start Action 
		c.gridwidth = GridBagConstraints.REMAINDER; //next-to-last
		c.fill = GridBagConstraints.NONE;      //reset to default
		c.weightx = 0.0;                       //reset to default
		welcomePanel.add(startButton, c);

		welcomePanel.add(startButton); // add button to panel

		dialog.add(welcomePanel);

		//set minimum size
		dialog.setMinimumSize(new Dimension(welcomePanel.getImageWidth(), 
											welcomePanel.getImageHeight()));
		dialog.setResizable(false); //leave the size as it is
		
		//Display welcome screen
		dialog.pack();
		dialog.setLocationRelativeTo(null); //center the welcome screen
		dialog.setVisible(true);
		//Shutdown App when dialog has been closed.
		if (!welcomePanel.hasStarted()) {
			System.exit(0);
		}

	}

	/**
	 * Show the Graphical User Interface for the Self Check Out application
	 */
	public static void main(String[] args) {
		// Schedule a job for the event dispatching thread:
		// creating and showing this application's GUI.
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SelfCheckOutGUI scoGUI = new SelfCheckOutGUI();
				createAndShowGUI(scoGUI);

			}
		});
	}

	/**
	 * Change font size of overall SelfCheckOutGUI app
	 */
	public void changeFontSize(SelfCheckOutGUI scoGUI, float size) {
		// Change the size of the SelfCheckOutGUI fonts
		changeSCOFontSize(scoGUI, size);
		// Change size of the general UI
		changeUIFontSize(size);
		frame.pack(); //dynamically resize
	}

	/**
	 * Change the SelfCheckOutGUI font size
	 */
	private void changeSCOFontSize(Component component, float size) {

		component.setFont(component.getFont().deriveFont(size));
		component.validate();
		if (component instanceof Container) {
			for (Component child : ((Container) component).getComponents()) {
				changeSCOFontSize(child, size);
			}
		}
	}

	/**
	 * Change the UI font size
	 */
	private void changeUIFontSize(float size) {

		UIDefaults defaults = UIManager.getDefaults();
		ArrayList<Object> newDefaults = new ArrayList<Object>();
		Map<Object, Font> newFonts = new HashMap<Object, Font>();
		Enumeration<Object> enumeration = defaults.keys();
		while (enumeration.hasMoreElements()) {
			Object key = enumeration.nextElement();
			Object value = defaults.get(key);
			if (value instanceof Font) {
				Font oldFont = (Font) value;
				Font newFont = newFonts.get(oldFont);
				if (newFont == null) {
					newFont = new Font(oldFont.getName(), oldFont.getStyle(),
							(int) size); // cast problem
					newFonts.put(oldFont, newFont);
				}
				newDefaults.add(key);
				newDefaults.add(newFont);
			}
		}
		defaults.putDefaults(newDefaults.toArray());
	}

	/**
	 * Changes the background color of the overall application
	 */
	public void changeBackgroundColor(Component component, Color color) {
		//Change default background color of every default UI panel and option pane
		UIManager.put("OptionPane.background", color);
		UIManager.put("Panel.background", color);
		//Change background color of SelfCheckOutGUI
		changeSCOBackground(component, color);

	}
	
	/**
	 * Changes the SelfCheckOutGUI background color components
	 */
	private void changeSCOBackground(Component component, Color color) {
		if 	((component instanceof JButton) ||
			(component instanceof JTextField) ||
			(component instanceof JLabel) ||
			(component instanceof ca.utoronto.csc301.SelfCheckOut.Gui.SearchResultPanel)) {
			return;
		}
		component.setBackground(color);
		component.validate();

		if ((component instanceof Container) && !(component instanceof JScrollPane)) {
			for (Component child : ((Container) component).getComponents()) {
				changeBackgroundColor(child, color);
			}
		}

	}

	/**
	 * play the visual feed back on visualFeedBackLabel
	 * 
	 * @param fileName
	 *            , the image file which contains the image to be displayed on
	 *            visualFeedBackLabel, this file must be already placed directly
	 *            under the visualFeedBackImages folder. Otherwise, this file
	 *            will not be read, and the visual feed back display will fail.
	 */
	public void playVisualFeedBack(String fileName) {
		String pathname = fileName;
		ImageIcon icon = new ImageIcon(getClass().getClassLoader().getResource(pathname));
		//refresh the image, so when the image is displayed later again
		//it will be displayed properly, this is essential for the display
		//of gif images, because without refresh the icon, if you display
		//the gif again (after displayed it before), 
		//you will probably get the latest frame only, and it will
		//not be played as a proper animation as you would expect.
		icon.getImage().flush();
		visualFeedBackLabel.setIcon(icon);
	}

	public boolean resetHandle(Actions actions) throws Exception {
		// if store person enters reset code, then reset
		// the self check out and tell actionPerformed
		// just return with out doing anything
		if (selfCheckOut == null) {
			 return false;
		}
    	if (upcTextField.getText().equals(resetCommand) ||
    			bicTextField.getText().equals(resetCommand)||
    			bicWeightTextField.getText().equals(resetCommand)||
    			prefLoginTextField.getText().equals(resetCommand)){
				selfCheckOut.resetAll();
				messagesTextArea.setText("");
				upcTextField.setText("");
				bicTextField.setText("");
				bicWeightTextField.setText("");
				prefLoginTextField.setText("");
    			return true;
    	}
    	return false;
   
	}
	
	public boolean stallHandle(){ 	
		//if the selfcheckout is in stall state, then tell
		//customer to keep waiting, and tell actionPerformed
		//just return without doing anyting.
		if (selfCheckOut == null) {
			return false;
		}
		if (selfCheckOut.inStallState()){
			messagesTextArea.append(stallMsg);
			return true;
		}
		return false;
	}

}
