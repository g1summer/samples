package ca.utoronto.csc301.SelfCheckOut.App;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.FileWriter;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class DatabaseTest {
	/**
	 * The database being tested
	 */
	private TestDatabase db;
	
	/**
	 * database file name
	 */
	private final static String DB_FILE = "Junit-DatabaseTest.db";
	
	/**
	 * Database class is abstract, so we create a dummy one which
	 * facilitates testing.
	 */
	private class TestDatabase extends Database<Integer, String> {

		public TestDatabase() {
			super(DB_FILE);
		}

		/**
		 * Restores the database from the file in key-value pairs.
		 * Key will be the line number, value will be the entire line
		 */
		@Override
		protected Hashtable<Integer, String> restoreDatabase(Scanner scanner) {
			Hashtable<Integer, String> hashtable = new Hashtable<Integer, String>();
			
			while(scanner.hasNextLine()) {
				String line = scanner.nextLine();
				String[] split = line.split(":");
				
				Integer key = Integer.parseInt(split[0]);
				
				hashtable.put(key, split[1]);
			}
			
			return hashtable;
		}
		
		/**
		 * Writes a single item into the database's file
		 */
		@Override
		protected void addToDatabase(FileWriter writer, Integer key, String value) {
			try {
				writer.write(key + ":" + value + String.format("%n"));
			} catch (Exception e) {
				throw new RuntimeException("Exception happened while testing");
			}
		}
	}
	
	/**
	 * creates a database
	 */
	@Before
	public void setUp() {
		db = new TestDatabase();
	}
	
	/**
	 * destroys the database and its file
	 */
	@After
	public void tearDown() {
		db.clearDatabase();
		db = null;
		
		File file = new File(DB_FILE);
		if(file.exists())
			file.delete();
	}
	
	/**
	 * tests the empty database is indeed empty
	 */
	@Test
	public void testEmpty() {
		Enumeration<String> items = db.getAllItems();
		assertFalse(items.hasMoreElements());
	}
	
	/**
	 * tests addItem
	 */
	@Test
	public void testAddItem() {
		//add item
		assertTrue(db.addItem(1, "First"));
		
		//make sure item is in db
		Enumeration<String> items = db.getAllItems();
		assertTrue(items.nextElement().equals("First"));
		assertFalse(items.hasMoreElements());
	}
	
	/**
	 * Tests that getAllItems works and is correct
	 */
	@Test
	public void testGetAllItems() {
		//add items
		assertTrue(db.addItem(1, "One"));
		assertTrue(db.addItem(2, "Two"));
		assertTrue(db.addItem(3, "Three"));
		
		//enumeration won't have the items in order, so need to make 
		// sure all 3 items are returned, and only those 3
		boolean[] found = new boolean[3];
		found[0] = found[1] = found[2] = false;
		Enumeration<String> items = db.getAllItems();
		//search db for items
		while(items.hasMoreElements()) {
			String item = items.nextElement();
			if(item.equals("One"))
				found[0] = true;
			else if(item.equals("Two"))
				found[1] = true;
			else if(item.equals("Three"))
				found[2] = true;
			else
				fail("Unknown item found in database");
		}
		
		//ensure all 3 items where found
		for(int i=0; i < 3; i++) {
			if(found[i] == false)
				fail("Item missing from database");
		}
	}
	
	/**
	 * Makes sure lookUpItem works
	 */
	@Test
	public void testLookUp() {
		//add items
		assertTrue(db.addItem(1, "One"));
		assertTrue(db.addItem(2, "Two"));
		assertTrue(db.addItem(3, "Three"));

		//try lookup on valid items
		assertTrue(db.lookUpItem(1).equals("One"));
		assertTrue(db.lookUpItem(3).equals("Three"));
		assertTrue(db.lookUpItem(2).equals("Two"));

		//try lookup on invalid items
		assertTrue(db.lookUpItem(4) == null);
		assertTrue(db.lookUpItem(0) == null);
	}
	
	/**
	 * attempts to add a second item with the same key
	 */
	@Test
	public void testItemAlreadyMappedToKey() {
		//add items 1 and 2
		assertTrue(db.addItem(1, "One"));
		assertTrue(db.addItem(2, "Two"));
		
		//try adding a second item to key 1
		assertFalse(db.addItem(1, "SecondOne"));
		
		//make sure item at key 1 is the first one added
		assertTrue(db.lookUpItem(1).equals("One"));
	}
	
	/**
	 * Tests file creation and contents of saved db
	 */
	@Test
	public void testFileCreation() {
		//add items
		assertTrue(db.addItem(1, "One", true));
		assertTrue(db.addItem(2, "Two", true));
		assertTrue(db.addItem(3, "Three", true));
		assertTrue(db.addItem(-4, "BLAH!", true));

		File file = new File(DB_FILE);
		Scanner scanner = null;
		try {
			//validate file contents
			scanner = new Scanner(file);
			assertTrue(scanner.nextLine().equals("1:One"));
			assertTrue(scanner.nextLine().equals("2:Two"));
			assertTrue(scanner.nextLine().equals("3:Three"));
			assertTrue(scanner.nextLine().equals("-4:BLAH!"));
			assertFalse(scanner.hasNextLine());
		} catch (Exception e) {
			fail("Exception happened while scanning");
		} finally {
			if(scanner != null)
				scanner.close();
		}
		
		//add another item, then scan the file again
		assertTrue(db.addItem(5, "Five", true));
		
		file = new File(DB_FILE);
		scanner = null;
		try {
			//validate file contents
			scanner = new Scanner(file);
			assertTrue(scanner.nextLine().equals("1:One"));
			assertTrue(scanner.nextLine().equals("2:Two"));
			assertTrue(scanner.nextLine().equals("3:Three"));
			assertTrue(scanner.nextLine().equals("-4:BLAH!"));
			assertTrue(scanner.nextLine().equals("5:Five"));
			assertFalse(scanner.hasNextLine());
		} catch (Exception e) {
			fail("Exception happened while scanning");
		} finally {
			if(scanner != null)
				scanner.close();
		}
	}
	
	/**
	 * tests clear database
	 */
	@Test
	public void testClearDatabase() {
		//add item
		assertTrue(db.addItem(1, "One"));
		
		//clear database
		db.clearDatabase();
		
		//make sure item is no longer there
		assertTrue(db.lookUpItem(1) == null);
		
		//make sure no items exist in db
		assertFalse(db.getAllItems().hasMoreElements());
	}
}
