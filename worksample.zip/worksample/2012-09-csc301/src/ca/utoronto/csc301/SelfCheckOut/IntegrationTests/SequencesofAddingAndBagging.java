package ca.utoronto.csc301.SelfCheckOut.IntegrationTests;

import static org.junit.Assert.*;

import java.util.Enumeration;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import ca.utoronto.csc301.SelfCheckOut.App.DiscountDB;
import ca.utoronto.csc301.SelfCheckOut.App.GroceryItem;
import ca.utoronto.csc301.SelfCheckOut.App.PreferredCustomerDB;
import ca.utoronto.csc301.SelfCheckOut.App.ProductDB;
import ca.utoronto.csc301.SelfCheckOut.App.SelfCheckOut;
import ca.utoronto.csc301.SelfCheckOut.App.UPC;
import ca.utoronto.csc301.SelfCheckOut.Devices.BaggingArea;
import ca.utoronto.csc301.SelfCheckOut.Devices.PaymentCollector;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.AddWhileBaggingException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.BagWhileAddingException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.IncorrectStateException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidProductException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.InvalidUPCException;
import ca.utoronto.csc301.SelfCheckOut.Exceptions.StallCustomerException;

public class SequencesofAddingAndBagging {
	
	static SelfCheckOut selfCheckOut;
	static ProductDB productDB;
	static BaggingArea baggingArea;
	static PaymentCollector paymentCollector;
	static PreferredCustomerDB customerDB;
	static DiscountDB discountDB;
	static UPC upc1;
	static UPC upc2;
	
	@BeforeClass
	public static void classSetUp() throws Exception {
		productDB = new ProductDB();
		paymentCollector = new PaymentCollector();
		baggingArea = new BaggingArea();
		customerDB = new PreferredCustomerDB();
		discountDB = new DiscountDB();
		
		selfCheckOut = new SelfCheckOut(baggingArea, paymentCollector, productDB, customerDB, discountDB);
		
		//Cost: 3.52	Weight: 1.35
		upc1 = new UPC("717951000842");
		//Cost: 4.00	Weight: 2.2
		upc2 = new UPC("024543213710");
				
	}
	
	@After
	public void tearDown() {
		selfCheckOut.resetAll();
	}
	
	@AfterClass
	public static void classTearDown() {
		selfCheckOut = null;
		baggingArea = null;
		productDB = null;
		paymentCollector = null;
	}
	
	/*
	 * This method is used to make sure that the cart is still usable after each
	 * test, which is useful since many of the tests involve exceptions and we 
	 * want to make sure those are handled gracefully. 
	 */
	public void addItemToCart(boolean empty) throws StallCustomerException {
		Enumeration<GroceryItem> egi;
		GroceryItem gi;
		
		//Make sure we can still add/bag an item
		try {
			selfCheckOut.addItem(upc2);
			baggingArea.changeWeight(2.2);
		} catch (IncorrectStateException e) {
			fail("IncorrectStateException");
		} catch (InvalidProductException e) {
			fail("InvalidProductException");
		}
	
		//Make sure the cart is in a correct state
		egi = selfCheckOut.listItemsInCart();
		
		if (!empty) {
			gi = egi.nextElement();
			assertEquals(upc1.toString(), gi.getInfo().getCode().toString());
		}
		
		gi = egi.nextElement();
		assertEquals(upc2.toString(), gi.getInfo().getCode().toString());
	}
	
	
	@Test
	public void AddSecondItemWithoutBagging() throws IncorrectStateException, InvalidProductException, StallCustomerException {
		boolean exceptionCaught = false;
		selfCheckOut.addItem(upc1);
		
		try {
			selfCheckOut.addItem(upc2);
		} catch (AddWhileBaggingException awbe) {
			exceptionCaught = true;
		}
		
		//We expect an AddWhileBaggingException
		assertTrue(exceptionCaught);
		
		//Make sure we can continue normally
		baggingArea.changeWeight(1.35);
		addItemToCart(false);
	}
	
	@Test
	public void AddSecondItemAfterBagging() throws IncorrectStateException, InvalidProductException, StallCustomerException {
		selfCheckOut.addItem(upc1);
		baggingArea.changeWeight(1.35);
		addItemToCart(false);
	}
	
	@Test
	public void BagTwiceAfterAdding() throws IncorrectStateException, InvalidProductException, StallCustomerException {
		boolean exceptionCaught = false;
		selfCheckOut.addItem(upc1);
		
		baggingArea.changeWeight(1.35);
		try {
			baggingArea.changeWeight(1.35);
		} catch (BagWhileAddingException bwae) {
			exceptionCaught = true;
		}
		
		//We tried to add when we should have been bagging so we should
		//have caught a BagWhileAddingException
		assertTrue(exceptionCaught);
						
		//Now make sure we can add a second item and everything is correct
		addItemToCart(false);
	}
	
	@Test
	public void BagWithoutAnyAdds() throws BagWhileAddingException, StallCustomerException {
		boolean exceptionCaught = false;
		
		try {
			baggingArea.changeWeight(1.1);
		} catch (BagWhileAddingException bwae) {
			exceptionCaught = true;
		}
		
		assertTrue(exceptionCaught);
		
		addItemToCart(true);
		
	}
	
	@Test
	public void AddDuringPayment() {
		/* We should test this, but since payment isn't implemented
		 * and just happens automatically and instantly, it is not actually
		 * possible to add another item during payment.
		 */
		
	}
	
	@Test
	public void AddInvalidItem() throws InvalidUPCException, StallCustomerException {
		//Try to add an item that's not in the database
		UPC invalidUPC = new UPC("012345678905");
		boolean exceptionCaught = false;
		
		try {
			selfCheckOut.addItem(invalidUPC);
		} catch (IncorrectStateException e) {
			fail("IncorrectStateException, expected InvalidProductException");
		} catch (InvalidProductException e) {
			exceptionCaught = true;
		}
		
		assertTrue(exceptionCaught);
		
		//Make sure the cart is still empty
		assertFalse(selfCheckOut.listItemsInCart().hasMoreElements());
		
		addItemToCart(true);
	}
}
