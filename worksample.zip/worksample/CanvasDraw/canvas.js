/* The following code contains all the functionalities for the drawing canvas. 
 * Allows a user to create and modify a select set of certain shapes (lines, squares, and triangles).
 * by H.R.
 */
var global_alpha = 1.0;
// Store the details for a single shape.
function Shape(canvas) {
	if (canvas) {
		this.context = canvas.getContext("2d");
		this.x = 0; //initial positions
		this.y = 0;
		this.x1 = 0; //second position only used by triangles
		this.x2 = 0; 
		this.x2 = 0; //terminal positions
		this.y2 = 0;
		
		this.phase = 0; //use to track which number step is during triangle drawing
	}
}

// Get the outline width of the shape.
Shape.prototype.getOutlineWidth = function () { 
	if (this.outlineWidth == undefined) { // If there is no defined width, get the outline width determined by the user.
		this.outlineWidth = getOutlineWidth();
	}
	return this.outlineWidth; 
};

// Get the fill colour of the shape.
Shape.prototype.getColor = function () { 
	if (this.color == undefined) { // If there is no defined fill colour, get the colour determined by the user.
		this.color = getFillColor();
	}
	return this.color; 
};

// Get the outline colour of the shape.
Shape.prototype.getOutlineColor = function () { 
	if (this.outlineColor == undefined) { // If there is no defined outline colour, get the colour determined by the user.
		this.outlineColor = getOutlineColor();
	}
	return this.outlineColor; 
};

// Keeps track on if a shape drawn on the canvas is selected to be modified.
Shape.prototype.selected = false;
Shape.prototype.setSelected = function(value) { this.selected = value;}
Shape.prototype.isSelected = function() { return this.selected;}

// Store the details for a single line. 
function Line(canvas) {
	Shape.call(this,canvas);
}
Line.prototype = new Shape();
Line.prototype.constructor = Line;
// Draw the line.
Line.prototype.draw = function () {
	this.context.golbalAlpha = 1
	this.context.beginPath();
    this.context.moveTo(this.x, this.y);
    this.context.lineTo(this.x2, this.y2);
    this.context.fillStyle = this.getColor();
    this.context.strokeStyle = this.getOutlineColor();

    if (this.isSelected()) {
    	this.context.lineWidth = 10;
    }
    else {
    	this.context.lineWidth = this.getOutlineWidth();
    }
    context.stroke();
    context.closePath();
}
// Determine whether a line is being selected. 
Line.prototype.testHit = function(testX,testY) {
	var t = 16; //tolerance
	var mx = (this.x + this.x2)/2;
	var my = (this.y + this.y2)/2;
	return PointInTriangle(testX,testY,this.x+t,this.y,this.x-t,this.y,this.x2,this.y2)||
	PointInTriangle(testX,testY,this.x,this.y,this.x2,this.y2+t,this.x2,this.y2-t)||
	PointInTriangle(testX,testY,this.x,this.y+t,this.x,this.y-t,this.x2,this.y2)||
	PointInTriangle(testX,testY,this.x,this.y,this.x2+t,this.y2,this.x2-t,this.y2)||

	PointInTriangle(testX,testY,mx+t ,my, mx-t,my,this.x2,this.y2)||
	PointInTriangle(testX,testY,mx ,my+t, mx,my-t,this.x2,this.y2)||
	PointInTriangle(testX,testY,mx+t ,my, mx-t,my,this.x,this.y)||
	PointInTriangle(testX,testY,mx ,my+t, mx,my-t,this.x,this.y);
	
}

// Store the details for a single triangle.
function Triangle(canvas) {
	Shape.call(this,canvas);
}
Triangle.prototype = new Shape();
Triangle.prototype.constructor = Triangle;
// Draw the triangle.
Triangle.prototype.draw = function () {
	this.context.golbalAlpha = 1;
	this.context.beginPath();
    this.context.moveTo(this.x, this.y);
    this.context.lineTo(this.x1, this.y1);
    this.context.lineTo(this.x2, this.y2);
    this.context.lineTo(this.x, this.y);
    this.context.fillStyle = this.getColor();
    this.context.strokeStyle = this.getOutlineColor();

    if (this.isSelected()) {
    	this.context.lineWidth = 10;
    }
    else {
    	this.context.lineWidth = this.getOutlineWidth();
    }
    context.fill();
    context.stroke();
    context.closePath();
}
// Determine whether a triangle is being selected. 
Triangle.prototype.testHit = function(testX,testY) {
	return PointInTriangle(testX, testY, this.x, this.y, this.x1, this.y1, this.x2, this.y2);
}

// Store the details for a single square. 
function Square(canvas) {
	Shape.call(this,canvas);
}

Square.prototype = new Shape(); // clone(Shape.prototype);
Square.prototype.constructor = Square;
// Draw the square. 
Square.prototype.draw = function () {
    this.context.globalAlpha = 1;
    this.context.beginPath();
    
    var edge = Math.min(Math.abs(this.x2 - this.x), Math.abs(this.y2 - this.y))
    var h_edge = edge;
    var v_edge = edge;
    if (this.x2 < this.x) {h_edge = h_edge * -1;}
    if (this.y2 < this.y) {v_edge = v_edge * -1;}
    this.h_edge = h_edge;
    this.v_edge = v_edge;
    
    this.context.rect(this.x, this.y, h_edge, v_edge);
    
    this.context.fillStyle = this.getColor();
    this.context.strokeStyle = this.getOutlineColor();

    if (this.isSelected()) {
    	this.context.lineWidth = 10;
    }
    else {
    	this.context.lineWidth = this.getOutlineWidth();
    }
    this.context.fill();
    this.context.stroke(); 
  };
//Determine whether a square is being selected. 
Square.prototype.testHit = function(testX,testY) {
	var xa = Math.min(this.x, this.x + this.h_edge);
	var xb = Math.max(this.x, this.x + this.h_edge);
	var ya = Math.min(this.y, this.y + this.v_edge);
	var yb = Math.max(this.y, this.y + this.v_edge);
	if ((testX > xa) && (testX < xb) && (testY > ya) && (testY < yb)){ 
		return true;}
	return false;
};

// This array hold all the shapes on the canvas.
var shapes = [];

var canvas;
var context;

// Load the canvas. 
window.onload = function() {
  canvas = document.getElementById("drawingCanvas");

  canvas.curtool = 0; // current draw tool, -1 if is selecting.
  canvas.curshape = null; 
  canvas.selectedShape = null; // Currently selected shape.
  canvas.duplicate = null; // Currently copied shape. 
  canvas.copied = 0; // Whether the currently copied shape has already been pasted on the canvas. 
  canvas.onmousedown = canvasDown;  
  canvas.onmouseup = canvasUp;
  canvas.onmousemove = canvasMove;
  canvas.moving = false;
  
  canvas.lastdown_x = 0; //latest mouse down x coord
  canvas.lastdown_y = 0;
  canvas.lastup_x = 0;
  canvas.lastup_y = 0;
  
  canvas.anchor_x = 0; //used to move objects
  canvas.anchor_y = 0;
  canvas.original_x = 0;
  canvas.original_y = 0;
  canvas.original_x1 = 0;
  canvas.original_y1 = 0;
  canvas.original_x2 = 0;
  canvas.original_y2 = 0;
  context = canvas.getContext("2d");

};

// Clear the canvas.
function clearCanvas() {
  // Remove all the shapes.
  shapes = [];

  // Update the display.
  drawShapes();
}

// Draw all the shapes currently saved. 
function drawShapes() {
  // Clear the canvas.
  context.clearRect(0, 0, canvas.width, canvas.height);

  // Go through all the shapes.
  for(var i=0; i<shapes.length; i++) {
    var shape = shapes[i];
    shape.draw();
  }
}

var previousSelectedShape;

// Handle certain key press events.
function pagePress(event) { 
	//console.log(event.keyCode);
	//console.log(event.keyChar);
	if (event.keyCode == 46||event.keyCode == 8){ // Del key, and backspace key, however, CDF has issues with Del, even Del
																		//works on other platforms, so backspace is the official hotkey for erease.
		eraseShape();
	}
	if ((event.keyCode == 173||event.keyCode == 45||event.keyCode == 95) && canvas.selectedShape!=null){ // - key.
		adjustSize(-0.03);
	}
	if ((event.keyCode == 61||event.keyCode==43) && canvas.selectedShape != null){ // + key.
		adjustSize(0.03);
	}
	if (event.which == 67 || event.which == 99){ // C key.
		copy();
	}
	if (event.which == 86 || event.which == 118){ // V key.
		paste();
	}
}

// Handle certain key down events.
function pagePressDown(event){ 
	if (event.keyCode == 46||event.keyCode==8){ // Del key, backspace key.
		eraseShape();
	}
	var mag0 = 0.03 //percentage of increase/decrease in shape size per step.
	if (canvas.selectedShape != null && ( // + or - key.
			(event.keyCode == 173 || event.keyCode == 189)||
			(event.keyCode == 61||event.keyCode == 187)
			)){
		if (event.keyCode == 173 || event.keyCode == 189) {mag0 = mag0 * -1;}
		adjustSize(mag0);
		return;
	}
}

// Delete the selected shape.
function eraseShape(){ 
	for(var i=shapes.length-1; i>=0; i--) {
	    var shape = shapes[i];
	    
	    if (shape.selected){ // Find the selected shape in the array and delete it.
	    	shape.selected=false;
	    	shapes.splice(shapes.indexOf(shape), 1);
	    	canvas.selectedShape=null;
	    	canvas.curshape=null;
	    	previousSelectedShape=null;
	    	drawShapes(); // Redraw the saved shapes to reflect this deletion. 
	    	}
	    }
	
}

// Adjust the size of the selected shape by a set amount. 
function adjustSize(amount){
	if (canvas.selectedShape == null){return;}
	cx = 0;
	cy = 0;
}

// Handle when the mouse left clicks on the canvas. 
function canvasDown(e) { 
	var cX = e.pageX - canvas.offsetLeft;
	var cY = e.pageY - canvas.offsetTop;
	if (canvas.curtool == -1){ //if user is selecting shape
		canvas.anchor_x = cX;
		canvas.anchor_y = cY;
		canvasClick(e);
		if (canvas.selectedShape != null){// if user selected a shape, then allow user to drag move it.
			canvas.original_x = canvas.selectedShape.x;
			canvas.original_y = canvas.selectedShape.y;
			canvas.original_x1 = canvas.selectedShape.x1;
			canvas.original_y1 = canvas.selectedShape.y1;
			canvas.original_x2 = canvas.selectedShape.x2;
			canvas.original_y2 = canvas.selectedShape.y2;
			canvas.moving = true;
		}
		return;
	}
	canvas.moving = true;
	  
	canvas.lastdown_x = cX;
	canvas.lastdown_y = cY;
	  
	if (canvas.curtool == 2 && canvas.curshape != null && canvas.curshape.phase == 1){ 
		  
		canvas.curshape.x2 = canvas.lastdown_x;
		canvas.curshape.y2 = canvas.lastdown_y;
		canvas.curshape.phase = 0;
		  
		canvas.moving = false;
		canvas.curshape = null;
		return;
	}
	  
	var types = [Line, Square, Triangle];
	var shape = new types[canvas.curtool](canvas);
	canvas.curshape = shape;
	shapes.push(shape);
	canvas.curshape.x = canvas.lastdown_x;
	canvas.curshape.y = canvas.lastdown_y;
	canvas.curshape.x1 = canvas.lastdown_x;
	canvas.curshape.y1 = canvas.lastdown_y;
	canvas.curshape.x2 = canvas.lastdown_x;
	canvas.curshape.y2 = canvas.lastdown_y;
	drawShapes();
	
}

// Handle when the mouse releases the left click. 
function canvasUp(e) {
	  var cX = e.pageX - canvas.offsetLeft;
	  var cY = e.pageY - canvas.offsetTop;
	if (canvas.curtool == -1 && canvas.moving && canvas.selectedShape!= null) {//done moving a shape
		canvas.moving = false;
		var dx = cX - canvas.anchor_x;
		var dy = cY - canvas.anchor_y;
		canvas.selectedShape.x = canvas.original_x + dx;
		canvas.selectedShape.y = canvas.original_y + dy;
		canvas.selectedShape.x1 = canvas.original_x1 + dx;
		canvas.selectedShape.y1 = canvas.original_y1 + dy;
		canvas.selectedShape.x2 = canvas.original_x2 + dx;
		canvas.selectedShape.y2 = canvas.original_y2 + dy;
		drawShapes();		
		return;}
	if (canvas.curshape == null){return;}
	if (canvas.curtool == 2 && canvas.curshape.phase == 0){
		canvas.curshape.x1 = cX;
		canvas.curshape.y1 = cY;
		canvas.curshape.x2 = cX;
		canvas.curshape.y2 = cY;
		drawShapes();
		canvas.curshape.phase = 1;
		return;
	}
	canvas.moving = false;
	  
	  canvas.lastup_x = cX;
	  canvas.lastup_y = cY;
	  canvas.curshape.x2 = canvas.lastup_x;
	  canvas.curshape.y2 = canvas.lastup_y;
	  drawShapes();
	  canvas.curshape.phase = 0;
	  canvas.curshape = null;
}

// Handle when a shape is moving on the canvas. 
function canvasMove(e) {
	  var cX = e.pageX - canvas.offsetLeft;
	  var cY = e.pageY - canvas.offsetTop;
	if (canvas.curtool == -1 && canvas.moving && canvas.selectedShape != null){
		if (!canvas.moving){return;}
		var dx = cX - canvas.anchor_x;
		var dy = cY - canvas.anchor_y;		
		canvas.selectedShape.x = canvas.original_x + dx;
		canvas.selectedShape.y = canvas.original_y + dy;
		canvas.selectedShape.x1 = canvas.original_x1 + dx;
		canvas.selectedShape.y1 = canvas.original_y1 + dy;
		canvas.selectedShape.x2 = canvas.original_x2 + dx;
		canvas.selectedShape.y2 = canvas.original_y2 + dy;
		drawShapes();
		return;}
	if (!canvas.moving || canvas.curshape == null){return;}

	  canvas.curshape.x2 = cX;
	  canvas.curshape.y2 = cY;
	  
	  if (canvas.curshape == 0){
	  canvas.curshape.x1 = canvas.lastup_x;
	  canvas.curshape.y1 = canvas.lastup_x;
	  }
	  
	  drawShapes();
}

// Handle when the mouse clicks on the canvas. 
function canvasClick(e) {
  // Get the canvas click coordinates.
  var clickX = e.pageX - canvas.offsetLeft;
  var clickY = e.pageY - canvas.offsetTop;

  // Look for the clicked shape.
  for(var i=shapes.length-1; i>=0; i--) {
    var shape = shapes[i];
    shape.setSelected(false);
    if (shape.testHit(clickX,clickY)) {
      if (previousSelectedShape != null) previousSelectedShape.setSelected(false);
      previousSelectedShape = shape;
      shape.setSelected(true);
      canvas.selectedShape = shape; // keep a reference of selected shapes.
      //set customizable options to the current selected shape's specs.
      document.getElementById('fillcolour').value = shape.getColor().replace(/^#/, '').toUpperCase();
      document.getElementById('fillcolour').style.backgroundColor = shape.getColor().toUpperCase();
      document.getElementById('outlinecolour').value = shape.getOutlineColor().replace(/^#/, '').toUpperCase();
      document.getElementById('outlinecolour').style.backgroundColor = shape.getOutlineColor().toUpperCase();
      document.getElementById('outlinewidth').value = shape.getOutlineWidth();
      shapes.push(shapes.splice(i, 1)[0]); // put cur selected shape on top of all other shapes.
      drawShapes();
      return;
    }
    cancelSelect(shapes); // unselect if click on black part of canvas.
    canvas.selectedShape = null; // dereference of selected shapes.
    drawShapes();
  }
}

// Set the canvas' current tool to draw a line.
function dline(){
	canvas.curtool = 0;
	cancelSelect(shapes);
}

// Set the canvas' current tool to draw a square.
function dsquare(){
	canvas.curtool = 1;
	cancelSelect(shapes);
}

// Set the canvas' current tool to draw a triangle.
function dtriangle(){
	canvas.curtool = 2;
	cancelSelect(shapes);
}

// Set the canvas' current tool to select a shape. 
function sShape(){
	canvas.curtool = -1;
}

// Cancel shape selection. 
function cancelSelect(s){
	canvas.selectedShapes = null; 
	for(var i=shapes.length-1; i>=0; i--) {
	    var shape = shapes[i];
	    shape.setSelected(false);
	}
	drawShapes();
}

// Return the user's selected shape fill colour.
function getFillColor(){
	return document.getElementById('fillcolour').style.backgroundColor;
}

// Switch the fill colour of the selected shape to the user's selected fill colour.
function switchFillColor(){
	if (canvas.selectedShape == null){return;}
	canvas.selectedShape.color = '#' + document.getElementById('fillcolour').color;
	drawShapes();
}

// Return the user's selected outline colour. 
function getOutlineColor(){
	return document.getElementById('outlinecolour').style.backgroundColor;
}

// Switch the outline colour of the selected shape to the user's selected outline colour. 
function switchOutlineColor(){
	if (canvas.selectedShape == null){return;}
	canvas.selectedShape.outlineColor = '#' + document.getElementById('outlinecolour').color;
	drawShapes();
}

// Return the user's selected outline width.
function getOutlineWidth(){
	return parseInt(document.getElementById('outlinewidth').value);
}

// Switch the outline width of the selected shape to the user's selected outline width. 
function switchOutlineWidth() {
	var newOutline = parseInt(document.getElementById('outlinewidth').value);
	var oldOutline = canvas.selectedShape.outlineWidth;
	if (canvas.selectedShape == null){return;}
	if (newOutline > oldOutline) {
		canvas.selectedShape.outlineWidth = oldOutline + (newOutline - oldOutline);
	}
	if (newOutline < oldOutline) {
		canvas.selectedShape.outlineWidth = oldOutline - (oldOutline - newOutline);
	}
	drawShapes();
}

// Increase the selected shape's outline width by one.
function increaseOutline() {
	if (canvas.selectedShape == null) {
		document.getElementById('outlinewidth').value = parseInt(document.getElementById('outlinewidth').value) + 1;
		return;
	}
	document.getElementById('outlinewidth').value = parseInt(document.getElementById('outlinewidth').value) + 1;
	canvas.selectedShape.outlineWidth = canvas.selectedShape.outlineWidth + 1;
	drawShapes();
}

// Decrease the selected shape's outline width by one. 
function decreaseOutline() {
	if (canvas.selectedShape == null) {
		if (parseInt(document.getElementById('outlinewidth').value) > 1) {
			document.getElementById('outlinewidth').value = parseInt(document.getElementById('outlinewidth').value) - 1;
		}
		return;
	}
	if (canvas.selectedShape.outlineWidth > 1) {
		document.getElementById('outlinewidth').value = parseInt(document.getElementById('outlinewidth').value) - 1;
		canvas.selectedShape.outlineWidth = canvas.selectedShape.outlineWidth - 1;
	}
	drawShapes();
}

// Adjust the size of the selected shape by a set amount. 
function adjustSize(mag){
	v1x = canvas.selectedShape.x1 - canvas.selectedShape.x;
	v2x = canvas.selectedShape.x2 - canvas.selectedShape.x;
	canvas.selectedShape.x1 = canvas.selectedShape.x + v1x * (1 + mag);
	canvas.selectedShape.x2 = canvas.selectedShape.x + v2x * (1 + mag);
	v1y = canvas.selectedShape.y1 - canvas.selectedShape.y;
	v2y = canvas.selectedShape.y2 - canvas.selectedShape.y;
	canvas.selectedShape.y1 = canvas.selectedShape.y + v1y * (1 + mag);
	canvas.selectedShape.y2 = canvas.selectedShape.y + v2y * (1 + mag);
	drawShapes();
}

// Increase the size of the selected shape.
function plusSize(){
	if (canvas.selectedShape != null){
		adjustSize(0.05);
	}
}

// Decrease the size of the selected shape.
function minusSize(){
	if (canvas.selectedShape != null){
		adjustSize(-0.05);
	}
}

// Copy the selected shape.
function copy() {
	if (canvas.selectedShape == null){return;}
	canvas.duplicate = new canvas.selectedShape.constructor(canvas); // Create a duplicate shape.
	canvas.duplicate.color = canvas.selectedShape.color;
	canvas.duplicate.outlineColor = canvas.selectedShape.outlineColor;
	canvas.duplicate.outlineWidth = canvas.selectedShape.outlineWidth;
	canvas.duplicate.x = canvas.width / 2;
	canvas.duplicate.y = canvas.height / 2;
	
	vx = canvas.duplicate.x - canvas.selectedShape.x
	vy = canvas.duplicate.y - canvas.selectedShape.y
	
	canvas.duplicate.x1 = canvas.selectedShape.x1 + vx;
	canvas.duplicate.y1 = canvas.selectedShape.y1 + vy;
	canvas.duplicate.x2 = canvas.selectedShape.x2 + vx;
	canvas.duplicate.y2 = canvas.selectedShape.y2 + vy;

	canvas.copied = 0;
}

// Paste the currently copied shape on the canvas. 
function paste() {
	if (canvas.duplicate == null) {return;}
	if (canvas.copied == 1) { // Create a new shape if the current one has already been pasted once. 
		var color = canvas.duplicate.color;
		var outline = canvas.duplicate.outlineColor;
		var width = canvas.duplicate.outlineWidth;
		var x = canvas.duplicate.x;
		var y = canvas.duplicate.y;
		var x1 = canvas.duplicate.x1;
		var y1 = canvas.duplicate.y1;
		var x2 = canvas.duplicate.x2;
		var y2 = canvas.duplicate.y2;

		canvas.duplicate = new canvas.duplicate.constructor(canvas);
		canvas.duplicate.color = color;
		canvas.duplicate.outlineColor = outline;
		canvas.duplicate.outlineWidth = width;
		canvas.duplicate.x = x;
		canvas.duplicate.y = y;
		canvas.duplicate.x1 = x1;
		canvas.duplicate.y1 = y1;
		canvas.duplicate.x2 = x2;
		canvas.duplicate.y2 = y2;
	}

	shapes.push(canvas.duplicate); // Add the shape to the array.
	drawShapes(); // Draw all the shapes. 
	canvas.copied = 1;
}

// Helper functions for triangle's hit test. 
function sign(p1x, p1y, p2x, p2y, p3x, p3y){
	return (p1x - p3x) * (p2y - p3y) - (p2x - p3x) * (p1y - p3y);
}
function PointInTriangle(px, py, p1x, p1y, p2x, p2y, p3x, p3y)
{
	b1 = sign(px, py, p1x, p1y, p2x, p2y) < 0.0;
  	b2 = sign(px, py, p2x, p2y, p3x, p3y) < 0.0;
  	b3 = sign(px, py, p3x, p3y, p1x, p1y) < 0.0;

  	return ((b1 == b2) && (b2 == b3));
}
