                               Drawing Canvas
                     by: Haitao Ran and Jennifer Collins 
                     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Main Objects and Datastructures
-------------------------------
	Shape: the generic class encompassing the three required shapes
	Line (inherits Shape): the specific class for lines
	Square (inherits Shape): the specific class for squares
	Triangle (inherits Shape): the specific class for triangles

	canvas: the drawing canvas
	shapes[]: the shapes currently on the canvas

	* More information on these objects and datastructures can be found in the
	  comments of the canvas.js file. *

How it Works
------------
	Getting Started/Familiar: When first opening the web page, you will notice
				  the blank canvas on the left and a multitude of
				  buttons and text boxes on the right. The text boxes 
				  are labelled with their purposes. If you hover over
			 	  any of the buttons with your mouse, a description of
				  what the button does appears. 

	Drawing Lines: To draw a line, simply click on the red line button, click and
		       hold on the canvas to start, and drag to the final point of the
		       line. 

	Drawing Squares: To draw a square, simply click on the yellow square button, 
		 	 click and hold on the canvas to start, and drag to the desired
			 size of the square. 

	Drawing Triangles: To draw a triangle, simply click on the blue triangle, click
			   and hold on the canvas to draw one side of the triangle, 
			   release and move the mouse to the final point of the 
			   triangle, and click to set the point. 

	Clearing the Canvas: To clear the canvas, simply click on the corresponding 
			     button (i.e. the one with a broom and the red X).

Editing Shapes on the Canvas
----------------------------
	Selecting a Shape to Edit: To select a shape to edit, simply click the select
				   button (i.e. the hand), and click on the desired
				   shape. 

	Moving a Shape: To move a shape, make sure you have selected a shape, and 
			simply click and drag the shape with the mouse. 

	Erasing a Shape: To erase a shape, make sure you have selected a shape, and
			 simply click the erease button (the eraser). For convenience,
			 you can also simply press the BackSpace key on your keyboard 
			 instead of clicking the button. 

	Copying a Shape: To copy a shape, make sure you have selected a shape, and
			 simply press the copy button (i.e. the button with two pages).
			 For convenience, you can also simply press the C key on your
			 keyboard instead of clicking the button. 

	Pasting a Shape: To paste a shape on the canvas, make sure you have already 
			 copied a shape, and simply click the paste button (the glue
			 bottle). For convenience, you can also simply press the V key
			 on your keyboard instead of clicking the button. 

Customizing Shapes
------------------
	Changing Fill Colour: To change the fill colour for future drawn shapes, simply
			      click on the 'Fill Colour' text box and select your
			      desired colour. To change the fill colour of an already
			      drawn shape, simply select the shape and pick the colour
		  	      as described above. 

	Changing Outline Colour: To change the outline colour for future drawn shapes, 
			         simply click on the 'Outline Colour' text box and 
			         select your desired colour. To change the outline 
			         colour of an already drawn shape, simply select the 
			         shape and pick the colour as described above.

	* The method of picking colours is taken from the jscolor.js library. *

	Changing Outline Width: To change the outline width for future drawn shapes,
				simply use the plus and minus buttons to increment
				the width, or type in your desired width in the text
				box. To change the width of an already drawn shape, 
				simply select the shape and change the width as 
				described above. 

	Changing Size: To change the size of an already drawn shape, simply select the
		       shape, and use the plus and minus buttons to increment the size.
		       For convenience, you can also use the + and - keys on the 
		       keyboard to change the size. 
